/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fisiogympf;

/**
 *
 * @author 52444
 */
public class FisioGympf {

    public static void main(String[] args) {
         
        principal p1 = new principal();  
        p1.setVisible(true);  
  }
}
