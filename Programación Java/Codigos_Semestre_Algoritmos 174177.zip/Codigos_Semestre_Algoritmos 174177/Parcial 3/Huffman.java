
package huffman;

public class Nodo <E extends Comparable<E>>{
    public E key;
    public int freq;
    public Nodo<E> right, left,p;
    
    public Nodo(E key, int freq) {
        this.key = key;
        this.freq = freq;
    }

    Nodo() {
        
    }
}

//---------------------------------------------------------------------------------------------------------


package huffman;

public class Arbol <E extends Comparable <E>> {
    Nodo<E> root;
	public int n = 0;
    
    public void inorderTreeWalk(Nodo<E> x){
        if(x != null){
            inorderTreeWalk(x.left);
            System.out.print(x.key.toString() + ", ");
            inorderTreeWalk(x.right);
        }
    }
	
    public void inorderTreeWalk(){
		Nodo<E> x = root;
        if(x != null){
	    System.out.println("" + x.left.key);
            inorderTreeWalk(x.left);
            System.out.print(x.key.toString() + ", ");
            inorderTreeWalk(x.right);
        }
    }
	
	public void count(Nodo<E> x){
        if(x != null){
            count(x.left);
			n++;
            count(x.right);
        }
    }
	
    public int count(){
		Nodo<E> x = root;
        if(x != null){
            count(x.left);
            n++;
            count(x.right);
        }
		
		return n;
    }
    
    public Nodo<E> treeSearch(Nodo<E>x, E k){
        if(x == null || k.compareTo(x.key) == 0) return x;
        if(k.compareTo(x.key) < 0) return treeSearch(x.left, k);
        else return treeSearch(x.right, k);
    }
	
    public Nodo<E> treeSearch(E k){
		Nodo<E> x = root;
        if(x == null || k.compareTo(x.key) == 0) return x;
        if(k.compareTo(x.key) < 0) return treeSearch(x.left, k);
        else return treeSearch(x.right, k);
    }
	
    public Nodo<E> iterativeTreeSearch(Nodo<E> x, E k) {
		while(x != null && k != x.key) {
			if(k.compareTo(x.key) < 0) x = x.left;
			else x = x.right;
		}
		return x;
    }
	
    public Nodo<E> iterativeTreeSearch(E k) {
    	Nodo<E> x = root;
		while(x != null && k != x.key) {
            if(k.compareTo(x.key) < 0) x = x.left;
            else x = x.right;
		}
		return x;
    }
	
    public Nodo <E> Minimum(Nodo <E> x){
        while(x.left!=null){
            x=x.left;
        }
        return x;
    }
    public Nodo <E> Minimum(){
        Nodo<E> x = root;
	while(x.left != null) x = x.left;
	return x;
    }
    public Nodo <E> Maximum(Nodo <E> x){
        while(x.right!=null){
            x=x.right;
        }
        return x;
    }
	
    public Nodo<E> treeSuccessor(Nodo<E> x) {
	if(x.right != null) return Minimum(x.right);
	Nodo<E> y = x.p;
	while(y != null && x == y.right) {
            x = y;
            y = y.p;
	}
    return y;
    }
    
    public Nodo<E> treePredecessor(Nodo<E> x) {
	if(x.left != null) return Maximum(x.left);
	Nodo<E> y = x.p;
	while(y != null && x == y.left) {
            x = y;
            y = y.p;
	}
        return y;
    }
    
    public void treeInsert(Nodo<E> z) {
        Nodo<E> y = null;
        Nodo<E> x = root;
        while(x != null) {
            y = x;
            if(z.freq < x.freq) x = x.left;
            else x = x.right;
        }
        z.p = y;
        if(y == null) root = z;
        else if(z.freq < y.freq) y.left = z;
        else y.right = z;
    }
	
    public void transplant(Nodo<E> u, Nodo<E> v) {
		if(u.p == null) root = v;
		else if(u == u.p.left) u.p.left = v;
		else u.p.right = v;
		if(v != null) v.p = u.p;
    }
	
    public void treeDelete(Nodo<E> z) {
		if(z.left == null) transplant(z, z.right);
		else if(z.right == null) transplant(z, z.left);
		else {
            Nodo<E> y = Minimum(z.right);
            if(y.p != z) {
		transplant(y, y.right);
		y.right = z.right;
		y.right.p = y;
            }
            transplant(z, y);
            y.left = z.left;
            y.left.p = y;
		}
    }
}


//---------------------------------------------------------------------------------------------------------------------------


package huffman;

public class HuffmanMetodo <E extends Comparable <E>> {

    public Nodo<E> Huffman(Arbol<Integer> C){
        int n = C.count();
        Arbol Q = C;
	
        for (int i = 1; i < (n-1); i++) {
            Nodo<E> z = new Nodo("Z", 0);
            Nodo x=Q.Minimum(z);
        }
        return Extract_min();
    }
    public Nodo<E> Extract_min(){
        return Extract_min();
    }
    
    
}


