<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/x-icon" href="logo3.png">
    <title>CapacitaT</title>
    <link rel="stylesheet" href="#">
</head>

<body>
   
    <header>
        <h1>CapacitaT</h1>
    </header>
    <main>
        <div>
            <h2>Origen</h2>

        </div>
        <diV>
            <h2>Bases</h2>
        </div>
        <div>
            <h2>Historia</h2>
        </div>
        <div>
            <h2>Objetivo</h2>
        </div>
        
    </main>

    <footer>
        <p>DESARROLLADORA JIMENEZ JUAREZ TANYA</p>
    </footer>
</body>
</html>
