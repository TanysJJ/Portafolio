<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/x-icon" href="logo3.png">
    <title>CapacitaT</title>
    <link rel="stylesheet" href="iniw2.css">
</head>
<body>
<header>
    <nav class="menu">
        <ul class="menu-list">
            <li><a href="inicio.php">Inicio</a></li>
            <li><a href="#">Cursos</a></li>
            <li class="dropdown"><a href="#">Soporte</a>
                <ul class="dropdown-menu">
                    <li><a href="Informacion.php">Sobre Nosotros</a></li>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Contactanos</a></li>
                </ul>
            </li>
            <li><a href="#">Iniciar sesión</a></li>
        </ul>
    </nav>
    <div class="logo-container">
        <img src="logo.jpg" alt="Logo de CapacitaT">
    </div>
</header>

<main>
<div>
  <table >
  <tr>
    <td>
      <img src="img3.png" alt="IMG1">
    </td>
    <td class="mi-celda">
     <h2>Capacitación y Consultoria</h2>
      <p>Desarrollando el talento que las empresas necesitan</p>
    </td>
  </tr>
  </table>
</div>
</main>

<footer>
    <p>DESARROLLADORA JIMENEZ JUAREZ TANYA</p>
</footer>

</body>
</html>
