<!DOCTYPE html>
<html>

<head>
        <title>Examen Practico 2P</title>
        <meta charset="utf-8">
        <link rel="icon" type="image/x-icon" href="skzoo2.jpg">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Protest+Revolution&family=Protest+Riot&family=Roboto&display=swap" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link rel="stylesheet" href="ep2p.css">

        <style>
                .boton-inicio {
                        background-color: #4560ab;
                        border: none;
                        color: white;
                        padding: 15px 32px;
                        text-align: center;
                        text-decoration: none;
                        display: inline-block;
                        font-size: 16px;
                        margin: 4px 2px;
                        cursor: pointer;
                        border-radius: 12px;
                }

                input[type="text"]{
                        width: calc(80% - 30px);
                        /* Ancho ajustado para que sea similar al de los botones */
                        padding: 10px;
                        /* Ajustar el padding */
                        margin: auto 150px;
                        /* Centrar horizontalmente y agregar espacio en la parte superior e inferior */
                        box-sizing: border-box;
                        border: none;
                        background-color: #f8f8f8;
                        font-size: 20px;
                        /* Tamaño de fuente ligeramente más pequeño */
                }
                label {
                        width: calc(80% - 30px);
                        /* Ancho ajustado para que sea similar al de los botones */
                        padding: 10px;
                        /* Ajustar el padding */
                        margin: auto 150px;
                        /* Centrar horizontalmente y agregar espacio en la parte superior e inferior */
                        border: none;
                        font-size: 20px;
                        /* Tamaño de fuente ligeramente más pequeño */
                }

                input[type="submit"] {
                        width: calc(80% - 30px);
                        /* Ancho ajustado para que sea similar al de los botones */
                        background-color: #5499C7;
                        color: white;
                        padding: 12px 20px;
                        /* Ajustar el padding */
                        margin: 30px 150px;
                        /* Centrar horizontalmente y agregar espacio en la parte superior e inferior */
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                        font-size: 20px;
                        /* Tamaño de fuente ligeramente más pequeño */
                }


                input[type="submit"]:hover {
                        background-color:#557F9B;
                }
        </style>
</head>

<body>
        <header>
                <h1>Examen Practico 2do Parcal</h1>
        </header>
        <div class="container">
                <main>
                        <section>
                                <div class="grid">
                                        <div>
                                                <form id="form1" method="post" action="mostrar.php">
                                                        <input type="submit" value=" Registros 1 a 50"><br><br>
                                                </form>

                                                <form id="form2" method="post" action="buscarid.php">
                                                        <label for="id">Busqueda por ID</label><br><br>
                                                        <input type="text" name="id" placeholder="ID"><br><br>
                                                        <input type="submit" value="Buscar Por Id"><br><br>
                                                </form>

                                                <form id="form3" method="post" action="buscargoogle.php">
                                                        <input type="submit" value="Personas con email de Google"><br><br>
                                                </form>

                                                <form id="form4" method="post" action="buscarap.php">
                                                        <input type="submit" value="Personas con apellidos Douglas o Mathews"><br><br>
                                                </form>
                                        </div>

                                        <div id="dataContainer"></div>
                                </div>

                        </section>
                </main>
        </div>
        <div class="bg"></div>
        <div class="bg bg2"></div>
        <div class="bg bg3"></div>
        <div class="content">
                <footer>
                        <p>Jimenez Juarez Tanya 174177</p>
                        <button class="boton-inicio" onclick="goBack()">Regresar</button></a>
                </footer>

                <script>
                        function goBack() {
                                window.history.back();
                        }
                </script>

                <script>
                        $(document).ready(function() {
                                $('#form1 input[type="submit"]').click(function(e) {
                                        e.preventDefault();

                                        $.ajax({
                                                url: 'mostrar.php',
                                                method: 'post',
                                                success: function(data) {
                                                        $('#dataContainer').html(data);
                                                }
                                        });
                                });

                                $('#form2 input[type="submit"]').click(function(e) {
                                        e.preventDefault();

                                        var id = $('#form2 input[name="id"]').val();

                                        $.ajax({
                                                url: 'buscarid.php',
                                                method: 'post',
                                                data: {
                                                        id: id
                                                },
                                                success: function(data) {
                                                        $('#dataContainer').html(data);
                                                }
                                        });
                                });

                                $('#form3 input[type="submit"]').click(function(e) {
                                        e.preventDefault();

                                        $.ajax({
                                                url: 'buscargoogle.php',
                                                method: 'post',
                                                success: function(data) {
                                                        $('#dataContainer').html(data);
                                                }
                                        });
                                });

                                $('#form4 input[type="submit"]').click(function(e) {
                                        e.preventDefault();

                                        $.ajax({
                                                url: 'buscarap.php',
                                                method: 'post',
                                                success: function(data) {
                                                        $('#dataContainer').html(data);
                                                }
                                        });
                                });


                        });
                </script>







</body>

</html>