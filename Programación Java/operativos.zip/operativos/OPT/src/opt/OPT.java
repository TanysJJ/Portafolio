/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package opt;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author asesi
 */
public class OPT extends JFrame{

    private JTextField framesField;
    private JTextField pagesField;
    private JTextArea resultArea;
    private JTable frameTable;
    private DefaultTableModel tableModel;

    public OPT(){
        setTitle("Óptima (OPT)");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // Panel superior con inputs
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2, 10, 10));

        inputPanel.add(new JLabel("Número de marcos:"));
        framesField = new JTextField();
        inputPanel.add(framesField);

        inputPanel.add(new JLabel("Secuencia de páginas (separadas por comas):"));
        pagesField = new JTextField();
        pagesField.setEditable(false);
        inputPanel.add(pagesField);
        
        JButton randomButton = new JButton("Generar Secuencia Aleatoria");
        inputPanel.add(randomButton);

        JButton simulateButton = new JButton("Simular");
        inputPanel.add(simulateButton);

        // Tabla para representar los marcos
        tableModel = new DefaultTableModel();
        frameTable = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(frameTable);

        // Área de resultados
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane resultScrollPane = new JScrollPane(resultArea);
        resultScrollPane.setPreferredSize(new Dimension(600, 200)); // Área de texto más grande

        // Añadir componentes al frame
        add(inputPanel, BorderLayout.NORTH);
        add(tableScrollPane, BorderLayout.CENTER);
        add(resultScrollPane, BorderLayout.SOUTH);

        // Acción para generar secuencia aleatoria
        randomButton.addActionListener(e -> generateRandomSequence());

        // Acción del botón de simulación
        simulateButton.addActionListener(e -> new Thread(this::simulateOptimal).start());
    }
    
    private void generateRandomSequence() {
        Random random = new Random();
        int sequenceLength = 10;
        StringBuilder sequence = new StringBuilder();

        for (int i = 0; i < sequenceLength; i++) {
            sequence.append(random.nextInt(9) + 1); // Números entre 1 y 9
            if (i < sequenceLength - 1) {
                sequence.append(",");
            }
        }

        pagesField.setText(sequence.toString());
    }
    
    private void simulateOptimal(){
        try{
            int numFrames = Integer.parseInt(framesField.getText().trim());
            if (numFrames <= 0) {
                resultArea.setText("El número de marcos debe ser mayor a 0.");
                return;
            }

            String[] pagesInput = pagesField.getText().trim().split(",");
            int[] pages = new int[pagesInput.length];
            for (int i = 0; i < pagesInput.length; i++) {
                pages[i] = Integer.parseInt(pagesInput[i].trim());
            }

            // Configuración inicial de la tabla
            tableModel.setRowCount(numFrames);
            tableModel.setColumnCount(1);
            for (int i = 0; i < numFrames; i++) {
                tableModel.setValueAt("-", i, 0); // Inicializamos los marcos con "-"
            }
            
            List<Integer> frames = new ArrayList<>();
            int pageFaults = 0;

            resultArea.setText(""); // Limpiamos resultados
            
            for (int i = 0; i < pages.length; i++){
                int page = pages[i];

                if (!frames.contains(page)) {
                    if (frames.size() >= numFrames) {
                        // Reemplazo Óptimo: seleccionar el marco que no se use por más tiempo
                        int pageToReplace = selectOptimalPage(frames, pages, i);
                        frames.remove((Integer) pageToReplace);
                        resultArea.append("Reemplazando página " + pageToReplace + "\n");
                        pageFaults++;
                    }

                    frames.add(page);
                    

                    // Actualizar la tabla
                    updateFrameTable(frames, numFrames);

                    // Mostrar información en el área de texto
                    resultArea.append("Cargando página " + page + " en los marcos: " + frames + "\n");
                }else {
                    resultArea.append("Página " + page + " ya está en memoria: " + frames + "\n");
                }

                // Pausa para simular animación
                Thread.sleep(1000); // 1 segundo entre cada paso
            }
            resultArea.append("\nTotal de fallos de página: " + pageFaults);
        }catch (NumberFormatException ex) {
            resultArea.setText("Por favor, ingresa datos válidos.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
     private int selectOptimalPage(List<Integer> frames, int[] pages, int currentIndex) {
        int farthestIndex = -1;
        int pageToReplace = -1;

        for (int frame : frames) {
            int nextUseIndex = Integer.MAX_VALUE; // Por defecto, no se usará más adelante
            for (int j = currentIndex + 1; j < pages.length; j++) {
                if (pages[j] == frame) {
                    nextUseIndex = j;
                    break;
                }
            }

            // Seleccionar la página con el uso más lejano o nunca usada
            if (nextUseIndex > farthestIndex) {
                farthestIndex = nextUseIndex;
                pageToReplace = frame;
            }
        }

        return pageToReplace;
    }
     
     private void updateFrameTable(List<Integer> frames, int numFrames) {
        for (int i = 0; i < numFrames; i++) {
            if (i < frames.size()) {
                tableModel.setValueAt(frames.get(i), i, 0);
            } else {
                tableModel.setValueAt("-", i, 0);
            }
        }
    }
     
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(() -> {
            OPT frame = new OPT();
            frame.setVisible(true);
        });
    }   
}
