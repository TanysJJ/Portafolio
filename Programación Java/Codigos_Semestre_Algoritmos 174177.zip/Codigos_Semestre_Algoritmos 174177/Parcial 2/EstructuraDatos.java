package estructurasdatos;


public class Queue<T>
{
    int tail;
    int head;
    T q[];

    public Queue(T[] q) {
        tail = 0;
        head = 0;
        this.q=q;
    }
    
    public void Enqueue(T x)
    {
        q[tail] = x;
        if(tail==q.length)
            tail=1;
        else 
            tail++;
    }
    
    public T Dequeue(T x)
    {
        x = q[head] ;
        if(head==q.length)
            head=1;
        else 
            head++;
        
        return x;
    }
    
}

//-----------------------------------------------------------------------------------------------------------------------------------

public class Stack<T> {
    int top;
    T[] s;

    public Stack( T[] s) {
        this.top = -1;
        this.s = s;
    }
    
    public boolean isEmpty()
    {
        boolean bandera=false;
        if(top!=0)
            return true;
        
        return bandera;
    }
    
    public void Push(T x)
    {
        top++;
        s[top]=x;
    }
    
    public T Pop()
    {
        T aux=null;
        if(isEmpty())
            System.out.println("Está vacio");
        else 
        {
            top=top-1;
            aux=s[top+1];
        }
        return aux;
    }
}


//-----------------------------------------------------------------------------------------------------------------------------------


public class LinkedList<T extends Comparable>
{
    Nodo<T> head;
    public Nodo<T> ListSearch(T k)
    {
        Nodo<T> x=head;
        
        while (x!=null && x.key!=k)
            x=x.next;
        return x;
    }
    
    public void ListInsert(Nodo<T> x)
    {
        x.next=head;
        if(head!=null)
            head.prev=x;
        head=x;
        x.prev=null;  
    }
    
    public void ListDelete(Nodo<T> x)
    {
        if(x.prev!=null)
            x.prev.next=x.next;
        else
            head=x.next;
        
        if(x.next!=null)
            x.next.prev=x.prev;
    }
    
    public void SingleInsert(Nodo<T> x)
    {
        x.next=head;
        head=x;
    }
    
    public void SingleDelete()
    {
        head=head.next;
    }
    
    public LinkedList reverses(LinkedList xs)
    {
        LinkedList ys = new LinkedList();
        
        while(xs.head!=null)
        {
            ys.SingleInsert(xs.head);
            xs.SingleDelete();
        }
        
        return ys;
    }
}


//------------------------------------------------------------------------------------------------------------------------------

public class Sentinels <T extends Comparable>
{
    Nodo<T> nil;

    public Sentinels()
    {
        nil.next=nil;
        nil.prev=nil;
    }
    
    public void Delete(Nodo<T> x)
    {
        x.prev.next = x.next;
        x.next.prev = x.prev;
    }
    
    public Nodo<T> Search(T k)
    {
        Nodo<T> x = nil.next;
        while(x!=nil && x.key!=k)
            x=x.next;
        return x;
    }
    
    public void Insert(Nodo<T> x)
    {
        x.next = nil.next;
        nil.next.prev = x;
        nil.next = x;
        x.prev = nil;
    }
    
    
}


//--------------------------------------------------------------------------------------------------------------------------------


public class Nodo <E>{
    E key;
    Nodo<E> next;
    Nodo<E> prev;
    
    public Nodo(E key)
    {
        this.key=key;
        next=null;
        prev=null;
    }
}