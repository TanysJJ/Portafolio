public boolean hasCycle() {
    boolean[] visited = new boolean[vertices];
    boolean[] recStack = new boolean[vertices];

    for (int i = 0; i < vertices; i++) {
        if (!visited[i]) {
            if (dfsCycle(i, visited, recStack)) {
                return true;
            }
        }
    }
    return false;
}

private boolean dfsCycle(int v, boolean[] visited, boolean[] recStack) {
    visited[v] = true;
    recStack[v] = true;

    for (Object neighborObj : adjList[v]) {
        int neighbor = (int) neighborObj;
        if (!visited[neighbor] && dfsCycle(neighbor, visited, recStack)) {
            return true;
        } else if (recStack[neighbor]) {
            return true;
        }
    }

    recStack[v] = false;
    return false;
}



public boolean hasCycle() {
    boolean[] visited = new boolean[vertices];
    boolean[] recStack = new boolean[vertices];

    for (int i = 0; i < vertices; i++) {
        if (!visited[i]) {
            if (dfsCycle(i, visited, recStack)) {
                return true;
            }
        }
    }
    return false;
}

private boolean dfsCycle(int v, boolean[] visited, boolean[] recStack) {
    visited[v] = true;
    recStack[v] = true;

    for (Object neighborObj : adjList[v]) {
        int neighbor = (int) neighborObj;
        if (!visited[neighbor] && dfsCycle(neighbor, visited, recStack)) {
            return true;
        } else if (recStack[neighbor]) {
            return true;
        }
    }

    recStack[v] = false;
    return false;
}

public void inOrder(Node node) {
    if (node != null) {
        inOrder(node.left);
        System.out.print(node.key + " ");
        inOrder(node.right);
    }
}

public void preOrder(Node node) {
    if (node != null) {
        System.out.print(node.key + " ");
        preOrder(node.left);
        preOrder(node.right);
    }
}

public void postOrder(Node node) {
    if (node != null) {
        postOrder(node.left);
        postOrder(node.right);
        System.out.print(node.key + " ");
    }
}

