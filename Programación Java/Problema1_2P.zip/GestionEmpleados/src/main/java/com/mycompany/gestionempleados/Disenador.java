/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestionempleados;

/**
 *
 * @author 52444
 */
public class Disenador extends Empleado {
    String herramientaDisenador;
    
    public Disenador(String nombre, double salario, String herramientaDisenador) {
        super(nombre, salario);
        this.herramientaDisenador = herramientaDisenador;
    }
    
    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Herramienta de disenio: " + herramientaDisenador);
    }
    
    @Override
    public void trabajar() {
        System.out.println("Disenia interfaces de usuario en " + herramientaDisenador);
    }
}
