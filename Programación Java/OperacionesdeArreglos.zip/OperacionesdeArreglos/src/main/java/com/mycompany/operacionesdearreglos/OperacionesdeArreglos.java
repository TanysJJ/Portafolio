/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.operacionesdearreglos;

/**
 *
 * @author 52444
 */
public class OperacionesdeArreglos {

    public static void main(String[] args) {
      Operaciones operaciones = new Operaciones();

        int[] enteros = {1, 2, 3, 4, 5};
        double[] dobles = {1.1, 2.2, 3.3, 4.4, 5.5};

        System.out.println("Suma de todos los elementos: " + operaciones.sumarElementos(enteros));
        double[] mayorYMenor = operaciones.encontrarMayorYMenor(dobles);
        System.out.println("Mayor: " + mayorYMenor[0] + ", Menor: " + mayorYMenor[1]);
        System.out.println("Suma de elementos mayores que 3: " + operaciones.sumarElementosMayoresQue(enteros, 3));

        operaciones.imprimirArreglo(enteros);
        operaciones.imprimirArreglo(dobles);
    }
}
