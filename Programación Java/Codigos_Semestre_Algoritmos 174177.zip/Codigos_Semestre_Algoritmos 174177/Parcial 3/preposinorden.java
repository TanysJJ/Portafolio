public class preposinorden {

    static class Node {
        int key;
        Node left;
        Node right;
        
        public Node(int key) {
            this.key = key;
            this.left = null;
            this.right = null;
        }
    }

    public static void inorderTree(Node x) {
        if (x != null) {
            inorderTree(x.left);
            System.out.print(x.key + " ");
            inorderTree(x.right);
        }
    }

  
    public static void preorderTree(Node x) {
        if (x != null) {
            System.out.print(x.key + " ");
            preorderTree(x.left);
            preorderTree(x.right);
        }
    }

 
    public static void postorderTree(Node x) {
        if (x != null) {
            postorderTree(x.left);
            postorderTree(x.right);
            System.out.print(x.key + " ");
        }
    }

    