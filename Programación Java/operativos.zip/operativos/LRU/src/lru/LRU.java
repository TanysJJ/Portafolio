/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lru;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author asesi
 */
public class LRU extends JFrame{
    private JTextField framesField;
    private JTextField pagesField;
    private JTextArea resultArea;
    private JTable frameTable;
    private DefaultTableModel tableModel;
    
    public LRU(){
        setTitle("LRU");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // Panel superior con inputs
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2, 10, 10));
        
        inputPanel.add(new JLabel("Número de marcos:"));
        framesField = new JTextField();
        inputPanel.add(framesField);
        
        inputPanel.add(new JLabel("Secuencia de páginas (separadas por comas):"));
        pagesField = new JTextField();
        pagesField.setEditable(false);
        inputPanel.add(pagesField);
        
        JButton randomButton = new JButton("Generar Secuencia Aleatoria");
        inputPanel.add(randomButton);

        JButton simulateButton = new JButton("Simular");
        inputPanel.add(simulateButton);
        
        // Tabla para representar los marcos
        tableModel = new DefaultTableModel();
        frameTable = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(frameTable);

        // Área de resultados
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane resultScrollPane = new JScrollPane(resultArea);
        resultScrollPane.setPreferredSize(new Dimension(600, 200)); // Ajustar el tamaño

        // Añadir componentes al frame
        add(inputPanel, BorderLayout.NORTH);
        add(tableScrollPane, BorderLayout.CENTER);
        add(resultScrollPane, BorderLayout.SOUTH);
        
        // Acción para generar secuencia aleatoria
        randomButton.addActionListener(e -> generateRandomSequence());

        // Acción del botón de simulación
        simulateButton.addActionListener(e -> new Thread(this::simulateLRU).start());
    }
    
    private void generateRandomSequence() {
        Random random = new Random();
        int sequenceLength = random.nextInt(10) + 5; // Longitud aleatoria entre 5 y 15
        StringBuilder sequence = new StringBuilder();

        for (int i = 0; i < sequenceLength; i++) {
            sequence.append(random.nextInt(9) + 1); // Números entre 1 y 9
            if (i < sequenceLength - 1) {
                sequence.append(",");
            }
        }

        pagesField.setText(sequence.toString());
    }
    
    private void simulateLRU(){
        try{
            int numFrames = Integer.parseInt(framesField.getText().trim());
            if (numFrames <= 0) {
                resultArea.setText("El número de marcos debe ser mayor a 0.");
                return;
            }
            
            String[] pagesInput = pagesField.getText().trim().split(",");
            int[] pages = new int[pagesInput.length];
            for (int i = 0; i < pagesInput.length; i++) {
                pages[i] = Integer.parseInt(pagesInput[i].trim());
            }
            
            // Configuración inicial de la tabla
            tableModel.setRowCount(numFrames);
            tableModel.setColumnCount(1);
            for (int i = 0; i < numFrames; i++) {
                tableModel.setValueAt("-", i, 0); // Inicializamos los marcos con "-"
            }

            List<Integer> frameList = new LinkedList<>(); // Lista para rastrear el orden de uso
            int pageFaults = 0;

            resultArea.setText(""); // Limpiamos resultados

            for (int page : pages) {
                if (!frameList.contains(page)) {
                    if (frameList.size() >= numFrames) {
                        int leastRecentlyUsed = frameList.remove(0); // Eliminamos la página menos recientemente usada
                        resultArea.append("Reemplazando página " + leastRecentlyUsed + "\n");
                        pageFaults++;
                    }
                    frameList.add(page);

                    // Actualizar la tabla
                    updateFrameTable(frameList, numFrames);

                    // Mostrar información en el área de texto
                    resultArea.append("Cargando página " + page + " en los marcos: " + frameList + "\n");
                } else {
                    // Página ya está en los marcos, actualizamos su orden
                    frameList.remove((Integer) page);
                    frameList.add(page);
                    resultArea.append("Página " + page + " accedida, actualizando su orden: " + frameList + "\n");
                }

                // Pausa para simular animación
                Thread.sleep(5000); // 1 segundo entre cada paso

                resultArea.append("\nTotal de fallos de página: " + pageFaults);                
            } 
        }catch (NumberFormatException ex) {
            resultArea.setText("Por favor, ingresa datos válidos.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    private void updateFrameTable(List<Integer> frameList, int numFrames) {
        for (int i = 0; i < numFrames; i++) {
            if (i < frameList.size()) {
                tableModel.setValueAt(frameList.get(i), i, 0);
            } else {
                tableModel.setValueAt("-", i, 0);
            }
        }
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(() -> {
            LRU frame = new LRU();
            frame.setVisible(true);
        });
    }
    
}
