/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.appshopheroes;

/**
 *
 * @author 52444
 */
public class AppShopHeroes {

    public static void main(String[] args) {
               Superheroe superman = new Superheroe("Superman");
        superman.setDescripcion("Superhéroe de traje azul y rojo");
        superman.setCapa(true);

        Superheroe batman = new Superheroe("Batman");
        batman.setDescripcion("Superhéroe vestido de negro con capa");
        batman.setCapa(true);

        // Crear dimensiones
        Dimension dimensionSuperman = new Dimension(20, 10, 5);
        Dimension dimensionBatman = new Dimension(18, 12, 6);

        // Crear figuras
        Figura figuraSuperman = new Figura("SUP001", 50.0, dimensionSuperman, superman);
        Figura figuraBatman = new Figura("BAT001", 75.0, dimensionBatman, batman);

        // Crear colección
        Coleccion coleccionSuperheroes = new Coleccion("DC Comics");
        coleccionSuperheroes.añadirFigura(figuraSuperman);
        coleccionSuperheroes.añadirFigura(figuraBatman);

        // Probar métodos
        System.out.println("Información de la Colección:");
        System.out.println(coleccionSuperheroes);

        System.out.println("\nFiguras con Capa:");
        System.out.println(coleccionSuperheroes.conCapa());

        System.out.println("\nFigura más Valiosa:");
        System.out.println(coleccionSuperheroes.masValioso());

        System.out.println("\nValor Total de la Colección: $" + coleccionSuperheroes.getValorColeccion());
        System.out.println("Volumen Total de la Colección: " + coleccionSuperheroes.getVolumenColeccion());

        // Subir precio de una figura
        coleccionSuperheroes.subirPrecio(10.0, "SUP001");
        System.out.println("\nPrecio de Superman después de subir: $" + figuraSuperman.getPrecio());
    }
}