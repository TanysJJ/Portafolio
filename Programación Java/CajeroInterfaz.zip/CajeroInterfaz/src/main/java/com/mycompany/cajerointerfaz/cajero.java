/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.cajerointerfaz;

/**
 *
 * @author 174177
 */
public class cajero extends javax.swing.JFrame {

    private int saldo = 10000;
    private int saldo2 = 15000;
    
    public cajero() {
        initComponents();
        
   
        total1.setText("" + saldo);
        total2.setText("" + saldo2);
        
         iniciarTransacciones();
    }
    
   
    public synchronized void retirarDinero(String nombre, int cantidad, int cajeroNum) {
        if (saldo >= cantidad) {
            try { Thread.sleep(100); } catch (InterruptedException e) {}
            saldo -= cantidad;
            total1.setText("" + saldo);
            
        
            switch (cajeroNum) {
                case 1:
                    C1cajero1.append(nombre + " ha retirado " + cantidad + "\n");
                    break;
                case 2:
                    C1cajero2.append(nombre + " ha retirado " + cantidad + "\n");
                    break;
                case 3:
                    C1cajero3.append(nombre + " ha retirado " + cantidad + "\n");
                    break;
            }
        } else {
            
            
   
            switch (cajeroNum) {
                case 1:
                    C1cajero1.append(nombre + " intentó retirar " + cantidad + " pero no hay suficiente saldo.\n");
                    break;
                case 2:
                    C1cajero2.append(nombre + " intentó retirar " + cantidad + " pero no hay suficiente saldo.\n");
                    break;
                case 3:
                    C1cajero3.append(nombre + " intentó retirar " + cantidad + " pero no hay suficiente saldo.\n");
                    break;
            }
        }
    }
    

    public synchronized void retirarDinero2(String nombre, int cantidad, int cajeroNum) {
        if (saldo2 >= cantidad) {
           
            try { Thread.sleep(100); } catch (InterruptedException e) {}
            saldo2 -= cantidad;
            
            total2.setText("" + saldo2);
            switch (cajeroNum) {
                case 1:
                    C2cajero1.append(nombre + " ha retirado " + cantidad + "\n");
                    break;
                case 2:
                    C2cajero2.append(nombre + " ha retirado " + cantidad + "\n");
                    break;
                case 3:
                    C2cajero3.append(nombre + " ha retirado " + cantidad + "\n");
                    break;
            }
        } else {
            
            switch (cajeroNum) {
                case 1:
                    C2cajero1.append(nombre + " intentó retirar " + cantidad + " de la cuenta 2 pero no hay suficiente saldo.\n");
                    break;
                case 2:
                    C2cajero2.append(nombre + " intentó retirar " + cantidad + " de la cuenta 2 pero no hay suficiente saldo.\n");
                    break;
                case 3:
                    C2cajero3.append(nombre + " intentó retirar " + cantidad + " de la cuenta 2 pero no hay suficiente saldo.\n");
                    break;
            }
        }
    }
    public void iniciarRetirosC1() {
   
    Runnable cajero1C1 = () -> {
        for (int i = 0; i < 17; i++) {
            retirarDinero("Cliente-C1-Cajero1", 200, 1);
            try { Thread.sleep(500); } catch (InterruptedException e) {}
        }
    };
    
   
    Runnable cajero2C1 = () -> {
        for (int i = 0; i < 17; i++) {
            retirarDinero("Cliente-C1-Cajero2", 200, 2);
            try { Thread.sleep(500); } catch (InterruptedException e) {}
        }
    };
    
    
    Runnable cajero3C1 = () -> {
        for (int i = 0; i < 17; i++) {
            retirarDinero("Cliente-C1-Cajero3", 200, 3);
            try { Thread.sleep(500); } catch (InterruptedException e) {}
        }
    };
    
  
    Thread t1 = new Thread(cajero1C1, "Cajero1-C1");
    Thread t2 = new Thread(cajero2C1, "Cajero2-C1");
    Thread t3 = new Thread(cajero3C1, "Cajero3-C1");
    
    
    t1.setPriority(5);       
    t2.setPriority(7);     
    t3.setPriority(9);       
    
   
    t1.start();
    t2.start();
    t3.start();
}

public void iniciarRetirosC2() {
 
    Runnable cajero1C2 = () -> {
        for (int i = 0; i < 50; i++) {
            retirarDinero2("Cliente-C2-Cajero1", 100, 1);
            try { Thread.sleep(500); } catch (InterruptedException e) {}
        }
    };
    
   
    Runnable cajero2C2 = () -> {
        for (int i = 0; i < 50; i++) {
            retirarDinero2("Cliente-C2-Cajero2", 100, 2);
            try { Thread.sleep(500); } catch (InterruptedException e) {}
        }
    };
    
    
    Runnable cajero3C2 = () -> {
        for (int i = 0; i < 50; i++) {
            retirarDinero2("Cliente-C2-Cajero3", 100, 3);
            try { Thread.sleep(500); } catch (InterruptedException e) {}
        }
    };
    
   
    Thread t1 = new Thread(cajero1C2, "Cajero1-C2");
    Thread t2 = new Thread(cajero2C2, "Cajero2-C2");
    Thread t3 = new Thread(cajero3C2, "Cajero3-C2");

    t1.setPriority(1);       
    t2.setPriority(3);     
    t3.setPriority(2);     
    
    // Iniciar los hilos
    t1.start();
    t2.start();
    t3.start();
}
    public void iniciarTransacciones() {
      
        C1cajero1.setText("");
        C1cajero2.setText("");
        C1cajero3.setText("");
        C2cajero1.setText("");
        C2cajero2.setText("");
        C2cajero3.setText("");
        iniciarRetirosC1();
        iniciarRetirosC2();
    }
    
    private void verificarTextAreas() {
    if (C1cajero1 == null) {
        C1cajero1 = new javax.swing.JTextArea();
        C1cajero1.setColumns(20);
        C1cajero1.setRows(5);
        jScrollPane9.setViewportView(C1cajero1);
        
    }
    
    if (C1cajero2 == null) {
        C1cajero2 = new javax.swing.JTextArea();
        C1cajero2.setColumns(20);
        C1cajero2.setRows(5);
        jScrollPane11.setViewportView(C1cajero2);
        
    }
    
    if (C1cajero3 == null) {
        C1cajero3 = new javax.swing.JTextArea();
        C1cajero3.setColumns(20);
        C1cajero3.setRows(5);
        jScrollPane10.setViewportView(C1cajero3);
        
    }
    
    if (C2cajero1 == null) {
        C2cajero1 = new javax.swing.JTextArea();
        C2cajero1.setColumns(20);
        C2cajero1.setRows(5);
        jScrollPane7.setViewportView(C2cajero1);
        
    }
    
    if (C2cajero2 == null) {
        C2cajero2 = new javax.swing.JTextArea();
        C2cajero2.setColumns(20);
        C2cajero2.setRows(5);
        jScrollPane4.setViewportView(C2cajero2);
        
    }
    
    if (C2cajero3 == null) {
        C2cajero3 = new javax.swing.JTextArea();
        C2cajero3.setColumns(20);
        C2cajero3.setRows(5);
        jScrollPane8.setViewportView(C2cajero3);
        
    }
    C1cajero1.append("Prueba de escritura en C1cajero1\n");
    C1cajero2.append("Prueba de escritura en C1cajero2\n");
    C1cajero3.append("Prueba de escritura en C1cajero3\n");
    C2cajero1.append("Prueba de escritura en C2cajero1\n");
    C2cajero2.append("Prueba de escritura en C2cajero2\n");
    C2cajero3.append("Prueba de escritura en C2cajero3\n");
    
    C1cajero1.repaint();
    C1cajero2.repaint();
    C1cajero3.repaint();
    C2cajero1.repaint();
    C2cajero2.repaint();
    C2cajero3.repaint();
}
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane4 = new javax.swing.JScrollPane();
        C2cajero2 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        total1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        retiro1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        total2 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        C2cajero1 = new javax.swing.JTextArea();
        jScrollPane8 = new javax.swing.JScrollPane();
        C2cajero3 = new javax.swing.JTextArea();
        jScrollPane9 = new javax.swing.JScrollPane();
        C1cajero1 = new javax.swing.JTextArea();
        jScrollPane10 = new javax.swing.JScrollPane();
        C1cajero3 = new javax.swing.JTextArea();
        jScrollPane11 = new javax.swing.JScrollPane();
        C1cajero2 = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        C2cajero2.setColumns(20);
        C2cajero2.setRows(5);
        C2cajero2.setMinimumSize(new java.awt.Dimension(100, 100));
        C2cajero2.setSelectionColor(new java.awt.Color(204, 204, 255));
        jScrollPane4.setViewportView(C2cajero2);

        jLabel1.setText("Cajero 1");

        jLabel2.setText("Cajero 2");

        jLabel3.setText("Cajero 3");

        jLabel4.setBackground(new java.awt.Color(255, 204, 204));
        jLabel4.setText("Cajero 1");

        jLabel5.setBackground(new java.awt.Color(255, 204, 204));
        jLabel5.setText("Cajero 2");

        jLabel6.setBackground(new java.awt.Color(255, 204, 204));
        jLabel6.setText("Cajero 3");

        jLabel7.setBackground(new java.awt.Color(204, 204, 255));
        jLabel7.setText("Cuenta 1");

        total1.setBackground(new java.awt.Color(153, 204, 255));
        total1.setText("             ");

        jLabel9.setBackground(new java.awt.Color(204, 204, 255));
        jLabel9.setText("Retiro");

        retiro1.setText("200");

        jLabel8.setBackground(new java.awt.Color(255, 204, 204));
        jLabel8.setText("Cuenta 2");

        total2.setBackground(new java.awt.Color(153, 204, 255));
        total2.setText("                    ");

        jLabel11.setBackground(new java.awt.Color(255, 204, 204));
        jLabel11.setText("Retiro");

        jLabel12.setBackground(new java.awt.Color(255, 204, 204));
        jLabel12.setText("100");

        C2cajero1.setColumns(20);
        C2cajero1.setRows(5);
        C2cajero1.setMinimumSize(new java.awt.Dimension(100, 100));
        C2cajero1.setSelectionColor(new java.awt.Color(204, 204, 255));
        jScrollPane7.setViewportView(C2cajero1);

        C2cajero3.setColumns(20);
        C2cajero3.setRows(5);
        C2cajero3.setMinimumSize(new java.awt.Dimension(100, 100));
        C2cajero3.setSelectionColor(new java.awt.Color(204, 204, 255));
        jScrollPane8.setViewportView(C2cajero3);

        C1cajero1.setColumns(20);
        C1cajero1.setRows(5);
        C1cajero1.setMinimumSize(new java.awt.Dimension(100, 100));
        C1cajero1.setSelectionColor(new java.awt.Color(204, 204, 255));
        jScrollPane9.setViewportView(C1cajero1);

        C1cajero3.setColumns(20);
        C1cajero3.setRows(5);
        C1cajero3.setMinimumSize(new java.awt.Dimension(100, 100));
        C1cajero3.setSelectionColor(new java.awt.Color(204, 204, 255));
        jScrollPane10.setViewportView(C1cajero3);

        C1cajero2.setColumns(20);
        C1cajero2.setRows(5);
        C1cajero2.setMinimumSize(new java.awt.Dimension(100, 100));
        C1cajero2.setSelectionColor(new java.awt.Color(204, 204, 255));
        jScrollPane11.setViewportView(C1cajero2);

        jLabel10.setText("Prioridad 5");

        jLabel13.setText("prioridad 7");

        jLabel14.setText("prioridad 9");

        jLabel15.setText("prioridad 1");

        jLabel16.setText("prioridad 3");

        jLabel17.setText("prioridad 2");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(111, 111, 111)
                                        .addComponent(jLabel1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel4)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel8)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(total2)
                                                .addGap(37, 37, 37)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel11)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel12))
                                            .addComponent(jLabel15))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(121, 121, 121)
                                        .addComponent(jLabel2)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(187, 187, 187)
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel14))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(92, 92, 92)
                                        .addComponent(jLabel5)
                                        .addGap(31, 31, 31)
                                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(92, 92, 92)
                                        .addComponent(jLabel6)
                                        .addGap(49, 49, 49)
                                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(total1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(retiro1)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(total1)
                            .addComponent(jLabel9)
                            .addComponent(retiro1)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1)
                            .addComponent(jLabel10)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(total2)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel15)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(63, 63, 63))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(cajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(cajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(cajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(cajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new cajero().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea C1cajero1;
    private javax.swing.JTextArea C1cajero2;
    private javax.swing.JTextArea C1cajero3;
    private javax.swing.JTextArea C2cajero1;
    private javax.swing.JTextArea C2cajero2;
    private javax.swing.JTextArea C2cajero3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel retiro1;
    private javax.swing.JLabel total1;
    private javax.swing.JLabel total2;
    // End of variables declaration//GEN-END:variables
}
