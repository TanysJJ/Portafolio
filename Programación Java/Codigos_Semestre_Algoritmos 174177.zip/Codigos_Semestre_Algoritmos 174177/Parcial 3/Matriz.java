
public class Matriz <E>{
	
    public static void main (String args[] ){
	int p[]= {30, 35, 15, 5, 10, 20, 25 }; 
	Par<int[][],int[][]> ar;
	ar= chainOrder(p);		
	System.out.println(printOptimalParens( ar.snd, 1, 6));
			
    } 
	
	
    public static Par<int[][],int[][]> chainOrder(int p []){
	int n = p.length - 1;
	int m[][] = new int[n+1][n+1];
	int s[][] = new int [n+1][n+1];
        int q = 0;
	for(int i = 1; i<=n; i++){
            m[i][i] = 0; 
	}
	for(int l = 2; l<=n; l++){
            for(int i = 1; i<=n-l+1; i++){
		int j = i + l - 1;
		m[i][j] = Integer.MAX_VALUE;
		for(int k = i; k<=j-1; k++){
                    q = m[i][k] + m[k+1][j] + (p[i-1]*p[k]*p[j]);
                    if(q<m[i][j]){
			m[i][j] = q;
			s[i][j] = k;
                    }     
		} 
            }
	}
	return new Par<int[][], int[][]>(m,s);
    }
	
    public static String printOptimalParens(int s[][], int i,int j){
	if(i==j){
            return "A"+i;
	}else{
            return "(" + printOptimalParens(s,i,s[i][j]) +printOptimalParens(s,s[i][j]+1,j) +")";
        }
    }
    public Matrix() {
    }
    
    
}

class Par<S,T> {
	public S fst;
	public T snd;
	
	public Par(S s, T t) {
		fst = s;
		snd = t;
	}
}


//--------------------------------------------------------------------------------------------------------------------------


public class MatrixChainMultiplication {
    public static int[][] matrixChainOrder(int[] p) {
        int n = p.length - 1;
        int[][] m = new int[n + 1][n + 1]; 
        int[][] s = new int[n + 1][n + 1]; 
       
        for (int i = 1; i <= n; i++) {
            m[i][i] = 0;
        }
        [cite_start]
        for (int l = 2; l <= n; l++) {
            for (int i = 1; i <= n - l + 1; i++) {
                int j = i + l - 1;
                m[i][j] = Integer.MAX_VALUE;
                for (int k = i; k <= j - 1; k++) {
                    [cite_start]
                    int cost = p[i - 1] * p[k] * p[j];
                    [cite_start]
                    int q = m[i][k] + m[k + 1][j] + cost;
                    if (q < m[i][j]) {
                        m[i][j] = q;
                        s[i][j] = k;
                    }
                }
            }
        }
        return s;
    }
    public static void printOptimalParens(int[][] s, int i, int j) {
        if (i == j) {
            System.out.print("A" + i);
        } else {
            System.out.print("(");
            printOptimalParens(s, i, s[i][j]);
            printOptimalParens(s, s[i][j] + 1, j);
            System.out.print(")");
        }
    }
    private static void printMatrix(int[][] matrix, String name) {
        System.out.println("\n--- " + name + " ---");
        for (int i = 1; i < matrix.length; i++) {
            for (int j = 1; j < matrix[i].length; j++) {
                if (i <= j) {
                    System.out.printf("%8d ", matrix[i][j]);
                } else {
                    System.out.print("         ");
                }
            }
            System.out.println();
        }
    }

}