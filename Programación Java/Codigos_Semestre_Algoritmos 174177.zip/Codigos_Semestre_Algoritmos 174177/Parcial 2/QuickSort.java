public class QuickSort<E extends Comparable<E>> {
    
    private void exchange(E A[], int i, int j) {
        E t = A[i]; 
        A[i] = A[j]; 
        A[j] = t; 
    
    public void quickSort(E A[], int p, int r){
        if(p<r){
            int q = partition(A,p,r); 
            quickSort(A,p,q-1); 
            quickSort(A,q+1,r); 
        }
    }
    
    public int partition(E A[], int p, int r){
        E x = A[r];
        int i = p-1;
        for(int j=p; j<r; j++){
            if(A[j].compareTo(x)<=0){
                i = i + 1; 
                exchange(A, i, j); 
            }
        }
        exchange(A, i+1, r);
        return i+1;
    }
    
    public static void main(String[] args) {
        Integer A[] = {3,2,9,0,7,5,4,8,6,1};
        QuickSort quick = new QuickSort();
        quick.quickSort(A, 0, 3);
        for(int x: A)
            System.out.println(x);
    }
}
