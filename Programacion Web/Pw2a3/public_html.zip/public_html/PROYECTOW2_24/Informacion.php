<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/x-icon" href="logo3.png">
    <title>CapacitaT</title>
    <link rel="stylesheet" href="pfw2.css">
</head>

<body>
   
<header>
  <nav class="menu">
    <ul class="menu-list">
      <li><a href="inicio.php">Inicio</a></li>
      <li>
        <a href="Informacion.php">Sobre Nosotros</a>
      </li>
      <li class="dropdown">
        <a href="#">Cursos</a>
        <ul class="dropdown-menu">
          <li><a href="#">Servicio 1</a></li>
          <li><a href="#">Servicio 2</a></li>
          <li><a href="#">Servicio 3</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Soporte</a>
      <ul class="dropdown-menu">
          <li><a href="#">Equipo</a></li>
          <li><a href="#">Historia</a></li>
          <li><a href="#">Misión y Visión</a></li>
        </ul>
    </li>
    <li><a href="#">Contacto</a></li>
    </ul>
  </nav>
  <div class="logo-container">
    <img src="logo.jpg" alt="Logo de CapacitaT">
  </div>
</header>

    <main>
    <div class="carousel">
     <div class="carousel-container">
    <div class="carousel-slide slide1 active">
      <h2>Origen</h2>
      <p>Descripción del primer slide.</p>
    </div>
    <div class="carousel-slide slide2">
      <h2>Bases</h2>
      <p>Descripción del segundo slide.</p>
    </div>
    <div class="carousel-slide slide3">
      <h2>Historia</h2>
      <p>Descripción del tercer slide.</p>
    </div>
    <div class="carousel-slide slide4">
      <h2>Objetivo</h2>
      <p>Descripción del tercer slide.</p>
    </div>
  </div>
  <button class="carousel-prev">&#10094;</button>
  <button class="carousel-next">&#10095;</button>
</div> 

    </main>

    <footer>
        <p>DESARROLLADORA JIMENEZ JUAREZ TANYA</p>
    </footer>
    <script src="carrusel.js"></script>
</body>
</html>
