<!DOCTYPE html>
<html>
<head>
    <style>
         body {
            
            background-image: url('skzoo2.jpg');
            background-attachment: fixed;
            background-size: 100% 100%;
        }
        
            .recuadro {
            display: flex;
            flex-direction: column; 
            justify-content: center;
            align-items: center;
            
            width: 80%; 
            height: 80vh; 
            margin: 0 auto; 
            border: 1px solid black;
            background-color: rgba(255, 255, 255, 0.7); 
            text-align: center; 
        }
        
        .recuadro label {
            font-weight: bold;
        }
    </style>
</head>
<body>



<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $numeroCasa = $_POST['nc'];
        $cp = $_POST['cp'];
        $contrasena = $_POST['pwd'];
        $email = $_POST['email'];
        $fechaNacimiento = $_POST['FN'];
        $nombre = $_POST['nombre'];
        $apellidoPaterno = $_POST['AP'];
        $apellidoMaterno = $_POST['AM'];
        $nombreUsuario = $_POST['nomuser'];
        $calle = $_POST['calle'];
        $colonia = $_POST['col'];
        $rfc = $_POST['rfc'];
        $pai = $_POST['pais'];
        $ciuda =$_POST['ciudad'];

        echo "<div class='recuadro'>";

        echo "<label>Nombre:</label> " . htmlspecialchars($nombre) . "<br>";

        echo "<label>Apellido Paterno:</label> " . htmlspecialchars($apellidoPaterno). "<br>";

        echo "<label>Apellido Materno:</label>" .  htmlspecialchars($apellidoMaterno) . "<br>";

        echo "<label>Nombre de usuario:</label>" . htmlspecialchars($nombreUsuario) . "<br>";

        echo "<label>Contraseña:</label> " .  htmlspecialchars($contrasena) . "<br>";

        echo "<label>Fecha de nacimiento:</label> " .  htmlspecialchars($fechaNacimiento) . "<br>";

        echo "<label>País:</label>". htmlspecialchars($pai)."<br>";

        echo "<label>Ciudad</label>". htmlspecialchars($ciuda)."<br>";

        echo "<label>Calle:</label>" .  htmlspecialchars($calle) . "<br>";

        echo "<label>Número de casa:</label>" . htmlspecialchars($numeroCasa). "<br>";

        echo "<label>Colonia:</label>" .  htmlspecialchars($colonia) . "<br>";

        echo "<label>E-mail:</label>" .  htmlspecialchars($email). "<br>";
        
        echo "<label>RFC:</label>" .  htmlspecialchars($rfc) . "<br>";

        echo "<label>CP:</label>" .  htmlspecialchars($cp). "<br>";

        echo "</div>";
    }
?>

</body>
</html>