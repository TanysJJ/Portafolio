package arbolesrojinegros;

import java.util.*;

public class ArbolesRojiNegros<T extends Comparable<T>> {

    
    private static final boolean RED = true;
    private static final boolean BLACK = false;

    nodoTree<Integer> arbolroot;
    
   
    public static void main(String[] args) {

        Random random = new Random();
        int comparaciones = 0;
        int minArboles = 1000;
        int maxArboles = 35000;
        int paso = 1000;

        for (int i = minArboles; i <= maxArboles; i += paso) {
            ArbolesRojiNegros<Integer> arbol = new ArbolesRojiNegros<>();

            int numInserciones = random.nextInt(50000) + 1000; //Crea inserciones entre 50000 a 1000 nodos.

            for (int j = 0; j < numInserciones; j++) {
                int valor = random.nextInt(1000); // Numeros aleatorios para llenar los nodos del arbol.
                arbol.RBInsert(valor);
            }
            comparaciones += contarComparaciones(arbol.arbolroot);
            System.out.println((i) + "-" + comparaciones);
        }
    }

    private static int contarComparaciones(nodoTree<Integer> x) {
        if (x == null) {
            return 0;
        }

        int comparacionesIzquierda = contarComparaciones(x.left);
        int comparacionesDerecha = contarComparaciones(x.right);

        return comparacionesIzquierda + comparacionesDerecha + 1;
    }

    public void inOrderTreeWalk(nodoTree x) {
        if (x != null) {
            inOrderTreeWalk(x.left);
            System.out.println(x.key + " ");
            inOrderTreeWalk(x.right);
        }
    }

    //------------------FUNCIONES PARA INSERCION DE NODOS EN EL ARBOL ROJINEGRO----------------------------------------------
   public void RBInsert(T key) {
    nodoTree z = new nodoTree(key); 
    z.color = RED;
    nodoTree y = null;
    nodoTree x = arbolroot; 
    while (x != null) {
        y = x;
        if (z.key.compareTo(x.key) < 0) {
            x = x.left;
        } else {
            x = x.right;
        }
    }

    z.parent = y;
    if (y == null) {
        arbolroot = z; 
    } else if (z.key.compareTo(y.key) < 0) {
        y.left = z;
    } else {
        y.right = z;
    }
    
    z.left = null;
    z.right = null;
    z.color = RED;
    
    RBInsertFixup(z);
}

    public void RBInsertFixup(nodoTree z) {
    while (z.parent != null && z.parent.color == RED) {
        if (z.parent == z.parent.parent.left) {
            nodoTree y = z.parent.parent.right;
            if (y != null && y.color == RED) {
                
                z.parent.color = BLACK;
                y.color = BLACK;
                z.parent.parent.color = RED;
                z = z.parent.parent;
            } else {
                
                if (z == z.parent.right) {
                    z = z.parent;
                    leftRotate(z);
                }
                
                z.parent.color = BLACK;
                z.parent.parent.color = RED;
                rightRotate(z.parent.parent);
            }
        } else {
            
            nodoTree y = z.parent.parent.left;
            if (y != null && y.color == RED) {
                
                z.parent.color = BLACK;
                y.color = BLACK;
                z.parent.parent.color = RED;
                z = z.parent.parent;
            } else {
                
                if (z == z.parent.left) {
                    z = z.parent;
                    rightRotate(z);
                }
               
                z.parent.color = BLACK;
                z.parent.parent.color = RED;
                leftRotate(z.parent.parent);
            }
        }
    }
   
    arbolroot.color = BLACK;
}

    public void leftRotate(nodoTree x) {
        nodoTree y = x.right;  
        x.right = y.left;       
        if (y.left != null) {
            y.left.parent = x;  
        }
        y.parent = x.parent;   
        if (x.parent == null) {
            arbolroot = y;      
        } else if (x == x.parent.left) {
            x.parent.left = y; 
        } else {
            x.parent.right = y; 
        }
        y.left = x; 
        x.parent = y; 
    }

    public void rightRotate(nodoTree x) {
        nodoTree y = x.left;
        x.left = y.right;
        if (y.right != null) {
            y.right.parent = x;
        }
        y.parent = x.parent;
        if (x.parent == null) {
            arbolroot = y;
        } else if (x == x.parent.left) {
            x.parent.left = y;
        } else {
            x.parent.right = y;
        }
        y.right = x;
        x.parent = y;
    }

    //--------------------------------FUNCIONES DELETE DE ARBOLES ROJINEGROS----------------------
    public void RBTransplant(nodoTree u, nodoTree v) {
        if (u.parent == null) {
            arbolroot = v;
        } else if (u == u.parent.left) {
            u.parent.left = v;
        } else {
            u.parent.right = v;
        }
        if (v != null) {
            v.parent = u.parent;
        }
    }

    public void RBDelete(nodoTree z) {
        nodoTree y = z;
        nodoTree x;
        boolean yOriginalColor = y.color;

        if (z.left == null) {
            x = z.right;
            RBTransplant(z, z.right);
        } else if (z.right == null) {
            x = z.left;
            RBTransplant(z, z.left);
        } else {
            y = treeMinimum(z.right);
            yOriginalColor = y.color;
            x = y.right;

            if (y.parent == z) {
                x.parent = y;
            } else {
                RBTransplant(z, y.right);
                y.right = z.right;
                y.right.parent = y;
            }
            RBTransplant(z, y);
            y.left = z.left;
            y.left.parent = y;
            y.color = z.color;
        }
        if (yOriginalColor == BLACK) {
            RBDeleteFixup(x, arbolroot);
        }

    }

    public void RBDeleteFixup(nodoTree<T> x, nodoTree arbolroot) {
        while (x != null && x != arbolroot && x.color == BLACK) {
            if (x == x.parent.left) {
                nodoTree<T> w = x.parent.right;
                if (w.color == RED) {             
                    w.color = BLACK;
                    x.parent.color = RED;
                    leftRotate(x.parent);
                    w = x.parent.right;
                }
                if (w.left.color == BLACK && w.right.color == BLACK) {
                    w.color = RED;              
                    x = x.parent;               
                } else {
                    if (w.right.color == BLACK) {
                        w.left.color = BLACK;   
                        w.color = RED;
                        rightRotate(w);
                        w = x.parent.right;
                    }
                    w.color = x.parent.color;   
                    x.parent.color = BLACK;
                    w.right.color = BLACK;
                    leftRotate(x.parent);
                    x = arbolroot;
                }
            } else {
                
                nodoTree<T> w = x.parent.left;
                if (w.color == RED) {            
                    w.color = BLACK;
                    x.parent.color = RED;
                    leftRotate(x.parent);
                    w = x.parent.left;
                }
                if (w.right.color == BLACK && w.left.color == BLACK) {
                    w.color = RED;              
                    x = x.parent;               
                } else {
                    if (w.left.color == BLACK) {
                        w.right.color = BLACK;   
                        w.color = RED;
                        leftRotate(w);
                        w = x.parent.left;
                    }
                    w.color = x.parent.color;   
                    x.parent.color = BLACK;
                    w.left.color = BLACK;
                    rightRotate(x.parent);
                    x = arbolroot;
                }
            }
        }
        if (x != null) {
            x.color = BLACK;
        }
    }

    //------------------------------Funciones maximos y minimos-------------------------------------
    public nodoTree<T> treeMinimum(nodoTree x) {
        while (x.left != null) {
            x = x.left;
        }
        return x;
    }

    public nodoTree<T> treeMaximum(nodoTree x) {
        while (x.right != null) {
            x = x.right;
        }
        return x;
    }

    //---------------------------Funciones para buscar----------------------------------------------
    public nodoTree<T> treeSearch(nodoTree<T> x, T key) {
        if (x == null || key.compareTo(x.key) == 0) {
            return x;
        }

        if (key.compareTo(x.key) < 0) {
            return treeSearch(x.left, key);
        } else {
            return treeSearch(x.right, key);
        }
    }

    //--------------------------FUNCIONES SUCESSOR Y PREDECESSOR------------------------
    public nodoTree<T> treeSuccessor(nodoTree<T> x) {
        if (x.right != null) {
            return treeMinimum(x.right);
        }

        nodoTree<T> y = x.parent;
        while (y != null && x == y.right) {
            x = y;
            y = y.parent;
        }

        return y;
    }

    public nodoTree<T> treePredecessor(nodoTree<T> x) {
        if (x.left != null) {
            return treeMaximum(x.left);
        }

        nodoTree<T> y = x.parent;
        while (y != null && x == y.left) {
            x = y;
            y = y.parent;
        }

        return y;
    }

}
