/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestionempleados;

/**
 *
 * @author 52444
 */
public class Desarrollador extends Empleado {
    String lenguajeProgramacion;
    
    public Desarrollador(String nombre, double salario, String lenguajeProgramacion) {
        super(nombre, salario);
        this.lenguajeProgramacion = lenguajeProgramacion;
    }
    
    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Lenguaje de programacion: " + lenguajeProgramacion);
    }
    
    @Override
    public void trabajar() {
        System.out.println("Desarrolla codigo en " + lenguajeProgramacion);
    }
}
