<!DOCTYPE html>
<html>

<head>
    <title>Alta de registros</title>
    <meta charset="utf-8">
    <link rel="icon" type="image/x-icon" href="skzoo2.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Protest+Revolution&family=Protest+Riot&family=Roboto&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="skzoo2.jpg">
    <link rel="stylesheet" href="pract3p2.css">

    <style>
        .boton-inicio {
            background-color: #4560ab;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 12px;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        input[type="password"],
        input[type="email"],
        select {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            box-sizing: border-box;
            border: none;
            background-color: #f8f8f8;
            font-size: 16px;
        }

        input[type="submit"],
        input[type="reset"] {
            width: 90%;
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: auto 60px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>

</head>

<body>
    <header>
        <h1>Practica 3: Alta de Registros</h1>
    </header>
    <div class="container">
        <main>
            <section>
                <div class="grid">
                    <div>
                        <form action="regisp3p2.php" method="post">
                            <fieldset>
                                <legend>Ingresar datos del producto</legend><br><br>

                                <label for="folio">Folio del prodcuto</label><br>
                                <input type="text" name="folio" placeholder="Folio" required><br><br>

                                <label for="Nombre">Nombre del producto</label><br>
                                <input type="text" name="nombre" placeholder="Producto" required><br><br>

                                <label for="existe">Existencias del producto</label><br>
                                <input type="text" name="existe" placeholder="Existencia" required><br><br>

                                <label for="precio">Precio del producto</label><br>
                                <input type="text" name="precio" placeholder="Precio" required><br><br>


                                <label for="costo">Costo del producto</label><br>
                                <input type="text" name="costo" placeholder="Costo" required><br><br>


                                <input type="submit" name="enviar" value="Registrar"><br><br><br>
                                <input type="reset" value="Restablecer"><br>
                        </form>
                        </fieldset>
                    </div>
                    <div>
                        <form method="post" action="listaProdu.php">
                            <fieldset>
                                <legend>Mostrar todos los registros</legend><br><br>
                                <input type="submit" value="Mostrar todo"><br><br>
                            </fieldset>
                    </div>
                    </form>
                </div>
    </div>
    </section>
    </main>
    </div>

    <div class="bg"></div>
    <div class="bg bg2"></div>
    <div class="bg bg3"></div>
    <div class="content">
        <footer>
            <p>Jimenez Juarez Tanya 174177</p>
            <button class="boton-inicio" onclick="goBack()">Regresar</button></a>
        </footer>

        <script>
            function goBack() {
                window.history.back();
            }
        </script>


</body>

</html>