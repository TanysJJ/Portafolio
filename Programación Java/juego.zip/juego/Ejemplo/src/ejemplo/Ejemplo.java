/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo;


public class Ejemplo {

   
    public static void main(String[] args) {
          datos objDatos = new datos();
          
          new menu(objDatos).setVisible(true);
     
    }
    
}
