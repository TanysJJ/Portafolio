<!DOCTYPE html>
<html>

<head>
    <title>Actualizacion de datos</title>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body>
    <h1>Actualizar gados clientes clientes</h1>
    <div>
        <div>
            <form id="form1" method="post" action="mostrarall.php">
                Mostrar usuarios<br>
                <input type="submit" value="Mostrar clientes registrados"><br>

            </form>
            <form id="form2" method="post" action="#">
                
                <input type="submit" value="-"><br>
            </form>
            <form id="form3" method="post" action="#">
                <input type="submit" value="-"><br>
            </form>

        </div>
        <div id="dataContainer"></div>

    </div>
    <script>
        $(document).ready(function() {
            $('#form1 input[type="submit"]').click(function(e) {
                e.preventDefault();

                $.ajax({
                    url: 'mostrarall.php',
                    method: 'post',
                    success: function(data) {
                        $('#dataContainer').html(data);
                    }
                });
            });

            $('#form2 input[type="submit"]').click(function(e) {
                e.preventDefault();

                var id = $('#form2 input[name="id"]').val();

                $.ajax({
                    url: '#',
                    method: 'post',
                    data: {
                        id: id
                    },
                    success: function(data) {
                        $('#dataContainer').html(data);
                    }
                });
            });

            $('#form3 input[type="submit"]').click(function(e) {
                e.preventDefault();

                $.ajax({
                    url: 'buscargoogle.php',
                    method: 'post',
                    success: function(data) {
                        $('#dataContainer').html(data);
                    }
                });
            });

            $('#form4 input[type="submit"]').click(function(e) {
                e.preventDefault();

                $.ajax({
                    url: '#',
                    method: 'post',
                    success: function(data) {
                        $('#dataContainer').html(data);
                    }
                });
            });


        });
    </script>


</body>

</html>