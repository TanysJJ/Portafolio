/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo;

import java.util.ArrayList;


public class datos {
    private ArrayList<jugador> jugadores;
     private int personajeSeleccionado = -1;
    public datos() {
        this.jugadores = new ArrayList<>();
    }
    
     public void prueba(){
        //System.out.println("Probando");
    }
    
    public int buscarJugador(String user, String pass){
        /*
        for (int i = 0; i < this.jugadores.size(); i++) {
            this.jugadores.get(i).getUser();
        }
        */
        for(jugador j : this.jugadores){// se crea una variable del tipo de dato que es array que es tipo jugador 
            if (j.getUser().equals(user)) {
                if (j.getPass().equals(pass)) {
                    return this.jugadores.indexOf(j);
                }else{
                    return -1;
                }
                
            }
            
        }
        
        return -2;
    }
    public void agregaJugador(jugador objJugador) {
        this.jugadores.add(objJugador);
    }
    public ArrayList<jugador> getJugadores() {
        return jugadores;
    }
    
    public int getPersonajeSeleccionado() {
        return personajeSeleccionado;
    }
    
    public void setPersonajeSeleccionado(int personajeSeleccionado) {
        this.personajeSeleccionado = personajeSeleccionado;
    }
}
