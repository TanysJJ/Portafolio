/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fisiogympf;

import java.util.ArrayList;


public class datosC {
    private ArrayList<citas>cita;
    
    public datosC(){
        this.cita = new ArrayList();
    }
    
    public void agregarCita(citas objCita){
        this.cita.add(objCita);
    }
    
    public ArrayList<citas> getCitas(){
        return cita;
    }
}
