/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tienda;

/**
 *
 * @author 52444
 */
public class Tienda {

    public static void main(String[] args) {
        Producto P1 = new TelefonoMovil("Galaxy A54","Smasung",10000);
        Producto P2 = new Computadora("Matebook D15","Huawei",15000);
        Producto P3 = new Tableta("Galaxy Tab S10","Samsung",23000);
        
        
        P1.calcularPrecioFinal();
        P1.mostrarInfo();
        
        P2.calcularPrecioFinal();
        P2.mostrarInfo();
        
        P3.calcularPrecioFinal();
        P3.mostrarInfo();
        
        
        
    }
}