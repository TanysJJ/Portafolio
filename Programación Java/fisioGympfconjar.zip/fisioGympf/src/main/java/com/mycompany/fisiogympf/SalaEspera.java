/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fisiogympf;

/**
 *
 * @author Alice
 */
import java.util.LinkedList;
import java.util.Queue;

public class SalaEspera {
    private Queue<String> pacientesEnEspera;
    public static final int CAPACIDAD_MAXIMA = 10;

    public SalaEspera() {
        pacientesEnEspera = new LinkedList<>();
    }

    public boolean agregarPaciente(String paciente) {
        if (pacientesEnEspera.size() < CAPACIDAD_MAXIMA) {
            pacientesEnEspera.add(paciente);
            return true;
        }
        return false;
    }

    public String siguientePaciente() {
        return pacientesEnEspera.poll();
    }

    public boolean hayEspacio() {
        return pacientesEnEspera.size() < CAPACIDAD_MAXIMA;
    }

    public int pacientesEnEspera() {
        return pacientesEnEspera.size();
    }
}