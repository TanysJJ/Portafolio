<!DOCTYPE html>
<html>

<head>
    <title>Listado de registros</title>
    <meta charset="utf-8">
    <link rel="icon" type="image/x-icon" href="skzoo2.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Protest+Revolution&family=Protest+Riot&family=Roboto&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="icon" type="image/x-icon" href="skzoo2.jpg">
    <link rel="stylesheet" href="pract4p2.css">

    <style>
        .boton-inicio {
            background-color: #4560ab;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 12px;
        }

        button[id="mostrarTodo"] {
            width: 90%;
            background-color: #927BEC;
            color: white;
            padding: 14px 20px;
            margin: auto 60px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button[id="mostrarTodo"]:hover {
            background-color: #8B7ACC;
        }

        label {
            font-size: 20px;
            font-family: Arial, sans-serif;
        }
    </style>
</head>

<body>
    <header>
        <h1>Practica 4: Listado de Productos</h1>
    </header>
    <div class="container">
        <main>
            <section>
                <div class="grid">
                    <div>

                        <label>Mostrar todos los registros</label><br><br>
                        <button id="mostrarTodo">Mostrar todo</button><br><br>

                        <br><br><br><br>
                        <div id="registros">

                        </div>

                    </div>
                </div>
            </section>
        </main>
    </div>
    <div class="bg"></div>
    <div class="bg bg2"></div>
    <div class="bg bg3"></div>
    <div class="content">
    <footer>
            <p>Jimenez Juarez Tanya 174177</p>
            <button class="boton-inicio" onclick="goBack()">Regresar</button></a>
        </footer>

        <script>
            function goBack() {
                window.history.back();
            }
        </script>

    <script>
        $(document).ready(function() {
            $('#mostrarTodo').click(function() {
                $.ajax({
                    url: 'listaProdu.php',
                    type: 'POST',
                    success: function(response) {
                        $('#registros').html(response);
                    }
                });
            });
        });
    </script>
</body>

</html>