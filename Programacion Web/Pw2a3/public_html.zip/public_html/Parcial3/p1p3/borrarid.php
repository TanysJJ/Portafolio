<?php
$conexion=mysqli_connect("localhost","id21895581_prograweb2","bd1Web2%","id21895581_bd1wb2") or die("Problemas en la conexion");

// Verificar si se recibió un ID válido
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // Eliminar el registro de la base de datos
    $query = "DELETE FROM clientes WHERE id = $id";
    mysqli_query($conexion, $query) or die(mysqli_error($conexion));

    echo "¡Registro eliminado exitosamente!";
} else {
    echo "ID de registro no válido.";
}

mysqli_close($conexion);
?>
