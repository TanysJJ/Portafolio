/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gestionempleados;

/**
 *
 * @author 52444
 */
public class GestionEmpleados {

       public static void main(String[] args) {
        Empleado e1 = new Gerente("Bang Chan", 20000, "Desarrollo de interfaz");
        Empleado e2 = new Desarrollador("Lee Know", 25000, "Java");
        Empleado e3 = new Disenador("Felix", 20000, "Adobe Photoshop");
        
        e1.mostrarInfo();
        e1.trabajar();
        
        e2.mostrarInfo();
        e2.trabajar();
        
        e3.mostrarInfo();
        e3.trabajar();
    }
}

