/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cajerointerfaz;

/**
 *
 * @author 52444
 */
public class CajeroInterfaz {

    public static void main(String[] args) {
         new cajero().setVisible(true);
    }
}
