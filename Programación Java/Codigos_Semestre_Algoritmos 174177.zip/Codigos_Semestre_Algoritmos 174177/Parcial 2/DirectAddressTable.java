public class DirectAddressTable {

    static class Elemento {
        int key;
        String data; 

        public Elemento(int key, String data) {
            this.key = key;
            this.data = data;
        }

        @Override
        public String toString() {
            return "(" + key + ", " + data + ")";
        }
    }

    private static Elemento[] T;

    public static void initializeTable(int m) {
        T = new Elemento[m];
    }

    public static Elemento directAddressSearch(int k) {
        // 1 return T[k] [cite: 617]
        if (k >= 0 && k < T.length) {
            return T[k];
        }
        return null;
    }

    
    public static void directAddressInsert(Elemento x) {
      
        if (x.key >= 0 && x.key < T.length) {
            T[x.key] = x;
        } else {
            System.out.println("Error: La clave " + x.key + " está fuera del rango de la tabla.");
        }
    }

 
    public static void directAddressDelete(Elemento x) {
        if (x.key >= 0 && x.key < T.length) {
            T[x.key] = null; 
        }
    }
    
    
    public static void printTable() {
        System.out.println("--- Tabla Directa (T) ---");
        for (int i = 0; i < T.length; i++) {
            System.out.println("Slot " + i + ": " + (T[i] != null ? T[i] : "NIL"));
        }
        System.out.println("-------------------------");
    }

    public static void main(String[] args) {
        
        int m = 10; 
        initializeTable(m); 
        
        System.out.println("Paso 1: Inicialización de la tabla (m=10).");
        printTable();
       
        Elemento e2 = new Elemento(2, "Data_A");
        Elemento e5 = new Elemento(5, "Data_B");
        Elemento e8 = new Elemento(8, "Data_C");

        directAddressInsert(e2);
        directAddressInsert(e5);
        directAddressInsert(e8);
        System.out.println("\nPaso 2: Después de INSERTAR (2, 5, 8).");
        printTable();
        
        int keyToSearch = 5;
        Elemento result = directAddressSearch(keyToSearch);
        System.out.println("\nPaso 3: Búsqueda de clave " + keyToSearch + ": " + result);

        directAddressDelete(e2);
        System.out.println("\nPaso 4: Después de ELIMINAR el elemento con clave 2.");
        printTable();
    }
}