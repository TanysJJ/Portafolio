<?php

echo "<style>";
echo "table { 
        margin: 20px auto; 
        border-collapse: collapse; 
        width: 90%; 
    }";
echo "th, td { 
        padding: 10px; 
        text-align: center; 
        border: 1px solid #ddd; 
    }";
echo "th { 
        background-color: #7FB3D5; 
    }";
echo "</style>";

$conexion=mysqli_connect("localhost","id21895581_prograweb2","bd1Web2%","id21895581_bd1wb2") or die("Problemas en la conexion");

if (isset($_POST['id']) && isset($_POST['act'])) {
    $id = $_POST['id'];
    $estado = $_POST['act'];

    if ($estado != 0 && $estado != 1) {
        echo "El estado debe ser 0 o 1.";
        exit;
    }

    $query = "UPDATE clientes SET estado = $estado WHERE id = $id";
    mysqli_query($conexion, $query) or die(mysqli_error($conexion));

    echo "<table>";
    echo "<tr>";
    echo "<td colspan='6' style='background-color: #7FB3D5; text-align: center;'>¡Estado actualizado exitosamente!</td>";
    echo "</tr>";
    echo "</table>";
} else {
    echo "Datos de entrada no válidos.";
}

mysqli_close($conexion);
?>
