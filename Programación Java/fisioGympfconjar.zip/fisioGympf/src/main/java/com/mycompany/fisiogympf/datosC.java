/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fisiogympf;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * 
 * @author 52444
 */
public class datosC {
    private ArrayList<citas> cita;
    
    public datosC(){
        this.cita = new ArrayList<>();
        cargarCitasDesdeBaseDatos(); 
    }
    
    /**
     * Carga todas las citas desde la base de datos al ArrayList
     */
    private void cargarCitasDesdeBaseDatos() {
        String sql = "SELECT * FROM citas ORDER BY Fecha, Hora";
        
        try (Connection conn = ConexionMysql.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            cita.clear(); 
            
            while (rs.next()) {
                Date fecha = rs.getDate("Fecha");
                LocalDate localDate = fecha.toLocalDate();
                
                citas c = new citas(
                    rs.getString("Paciente"),
                    localDate.getDayOfMonth(),
                    localDate.getMonthValue(),
                    localDate.getYear(),
                    rs.getInt("Hora"),
                    rs.getString("Servicio")
                );
                cita.add(c);
            }
            
            System.out.println("Citas cargadas desde BD: " + cita.size());
            
        } catch (SQLException e) {
            System.err.println("Error al cargar citas desde BD: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al cargar datos de citas: " + e.getMessage(), 
                    "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public ArrayList<citas> getCitasPorFecha(LocalDate fecha) {
    ArrayList<citas> citasFecha = new ArrayList<>();

    for (citas c : cita) { 
        LocalDate fechaCita = LocalDate.of(c.getAño(), c.getMes(), c.getDia());
        if (fechaCita.equals(fecha)) {
            citasFecha.add(c);
        }
    }

    return citasFecha;
}

    
    
    public void refrescarDatos() {
        cargarCitasDesdeBaseDatos();
    }
    
   
    public boolean agregarCita(citas objCita) {
       
        String sql = "INSERT INTO citas (Paciente, Fecha, Hora, Servicio) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = ConexionMysql.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            LocalDate fecha = LocalDate.of(objCita.getAño(), objCita.getMes(), objCita.getDia());
            
            pstmt.setString(1, objCita.getPaciente());
            pstmt.setDate(2, Date.valueOf(fecha));
            pstmt.setInt(3, objCita.getHora());
            pstmt.setString(4, objCita.getServicio());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Si se guardó exitosamente en BD, agregarlo al ArrayList
                this.cita.add(objCita);
                System.out.println("Cita agregada exitosamente");
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al agregar cita: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al registrar cita: " + e.getMessage(), 
                    "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
        }
        
        return false;
    }
    
   
    public ArrayList<citas> getCitas() {
        return cita;
    }
    
   
    public boolean actualizarCita(int indice, citas citaActualizada) {
        if (indice >= 0 && indice < cita.size()) {
            citas citaOriginal = cita.get(indice);
            
          
            String sql = "UPDATE citas SET Paciente = ?, Fecha = ?, Hora = ?, Servicio = ? WHERE Paciente = ? AND Fecha = ? AND Hora = ? AND Servicio = ?";
            
            try (Connection conn = ConexionMysql.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                
                LocalDate fechaNueva = LocalDate.of(citaActualizada.getAño(), citaActualizada.getMes(), citaActualizada.getDia());
                LocalDate fechaOriginal = LocalDate.of(citaOriginal.getAño(), citaOriginal.getMes(), citaOriginal.getDia());
                
                // Datos nuevos
                pstmt.setString(1, citaActualizada.getPaciente());
                pstmt.setDate(2, Date.valueOf(fechaNueva));
                pstmt.setInt(3, citaActualizada.getHora());
                pstmt.setString(4, citaActualizada.getServicio());
                
                // Datos originales para WHERE
                pstmt.setString(5, citaOriginal.getPaciente());
                pstmt.setDate(6, Date.valueOf(fechaOriginal));
                pstmt.setInt(7, citaOriginal.getHora());
                pstmt.setString(8, citaOriginal.getServicio());
                
                int rowsAffected = pstmt.executeUpdate();
                
                if (rowsAffected > 0) {
                   
                    cita.set(indice, citaActualizada);
                    System.out.println("Cita actualizada exitosamente");
                    return true;
                }
                
            } catch (SQLException e) {
                System.err.println("Error al actualizar cita: " + e.getMessage());
                JOptionPane.showMessageDialog(null, "Error al actualizar cita: " + e.getMessage(), 
                        "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        return false;
    }
    
   
    public boolean eliminarCita(int indice) {
        if (indice >= 0 && indice < cita.size()) {
            citas citaAEliminar = cita.get(indice);
            
           
            String sql = "DELETE FROM citas WHERE Paciente = ? AND Fecha = ? AND Hora = ? AND Servicio = ?";
            
            try (Connection conn = ConexionMysql.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                
                LocalDate fecha = LocalDate.of(citaAEliminar.getAño(), citaAEliminar.getMes(), citaAEliminar.getDia());
                
                pstmt.setString(1, citaAEliminar.getPaciente());
                pstmt.setDate(2, Date.valueOf(fecha));
                pstmt.setInt(3, citaAEliminar.getHora());
                pstmt.setString(4, citaAEliminar.getServicio());
                
                int rowsAffected = pstmt.executeUpdate();
                
                if (rowsAffected > 0) {
                   
                    cita.remove(indice);
                    System.out.println("Cita eliminada exitosamente");
                    return true;
                }
                
            } catch (SQLException e) {
                System.err.println("Error al eliminar cita: " + e.getMessage());
                JOptionPane.showMessageDialog(null, "Error al eliminar cita: " + e.getMessage(), 
                        "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        return false;
    }
    
    
    public boolean eliminarCita(citas citaAEliminar) {
        int indice = cita.indexOf(citaAEliminar);
        if (indice >= 0) {
            return eliminarCita(indice);
        }
        return false;
    }
    
   
    public boolean verificarDisponibilidad(LocalDate fecha, int hora, String servicio, int maxCitasPorHora) {
        String sql = "SELECT COUNT(*) FROM citas WHERE Fecha = ? AND Hora = ? AND Servicio = ?";
        
        try (Connection conn = ConexionMysql.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setDate(1, Date.valueOf(fecha));
            pstmt.setInt(2, hora);
            pstmt.setString(3, servicio);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                int citasExistentes = rs.getInt(1);
                return citasExistentes < maxCitasPorHora;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al verificar disponibilidad: " + e.getMessage());
        }
        
        return false;
    }
    
    
    public ArrayList<citas> obtenerCitasPorFecha(LocalDate fecha) {
        ArrayList<citas> citasFecha = new ArrayList<>();
        String sql = "SELECT * FROM citas WHERE Fecha = ? ORDER BY Hora";
        
        try (Connection conn = ConexionMysql.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setDate(1, Date.valueOf(fecha));
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Date fechaDB = rs.getDate("Fecha");
                LocalDate localDate = fechaDB.toLocalDate();
                
                citas c = new citas(
                    rs.getString("Paciente"),
                    localDate.getDayOfMonth(),
                    localDate.getMonthValue(),
                    localDate.getYear(),
                    rs.getInt("Hora"),
                    rs.getString("Servicio")
                );
                citasFecha.add(c);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener citas por fecha: " + e.getMessage());
        }
        
        return citasFecha;
    }
    
    
    public ArrayList<citas> obtenerCitasPorPaciente(String nombrePaciente) {
        ArrayList<citas> citasPaciente = new ArrayList<>();
        String sql = "SELECT * FROM citas WHERE Paciente = ? ORDER BY Fecha, Hora";
        
        try (Connection conn = ConexionMysql.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nombrePaciente);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Date fechaDB = rs.getDate("Fecha");
                LocalDate localDate = fechaDB.toLocalDate();
                
                citas c = new citas(
                    rs.getString("Paciente"),
                    localDate.getDayOfMonth(),
                    localDate.getMonthValue(),
                    localDate.getYear(),
                    rs.getInt("Hora"),
                    rs.getString("Servicio")
                );
                citasPaciente.add(c);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener citas del paciente: " + e.getMessage());
        }
        
        return citasPaciente;
    }
    
    
    public ArrayList<String> obtenerServicios() {
        ArrayList<String> servicios = new ArrayList<>();
        String sql = "SELECT DISTINCT Servicio FROM citas WHERE Servicio IS NOT NULL AND Servicio != '' ORDER BY Servicio";
        
        try (Connection conn = ConexionMysql.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                String servicio = rs.getString("Servicio");
                if (servicio != null && !servicio.trim().isEmpty()) {
                    servicios.add(servicio.trim());
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener servicios: " + e.getMessage());
        }
        
        return servicios;
    }
    
    
    public String obtenerEstadisticas() {
        StringBuilder stats = new StringBuilder();
        
        try (Connection conn = ConexionMysql.getConnection()) {
            
            String sqlTotal = "SELECT COUNT(*) as total FROM citas";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlTotal)) {
                if (rs.next()) {
                    stats.append("Total de citas: ").append(rs.getInt("total")).append("\n");
                }
            }
            
           
            String sqlPorServicio = "SELECT Servicio, COUNT(*) as cantidad FROM citas WHERE Servicio IS NOT NULL AND Servicio != '' GROUP BY Servicio ORDER BY cantidad DESC";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlPorServicio)) {
                stats.append("\nCitas por servicio:\n");
                while (rs.next()) {
                    stats.append("- ").append(rs.getString("Servicio")).append(": ")
                         .append(rs.getInt("cantidad")).append("\n");
                }
            }
            
            
            String sqlHoy = "SELECT COUNT(*) as hoy FROM citas WHERE Fecha = CURDATE()";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlHoy)) {
                if (rs.next()) {
                    stats.append("\nCitas para hoy: ").append(rs.getInt("hoy")).append("\n");
                }
            }
            
           
            String sqlFuturas = "SELECT COUNT(*) as futuras FROM citas WHERE Fecha > CURDATE()";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlFuturas)) {
                if (rs.next()) {
                    stats.append("Citas futuras: ").append(rs.getInt("futuras")).append("\n");
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener estadísticas: " + e.getMessage());
            return "Error al cargar estadísticas";
        }
        
        return stats.toString();
    }
    
   
    public int contarCitasPaciente(String nombrePaciente) {
        String sql = "SELECT COUNT(*) FROM citas WHERE Paciente = ?";
        
        try (Connection conn = ConexionMysql.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nombrePaciente);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al contar citas del paciente: " + e.getMessage());
        }
        
        return 0;
    }
    
    
    public boolean eliminarCitasPorPaciente(String nombrePaciente) {
        String sql = "DELETE FROM citas WHERE Paciente = ?";
        
        try (Connection conn = ConexionMysql.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nombrePaciente);
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // También eliminar del ArrayList local
                cita.removeIf(c -> c.getPaciente().equals(nombrePaciente));
                System.out.println("Eliminadas " + rowsAffected + " citas del paciente: " + nombrePaciente);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al eliminar citas del paciente: " + e.getMessage());
        }
        
        return false;
    }
    
    
    public ArrayList<citas> obtenerCitasPorServicio(String servicio) {
        ArrayList<citas> citasServicio = new ArrayList<>();
        String sql = "SELECT * FROM citas WHERE Servicio = ? ORDER BY Fecha, Hora";
        
        try (Connection conn = ConexionMysql.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, servicio);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Date fechaDB = rs.getDate("Fecha");
                LocalDate localDate = fechaDB.toLocalDate();
                
                citas c = new citas(
                    rs.getString("Paciente"),
                    localDate.getDayOfMonth(),
                    localDate.getMonthValue(),
                    localDate.getYear(),
                    rs.getInt("Hora"),
                    rs.getString("Servicio")
                );
                citasServicio.add(c);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener citas por servicio: " + e.getMessage());
        }
        
        return citasServicio;
    }
    
   
    public boolean existeCita(String paciente, LocalDate fecha, int hora, String servicio) {
        String sql = "SELECT COUNT(*) FROM citas WHERE Paciente = ? AND Fecha = ? AND Hora = ? AND Servicio = ?";
        
        try (Connection conn = ConexionMysql.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, paciente);
            pstmt.setDate(2, Date.valueOf(fecha));
            pstmt.setInt(3, hora);
            pstmt.setString(4, servicio);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al verificar existencia de cita: " + e.getMessage());
        }
        
        return false;
    }
}