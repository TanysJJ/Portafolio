
public class ChainedHashTable {

    static class Elemento {
        int key;
        String data;

        public Elemento(int key, String data) {
            this.key = key;
            this.data = data;
        }

        @Override
        public String toString() {
            return "[" + key + ": " + data + "]";
        }
    }

    private static LinkedList<Elemento>[] T;
    private static int tableSize;

    private static int hashFunction(int k) {
        return k % tableSize;
    }

    public static void initializeHashTable(int m) {
        tableSize = m;
        T = new LinkedList[m];
        for (int i = 0; i < m; i++) {
            T[i] = new LinkedList<>();
        }
    }

    public static void chainedHashInsert(Elemento x) {
        int slot = hashFunction(x.key)
        T[slot].addFirst(x); 
    }

 
    public static Elemento chainedHashSearch(int k) {
        int slot = hashFunction(k);
       
        for (Elemento x : T[slot]) {
            if (x.key == k) {
                return x;
            }
        }
        return null;
    }

    public static void chainedHashDelete(Elemento x) {
        int slot = hashFunction(x.key);
        T[slot].remove(x); 
    }

    public static void printTable() {
        System.out.println("--- Tabla Hash (m=" + tableSize + ") ---");
        for (int i = 0; i < T.length; i++) {
            System.out.print("Slot " + i + ": ");
            if (T[i].isEmpty()) {
                System.out.println("NIL");
            } else {
                for (Elemento e : T[i]) {
                    System.out.print(e + " -> ");
                }
                System.out.println("/");
            }
        }
        System.out.println("---------------------------------");
    }

    public static void main(String[] args) {
        int m = 9; 
        initializeHashTable(m); 
        
        int[] keys = {5, 28, 19, 15, 20, 33, 12, 17, 10};
        
        System.out.println("Paso 1: Insertando claves h(k) = k mod 9.");
        for (int key : keys) {
            Elemento e = new Elemento(key, "Data_" + key);
            chainedHashInsert(e);
        }
  
        printTable();

        int keyToSearch = 20;
        Elemento result = chainedHashSearch(keyToSearch);
        System.out.println("\nPaso 2: Búsqueda de clave " + keyToSearch + ": " + result);

        Elemento e19 = chainedHashSearch(19);
        if (e19 != null) {
            chainedHashDelete(e19);
            System.out.println("\nPaso 3: Después de ELIMINAR la clave 19.");
            printTable();
        } else {
             System.out.println("\nNo se encontró el elemento con clave 19 para eliminar.");
        }
    }
}