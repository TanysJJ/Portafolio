
public class QuickMergeInsertionHeapSort {

    static int contadorInsertion = 0;
    static int contadorMerge = 0;
    static int contadorHeap = 0;
    static int contadorQuick = 0;
    static int heapSize = 0;

    public static void main(String[] args) {

        System.out.println("INSERTION SORT");
        Random rn1 = new Random();
        for (int i = 1000; i <= 35000; i += 1000) {
            int prom = promediarInsertion(rn1, i, 10);  
            System.out.println(i + "-" + prom);                 
        }

        System.out.println("MERGE SORT");
        Random rn2 = new Random();
        for (int i = 1000; i <= 35000; i += 1000) {
            int prom = promediarMerge(rn2, i, 10);
            System.out.println(i + "-" + prom);
        }

        System.out.println("HEAP SORT");

        Random rn3 = new Random();
        for (int i = 1000; i <= 35000; i += 1000) {
            int prom = promediarHeap(rn3, i, 10);
            System.out.println(i + "-" + prom);
        }

        System.out.println("QUICK SORT");

        Random rn4 = new Random();
        for (int i = 1000; i <= 35000; i += 1000) {
            int prom = promediarQuick(rn4, i, 10);
            System.out.println(i + "-" + prom);
        }

    }

    public static Integer[] construir(Random rnd, int n) {
        Integer A[] = new Integer[n];
        for (int i = 0; i < A.length; i++) {
            A[i] = rnd.nextInt(100000);
        }
        return A;
    }


    public static int promediarInsertion(Random rnd, int n, int m) {
        long comparaciones = 0;
        for (int i = 0; i < m; i++) {
            Integer A[] = construir(rnd, n);    
            Insertion(A);                       
            comparaciones += contadorInsertion; 
        }
        return (int) (comparaciones / m);
    }

 
    public static int promediarMerge(Random rnd, int n, int m) {
        long comparaciones = 0;
        for (int i = 0; i < m; i++) {
            Integer A[] = construir(rnd, n);
            mergeSort(A, 0, A.length - 1);
            comparaciones += contadorMerge;
        }
        return (int) (comparaciones / m);
    }


    public static int promediarHeap(Random rnd, int n, int m) {
        long comparaciones = 0;
        for (int i = 0; i < m; i++) {
            Integer A[] = construir(rnd, n);
            heapSort(A);
            comparaciones += contadorHeap;
        }
        return (int) (comparaciones / m);
    }

   
    public static int promediarQuick(Random rnd, int n, int m) {
        long comparaciones = 0;
        for (int i = 0; i < m; i++) {
            Integer A[] = construir(rnd, n);
            quickSort(A, 0, A.length - 1);
            comparaciones += contadorQuick;
        }
        return (int) (comparaciones / m);
    }

   
    public static <T extends Comparable<T>> void Insertion(T[] A) {
        contadorInsertion = 0;
        for (int j = 1; j < A.length; j++) {
            T key = A[j];
            int i = j - 1;
            while (i >= 0 && key.compareTo(A[i]) < 0) {
                A[i + 1] = A[i];
                i--;
                contadorInsertion++;
            }
            A[i + 1] = key;
        }
    }

    public static <T extends Comparable<T>> void merge(T A[], int p, int q, int r) {

        int n1 = q - p + 1;
        int n2 = r - q;

      
        T[] L = Arrays.copyOfRange(A, p, q + 1);
        T[] R = Arrays.copyOfRange(A, q + 1, r + 1);

        int i = 0, j = 0, k = p;
        while (i < n1 && j < n2) {
            if (L[i].compareTo(R[j]) <= 0) {
                contadorMerge++;
                A[k++] = L[i++];
            } else {
                A[k++] = R[j++];
            }
        }

        while (i < n1) {
            A[k++] = L[i++];
        }
        while (j < n2) {
            A[k++] = R[j++];
        }
    }

    public static <T extends Comparable<T>> void mergeSort(T[] A, int p, int r) {
        if (p < r) {
            int q = (p + r) / 2;
            mergeSort(A, p, q);
            mergeSort(A, q + 1, r);
            merge(A, p, q, r);
        }
    }

    public static <T extends Comparable<T>> void heapSort(T A[]) {
        buildMaxHeap(A);
        for (int i = A.length - 1; i >= 1; i--) {
            T temp = A[0];
            A[0] = A[i];
            A[i] = temp;
            heapSize--;
            maxHeapify(A, 0);
        }
    }

    public static <T extends Comparable<T>> void buildMaxHeap(T A[]) {
        heapSize = A.length;
        for (int i = (A.length / 2) - 1; i >= 0; i--) {
            maxHeapify(A, i);
            contadorHeap++;
        }
    }

    public static <T extends Comparable<T>> void maxHeapify(T A[], int i) {
        int l = left(i);
        int r = right(i);
        int largest;

        if (l < heapSize && A[l].compareTo(A[i]) > 0) {
            largest = l;
        } else {
            largest = i;
        }

        if (r < heapSize && A[r].compareTo(A[largest]) > 0) {
            largest = r;
        }

        if (largest != i) {
            T temp = A[i];
            A[i] = A[largest];
            A[largest] = temp;
            maxHeapify(A, largest);
        }
    }

    public static <T extends Comparable<T>> void quickSort(T A[], int p, int r) {
        if (p < r) {
            int q = partition(A, p, r);
            quickSort(A, p, q - 1);
            quickSort(A, q + 1, r);
        }
    }
    public static <T extends Comparable<T>> int partition(T A[], int p, int r) {

        T x = A[r];
        int i = p - 1;
        for (int j = p; j <= r - 1; j++) {
            contadorQuick++;            //contador
            if (A[j].compareTo(x) <= 0) {
                i++;
                T aux = A[i];
                A[i] = A[j];
                A[j] = aux;
            }
        }
        T aux = A[i + 1];
        A[i + 1] = A[r];
        A[r] = aux;

        return i + 1;
    }
    public static int parent(int i) {
        return i / 2;
    }

    public static int left(int i) {
        return 2 * i;
    }

    public static int right(int i) {
        return 2 * i + 1;
    }

}
