<?php
function mostrarTablaRegistros() {
    echo "<style>";
    echo "table { 
        margin: 20px auto; 
        border-collapse: collapse; 
        width: 90%; 
    }";
    echo "th, td { 
        padding: 10px; 
        text-align: center; 
        border: 1px solid #ddd; 
    }";
    echo "th { 
        background-color: #7FB3D5; 
    }";
    echo "</style>";

    echo "<table>";
    echo "<tr>";
    echo "<th>Id</th>";
    echo "<th>Nombre</th>";
    echo "<th>Apellido Paterno</th>";
    echo "<th>Apellido Materno</th>";
    echo "<th>E-mail</th>";
    echo "<th>Estado</th>";
    echo "<th>Acción</th>"; // Nuevo encabezado para la columna de acción
    echo "</tr>";

    $conexion=mysqli_connect("localhost","id21895581_prograweb2","bd1Web2%","id21895581_bd1wb2") or die("Problemas en la conexion");

    $registros = mysqli_query($conexion, "SELECT id,nombre, ap, am, email, estado FROM clientes WHERE id = '$_REQUEST[id]'")
        or die("Problemas en el select" . mysqli_error());

    if ($reg = mysqli_fetch_array($registros)) {
        echo "<tr>";
        echo "<td>" . $reg['id'] . "</td>";
        echo "<td>" . $reg['nombre'] . "</td>";
        echo "<td>" . $reg['ap'] . "</td>";
        echo "<td>" . $reg['am'] . "</td>";
        echo "<td>" . $reg['email'] . "</td>";
        echo "<td>" . $reg['estado'] . "</td>";
        echo "<td><button class='eliminar' data-id='" . $reg['id'] . "'>Eliminar</button></td>"; // Botón para eliminar con atributo data-id
        echo "</tr>";
    } else {
        echo "<tr>";
        echo "<td colspan='7'>No existe el Registro</td>";
        echo "</tr>";
    }

    echo "</table>";

    mysqli_close($conexion);
}
?>

<?php mostrarTablaRegistros(); ?>

<div id="mensaje"></div> <!-- Div para mostrar el mensaje de eliminación -->

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    // Función para mostrar la ventana de confirmación al hacer clic en el botón Eliminar
    $('.eliminar').click(function() {
        var id = $(this).data('id');
        if (confirm('¿Estás seguro que quieres borrar este registro?')) {
            // Si se confirma la eliminación, se envía una solicitud AJAX a borrarid.php con el ID del registro
            $.ajax({
                url: 'borrarid.php',
                method: 'post',
                data: {id: id},
                success: function(response) {
                    // Mostrar el mensaje de eliminación
                    $('#mensaje').html(response);
                    // Agregar el botón para mostrar los registros restantes
                    $('#mensaje').append('<button id="mostrarRegistros">Mostrar Registros Restantes</button>');
                }
            });
        }
    });

    // Función para cargar y mostrar los registros restantes al hacer clic en el botón "Mostrar Registros Restantes"
    $('#mensaje').on('click', '#mostrarRegistros', function() {
        $.ajax({
            url: 'restantes.php',
            method: 'get',
            success: function(response) {
                // Agregar el contenido de php2.php debajo de la tabla existente
                $('#mensaje').after(response);
            }
        });
    });
});
</script>
