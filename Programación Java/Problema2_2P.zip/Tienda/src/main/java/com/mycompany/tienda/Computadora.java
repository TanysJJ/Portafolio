/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tienda;

/**
 *
 * @author 52444
 */
public class Computadora extends Producto {
    public int descuento;
    public double precioFinal;
     public double precioTotal;
    
    public Computadora(String nombre, String marca, double precioBase) {
        super(nombre, marca, precioBase);
    }
    
    @Override
    public void calcularPrecioFinal(){
      precioFinal = precioBase *(0.15);
       precioTotal=precioBase-precioFinal;
    }
    
    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Precio final con descuento " + precioTotal);
    }
}

