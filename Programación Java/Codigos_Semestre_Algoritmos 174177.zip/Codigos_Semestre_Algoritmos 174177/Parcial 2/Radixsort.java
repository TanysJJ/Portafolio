public static void radixSort(int[] A, int d) {
    final int k = 9; 
    
    int[] B = new int[A.length];
    int exp = 1;
    for (int i = 1; i <= d; i++) {
        countingSortByDigit(A, B, k, exp);
        System.arraycopy(B, 0, A, 0, A.length);
        exp *= 10;
    }
}
private static void countingSortByDigit(int[] A, int[] B, int k, int exp) {
    int[] C = new int[k + 1];
    for (int j = 0; j < A.length; j++) {
        int digit = (A[j] / exp) % 10;
        C[digit]++;
    }

  
    for (int i = 1; i <= k; i++) {
        C[i] += C[i - 1];
    }
    
    for (int j = A.length - 1; j >= 0; j--) {
        int digit = (A[j] / exp) % 10;
        B[C[digit] - 1] = A[j]; 
        C[digit]--;
    }
}
//--------------------------------------------------------------------------------------------
public class RadixSort {

    public static void main(String[] args) {
        Integer arr[] = {170, 45, 75, 90, 802, 24, 2, 66}; 
        int n = arr.length; 
        radixSort(arr, n); 
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " "); // Imprimir el arreglo ordenado
        }
    }

  
    public static <E extends Comparable<E>> E getMax(E arr[], int n) {
        E mx = arr[0];
        for (int i = 1; i < n; i++) {
            if (arr[i].compareTo(mx) > 0) {
                mx = arr[i];
            }
        }
        return mx;
    }

   
    public static <E extends Comparable<E>> void radixSort(E arr[], int n) {
        
        E m = getMax(arr, n);

       
        for (int exp = 1; (Integer)m / exp > 0; exp *= 10) {
            countingSort(arr, exp);
        }
    }

    
    public static <E extends Comparable<E>> void countingSort(E A[], int exp) {
        int n = A.length;
        int[] C = new int[10]; 
      
        for (int i = 0; i < n; i++) {
            C[((Integer)A[i] / exp) % 10]++;
        }

       
        for (int i = 1; i < 10; i++) {
            C[i] += C[i - 1];
        }

        
        E[] B = (E[]) new Comparable[n];
        for (int i = n - 1; i >= 0; i--) {
            B[--C[((Integer)A[i] / exp) % 10]] = A[i];
        }

        
        System.arraycopy(B, 0, A, 0, n);
    }
}
