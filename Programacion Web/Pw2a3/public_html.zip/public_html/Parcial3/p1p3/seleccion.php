<!DOCTYPE html>
<html>

<head>
        <title>Eliminacion en base de datos</title>
        <meta charset="utf-8">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body>
        <h1>Actualizar clientes</h1>
        <div>
                <div>
                        <form id="form1" method="post" action="updateuser.php">
                                Activar usuario<br>
                                <input type="text" name="id" placeholder="ID del cliente"><br><br>
                                <input type="text" name="act" placeholder="1 o 0"><br><br>
                                <input type="submit" name="enviar" value="Actualizar"><br>

                        </form>
                        <form id="form2" method="post" action="#">
                                Mostrar usuarios activos<br>
                                <input type="submit" name="enviar" value="Mostrar"><br>
                        </form>
                        <form id="form3" method="post" action="#">
                                Mostrar usuarios inactivos<br>
                                <input type="submit" name="enviar" value="Mostrar"><br>
                        </form>

                </div>
                <div id="dataContainer1"></div>

        </div>

        <script>
                $(document).ready(function() {
                        $('#form1').submit(function(e) {
        e.preventDefault();

        var id = $('#form1 input[name="id"]').val();
        var estado = $('#form1 input[name="act"]').val();

        $.ajax({
            url: 'updateuser.php',
            method: 'post',
            data: {
                id: id,
                act: estado
            },
            success: function(data) {
                $('#dataContainer1').html(data); // Mostrar el mensaje de actualización

                // Después de un breve retraso, cargar nuevamente la tabla de clientes
                setTimeout(function() {
                    $.ajax({
                        url: 'updateuser.php',
                        method: 'post',
                        success: function(data) {
                            $('#dataContainer1').html(data); // Mostrar la tabla actualizada
                        }
                    });
                }, 2000); // 2000 milisegundos = 2 segundos (puedes ajustar este valor según necesites)
            }
        });
    });

                        $('#form2 input[type="submit"]').click(function(e) {
                                e.preventDefault();

                                $.ajax({
                                        url: "#",
                                        method: 'post',
                                        success: function(data) {
                                                $('#dataContainer1').html(data);
                                        }
                                });
                        });
                        $('#form3 input[type="submit"]').click(function(e) {
                                e.preventDefault();

                                $.ajax({
                                        url: '#',
                                        method: 'post',
                                        success: function(data) {
                                                $('#dataContainer1').html(data);
                                        }
                                });
                        });
                });
        </script>
</body>

</html>