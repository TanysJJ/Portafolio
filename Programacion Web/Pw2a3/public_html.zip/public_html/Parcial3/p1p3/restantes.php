<?php
    echo "<style>";
    echo "table { 
        margin: 20px auto; 
        border-collapse: collapse; 
        width: 90%; 
    }";
    echo "th, td { 
        padding: 10px; 
        text-align: center; 
        border: 1px solid #ddd; 
    }";
    echo "th { 
        background-color: #7FB3D5; 
    }";
    echo "</style>";

    echo "<table>";
    echo "<tr>";
    echo "<th>Id</th>";
    echo "<th>Nombre</th>";
    echo "<th>Apellido Paterno</th>";
    echo "<th>Apellido Materno</th>";
    echo "<th>E-mail</th>";
    echo "<th>Estado</th>";
    echo "</tr>";

    $conexion=mysqli_connect("localhost","id21895581_prograweb2","bd1Web2%","id21895581_bd1wb2") or die("Problemas en la conexion");

    $registros = mysqli_query($conexion, "SELECT id,nombre, ap, am, email, estado FROM clientes")
        or die("Problemas en el select" . mysqli_error());

    while($reg = mysqli_fetch_array($registros)) {
        echo "<tr>";
        echo "<td>" . $reg['id'] . "</td>";
        echo "<td>" . $reg['nombre'] . "</td>";
        echo "<td>" . $reg['ap'] . "</td>";
        echo "<td>" . $reg['am'] . "</td>";
        echo "<td>" . $reg['email'] . "</td>";
        echo "<td>" . $reg['estado'] . "</td>";

        echo "</tr>";
    }

    echo "</table>";

    mysqli_close($conexion);

?>



</script>
