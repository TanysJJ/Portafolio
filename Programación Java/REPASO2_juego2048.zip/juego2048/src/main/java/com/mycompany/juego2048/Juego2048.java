/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.juego2048;

/**
 *
 * @author 52444
 */
public class Juego2048 {

    public static void main(String[] args) {
        
    }
}
