/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appshopheroes;

/**
 *
 * @author 174177
 */
public class Superheroe {
   
    String nombre;
    String descripcion;
    boolean capa;

   
    public Superheroe(String nombre) {
        this.nombre = nombre;
        this.descripcion = "";
        this.capa = false;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isCapa() {
        return capa;
    }

    public void setCapa(boolean capa) {
        this.capa = capa;
    }

    
    @Override
    public String toString() {
        return "Superhéroe: " + nombre + 
               "\nDescripción: " + descripcion + 
               "\nCapa: " + (capa ? "Sí" : "No");
    }
}