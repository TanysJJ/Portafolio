public class DFS {
    Map<Vertice,List<Vertice>> adj= new HashMap<Vertice,List<Vertice>>();
    
    public DFS(Vertice V[], List<List<Vertice>> adj){
        for(int i=0; i<V.length; i++)
            this.adj.put(V[i],adj.get(i));
    }
    
    public void DFS(Vertice s){
       for(Vertice u : adj.keySet()){
            u.color = Vertice.WHITE;
            u.pi = null;
        } 
        int time=0;
        for(Vertice u : adj.keySet()){
            if(u.color == Vertice.WHITE)
                DFSVisit(u,time);
        } 
    }
    
    public void DFSVisit(Vertice u, int time){
        time++;
        u.d = time;
        u.color = Vertice.GRAY;
        for(Vertice v : adj.keySet()){
            if(v.color == Vertice.WHITE){
                v.pi = u;
                DFSVisit(v,time);
            }
        }
        u.color=Vertice.BLACK;
        time++;
        u.f=time;
    }
    
    public static void main(String args[]){
        Vertice u = new Vertice("u");
        Vertice v = new Vertice("v");
        Vertice w = new Vertice("w");
        Vertice x = new Vertice("x");
        Vertice y = new Vertice("y");
        Vertice z = new Vertice("z");
        
        List<Vertice> u_adj = new LinkedList<Vertice>();
        u_adj.add(v);
        u_adj.add(x);
        
        List<Vertice> v_adj = new LinkedList<Vertice>();
        v_adj.add(y);
        
        List<Vertice> w_adj = new LinkedList<Vertice>();
        w_adj.add(y);
        w_adj.add(z);
        
        List<Vertice> x_adj = new LinkedList<Vertice>();
        x_adj.add(v);
        
        List<Vertice> y_adj = new LinkedList<Vertice>();
        y_adj.add(x);
        
        List<Vertice> z_adj = new LinkedList<Vertice>();
        z_adj.add(z);
        
        Vertice V[]={u,v,w,x,y,z};
        List<List<Vertice>> adj = new LinkedList<List<Vertice>>();
        adj.add(u_adj);
        adj.add(v_adj);
        adj.add(w_adj);
        adj.add(x_adj);
        adj.add(y_adj);
        adj.add(z_adj);
        DFS g = new DFS(V,adj);
        g.DFS(u);
        System.out.println(g.adj);
    }
}
class Vertice {
    public static final String WHITE ="WHITE";
    public static final String GRAY ="GRAY";
    public static final String BLACK ="BLACK";
    
    public String n;
    public int d,f;
    public Vertice pi;
    public String color;
    
    public Vertice(String n){
        this.n = n;
    }
    
    public int hashCode(){
        return n.hashCode();
    }
    
    public String toString(){
        return "nombre--" + n + ", d=" +d+"\n";
    }
}
