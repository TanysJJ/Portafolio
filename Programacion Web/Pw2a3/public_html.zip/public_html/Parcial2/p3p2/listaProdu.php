<!DOCTYPE html>
<html>

<head>
    <style>
        body {
            background-image: url('F1.jpg');
            background-attachment: fixed;
            background-size: 100% 100%;
        }

        .recuadro {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            width: 80%;
            height: 80vh;
            margin: 0 auto;
            border: 1px solid rgba(0, 0, 0, 0.5);
            /* Borde con color oscuro */
            border-radius: 10px;
            /* Bordes redondeados */
            background-color: rgba(255, 255, 255, 0.7);
            text-align: center;
            padding: 20px;
            /* Añade espacio interno */
        }

        .recuadro label {
            font-weight: bold;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            border-radius: 10px;
            /* Bordes redondeados */
            overflow: hidden;
            /* Evita que los bordes redondeados se solapen con los bordes de la tabla */
        }

        th,
        td {
            padding: 10px;
            text-align: center;
            border: 1px solid rgba(0, 0, 0, 0.5);
            /* Borde con color oscuro */
        }

        th {
            background-color: #C1BDD3 ;
            /* Color de fondo para los encabezados */
        }
    </style>
</head>

<body>

    <div class="recuadro">
        <table>
            <tr>
                <th>Folio</th>
                <th>Nombre</th>
                <th>Existencias</th>
                <th>Precio</th>
                <th>Costo</th>
            </tr>

            <?php
            $conexion=mysqli_connect("localhost","id21895581_prograweb2","bd1Web2%","id21895581_bd1wb2") or die("Problemas en la conexion");

            $registros = mysqli_query($conexion, "SELECT * FROM productos")
                or die("Problemas en el select" . mysqli_error());

            while ($reg = mysqli_fetch_array($registros)) {
                echo "<tr>";
                echo "<td>" . $reg['folio'] . "</td>";
                echo "<td>" . $reg['nombre'] . "</td>";
                echo "<td>" . $reg['existencia'] . "</td>";
                echo "<td>" . $reg['precio'] . "</td>";
                echo "<td>" . $reg['costo'] . "</td>";
                echo "</tr>";
            }

            mysqli_close($conexion);
            ?>
        </table>
    </div>

</body>

</html>