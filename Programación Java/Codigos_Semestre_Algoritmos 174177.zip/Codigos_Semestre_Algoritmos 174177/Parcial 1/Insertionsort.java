public class InsertionSort {

   
    public static void InsertionSort(int A[]) {
           
           for (int j = 1; j < A.length; j++) {
            
               int key = A[j];
               int i = j-1;
               
               while(i>=0 && A[i] > key){
                   A[i+1] = A[i];
                   i --;  
               }
               A[i+1] = key;
        }
        
    }
     public static void main(String[] args) {
         int A[] = {5,2,4,6,1,3};
         
         //imprimir arreglo sin ordenar
         for(int x : A)
             System.out.print(x+" ");
         System.out.println();
         
         //ordenar arreglo
         InsertionSort.InsertionSort(A);
         
        //Imprimimos el arreglo ordenado
         for (int x : A)
           System.out.print(x+" ");
         System.out.println();
     }
}
//Insertion sort con genericos

public class InsertSort {
   
    public static <T extends Comparable<T>> void InsertSort(T A[]) {
           
           for (int j = 1; j < A.length; j++) {
            
               T key = A[j];
               
               int i = j-1;
               
               while(i>=0 && A[i].compareTo(key)>0){
                   
                   A[i+1] = A[i];
                   i --;  
               }
               A[i+1] = key;
        }
        
    }
     public static void main(String[] args) {
         //Integer A[] = {5,2,4,6,1,3};
        // String A[] = {"Chan","Minho","Binnie","Hyunjin","Hannie","Youngbok","Minnie","Jeonginnie"};
          Integer A[] = {5,2,4,6,1,3};
         //imprimir arreglo sin ordenar
         for(Comparable x : A)
             System.out.print(x+" ");
         System.out.println();
         
         //ordenar arreglo
         InsertSort.InsertSort(A);
         
        //Imprimimos el arreglo ordenado
         for (Comparable x : A)
              System.out.print(x+" ");
         System.out.println();
     }
}
    
    
    
    