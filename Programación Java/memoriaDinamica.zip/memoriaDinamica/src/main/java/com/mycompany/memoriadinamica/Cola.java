/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.memoriadinamica;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author 52444
 */
public class Cola {

    private Queue<Integer> cola = new LinkedList<>();

    public String insertarElemento(int elemento) {
        cola.offer(elemento);
        return "Elemento " + elemento + " insertado. Estado de la cola: " + cola;
    }

    public String eliminarElemento() {
        if (!cola.isEmpty()) {
            int eliminado = cola.poll();
            return "Elemento " + eliminado + " eliminado. Estado de la cola: " + cola;
        } else {
            return "La cola está vacía. No se puede eliminar ningún elemento.";
        }
    }

    public String getEstadoCola() {
        return "Estado final de la cola: " + cola;
    }

    public String getEstadoInicial() {
        return "Estado inicial de la cola: " + cola;
    }
}

