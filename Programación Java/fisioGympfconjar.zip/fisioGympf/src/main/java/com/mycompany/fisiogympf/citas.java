/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fisiogympf;

public class citas {
    String paciente;
    int dia;
    int mes;
    int año;
    int hora;
    String servicio;
    private int duracionHoras = 1; 

    public citas(String paciente, int dia, int mes, int año, int hora, String servicio) {
        this.paciente = paciente;
        this.dia = dia;
        this.mes = mes;
        this.año = año;
        this.hora = hora;
        this.servicio = servicio;
    }

    public String getPaciente() {
        return paciente;
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAño() {
        return año;
    }

    public int getHora() {
        return hora;
    }

    public String getServicio() {
        return servicio;
    }

   public String getArea() {
    return servicio; 
}
    public int getDuracionHoras() {
        return duracionHoras;
    }

    public void setDuracionHoras(int duracion) {
        this.duracionHoras = duracion;
    }
}