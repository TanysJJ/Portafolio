<?php

$conexion=mysqli_connect("localhost","id21895581_prograweb2","bd1Web2%","id21895581_bd1wb2") or die("Problemas en la conexion");
$registros = mysqli_query($conexion, "SELECT * FROM productos")
    or die("Problemas en el seelect" . mysqli_error());

echo "<style>";
echo "table { 
    margin: 20px auto; /* Margen superior e inferior de 20px y centrado horizontal */
    border-collapse: collapse; /* Colapso de bordes para que se vean como una sola línea */
    width: 90%; /* Ancho del 90% del contenedor */
}";
echo "th, td { 
    padding: 10px; /* Añade espacio interno a celdas */
    text-align: center; /* Alineación del texto en el centro */
    border: 1px solid #ddd; /* Borde de 1px sólido de color gris */
}";
echo "th { 
    background-color: #f2f2f2; /* Color de fondo para los encabezados */
}";
echo "</style>";

echo "<table>";
echo "<tr>";
echo "<th>Folio</th>";
echo "<th>Nombre</th>";
echo "<th>Existencias</th>";
echo "<th>Precio</th>";
echo "<th>Costo</th>";
echo "</tr>";

while ($reg = mysqli_fetch_array($registros)) {
    echo "<tr>";
    echo "<td>" . $reg['folio'] . "</td>";
    echo "<td>" . $reg['nombre'] . "</td>";
    echo "<td>" . $reg['existencia'] . "</td>";
    echo "<td>" . $reg['precio'] . "</td>";
    echo "<td>" . $reg['costo'] . "</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conexion);
