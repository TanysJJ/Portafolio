public class ArbolesRojiNegros<T extends Comparable<T>> {

    static class nodoTree<T extends Comparable<T>> {
        T key;
        nodoTree<T> parent;
        nodoTree<T> left;
        nodoTree<T> right;
        boolean color; 
        public nodoTree(T key) {
            this.key = key;
            this.parent = null;
            this.left = null;
            this.right = null;
            this.color = ArbolesRojiNegros.RED; 
        }
    }

    private static final boolean RED = true;
    private static final boolean BLACK = false;

    nodoTree<T> arbolroot;

    public ArbolesRojiNegros() {
        this.arbolroot = null;
    }

    
    public static void main(String[] args) {
        ArbolesRojiNegros<Integer> arbol = new ArbolesRojiNegros<>();

        arbol.RBInsert(10);
        arbol.RBInsert(20);
        arbol.RBInsert(30);
        arbol.RBInsert(15);
        arbol.RBInsert(25);
        arbol.RBInsert(5);
        arbol.RBInsert(35);

        System.out.println("\nRecorrido In-Order del árbol:");
        arbol.inOrderTreeWalk(arbol.arbolroot);
        nodoTree<Integer> nodeToDelete = arbol.treeSearch(arbol.arbolroot, 20);
        if (nodeToDelete != null) {
            System.out.println("\nEliminando nodo con clave 20...");
            arbol.RBDelete(nodeToDelete);
        }
        System.out.println("\nRecorrido In-Order después de la eliminación:");
        arbol.inOrderTreeWalk(arbol.arbolroot);
    }
 
    public void inOrderTreeWalk(nodoTree<T> x) {
        if (x != null) {
            inOrderTreeWalk(x.left);
            String colorStr = x.color == RED ? "ROJO" : "NEGRO";
            System.out.println(x.key + " (" + colorStr + ")");
            inOrderTreeWalk(x.right);
        }
    }

   
    public void RBInsert(T key) {
        
        nodoTree<T> z = new nodoTree<>(key); 
        nodoTree<T> y = null;
        nodoTree<T> x = arbolroot; 
        
        while (x != null) {
            y = x;
            if (z.key.compareTo(x.key) < 0) {
                x = x.left;
            } else {
                x = x.right;
            }
        }
        z.parent = y;
        if (y == null) {
            arbolroot = z;
        } else if (z.key.compareTo(y.key) < 0) {
            y.left = z;
        } else {
            y.right = z;
        }
        z.left = null;
        z.right = null;
        z.color = RED; 
        
        RBInsertFixup(z);
    }

    public void RBInsertFixup(nodoTree<T> z) {
        
        while (z.parent != null && z.parent.color == RED) {
          
            if (z.parent == z.parent.parent.left) {
                nodoTree<T> y = z.parent.parent.right; 
                if (y != null && y.color == RED) {
                    z.parent.color = BLACK;
                    y.color = BLACK;
                    z.parent.parent.color = RED;
                    z = z.parent.parent; 
                } else { 
                    
                    if (z == z.parent.right) {
                        z = z.parent;
                        leftRotate(z);
                    }
                    z.parent.color = BLACK;
                    z.parent.parent.color = RED;
                    rightRotate(z.parent.parent);
                }
            } else { 
                nodoTree<T> y = z.parent.parent.left; 
                if (y != null && y.color == RED) {
                    z.parent.color = BLACK;
                    y.color = BLACK;
                    z.parent.parent.color = RED;
                    z = z.parent.parent; 
                } else { 
                    if (z == z.parent.left) {
                        z = z.parent;
                        rightRotate(z);
                    }
                    z.parent.color = BLACK;
                    z.parent.parent.color = RED;
                    leftRotate(z.parent.parent);
                }
            }
        }
        
        arbolroot.color = BLACK; 
    }

   
    public void leftRotate(nodoTree<T> x) {
        nodoTree<T> y = x.right;    
        x.right = y.left;            
        if (y.left != null) {
            y.left.parent = x;       
        }
        y.parent = x.parent;         
        if (x.parent == null) {
            arbolroot = y;           
        } else if (x == x.parent.left) {
            x.parent.left = y;       
        } else {
            x.parent.right = y;      
        }
        y.left = x;                  
        x.parent = y;                
    }

    public void rightRotate(nodoTree<T> x) {
    
        nodoTree<T> y = x.left;
        x.left = y.right;
        if (y.right != null) {
            y.right.parent = x;
        }
        y.parent = x.parent;
        if (x.parent == null) {
            arbolroot = y;
        } else if (x == x.parent.left) {
            x.parent.left = y;
        } else {
            x.parent.right = y;
        }
        y.right = x;
        x.parent = y;
    }

    public void RBTransplant(nodoTree<T> u, nodoTree<T> v) {
        if (u.parent == null) {
            arbolroot = v;
        } else if (u == u.parent.left) {
            u.parent.left = v;
        } else {
            u.parent.right = v;
        }
        if (v != null) {
            v.parent = u.parent;
        }
    }

   
    public void RBDelete(nodoTree<T> z) {
        nodoTree<T> y = z;
        nodoTree<T> x; 
        boolean yOriginalColor = y.color; 

        if (z.left == null) {
            x = z.right;
            RBTransplant(z, z.right);
        } else if (z.right == null) {
            x = z.left;
            RBTransplant(z, z.left);
        } else {
            y = treeMinimum(z.right); 
            yOriginalColor = y.color;
            x = y.right; 

            if (y.parent == z) {
                if (x != null) { 
                    x.parent = y;
                }
            } else {
                RBTransplant(y, y.right);
                y.right = z.right;
                y.right.parent = y;
            }
            
            RBTransplant(z, y);
            y.left = z.left;
            y.left.parent = y;
            y.color = z.color; 
        }
        if (yOriginalColor == BLACK) {
            RBDeleteFixup(x);
        }
    }
    public void RBDeleteFixup(nodoTree<T> x) {
        while (x != arbolroot && (x == null || x.color == BLACK)) { 
            if (x == x.parent.left) {
                nodoTree<T> w = x.parent.right; 
                if (w != null && w.color == RED) { 
                    w.color = BLACK;
                    x.parent.color = RED;
                    leftRotate(x.parent);
                    w = x.parent.right;
                }
                if ((w.left == null || w.left.color == BLACK) && (w.right == null || w.right.color == BLACK)) {
                    w.color = RED; 
                    x = x.parent;
                } else {
                    
                    if (w.right == null || w.right.color == BLACK) {
                        if (w.left != null) w.left.color = BLACK;
                        w.color = RED;
                        rightRotate(w);
                        w = x.parent.right;
                    }
                    w.color = x.parent.color;
                    x.parent.color = BLACK;
                    if (w.right != null) w.right.color = BLACK;
                    leftRotate(x.parent);
                    x = arbolroot; 
                }
            } else { 
                nodoTree<T> w = x.parent.left; 
                if (w != null && w.color == RED) {
                    w.color = BLACK;
                    x.parent.color = RED;
                    rightRotate(x.parent);
                    w = x.parent.left;
                }

                if ((w.right == null || w.right.color == BLACK) && (w.left == null || w.left.color == BLACK)) {
                    w.color = RED;
                    x = x.parent;
                } else {
                    if (w.left == null || w.left.color == BLACK) {
                        if (w.right != null) w.right.color = BLACK;
                        w.color = RED;
                        leftRotate(w);
                        w = x.parent.left;
                    }
                    w.color = x.parent.color;
                    x.parent.color = BLACK;
                    if (w.left != null) w.left.color = BLACK;
                    rightRotate(x.parent);
                    x = arbolroot; 
                }
            }
        }
        
        if (x != null) {
             x.color = BLACK;
        }
    }
    public nodoTree<T> treeMinimum(nodoTree<T> x) {
        if (x == null) return null;
        while (x.left != null) {
            x = x.left;
        }
        return x;
    }

    public nodoTree<T> treeMaximum(nodoTree<T> x) {
        if (x == null) return null;
        while (x.right != null) {
            x = x.right;
        }
        return x;
    }
    
    public nodoTree<T> treeSearch(nodoTree<T> x, T key) {
        if (x == null || key.compareTo(x.key) == 0) {
            return x;
        }

        if (key.compareTo(x.key) < 0) {
            return treeSearch(x.left, key);
        } else {
            return treeSearch(x.right, key);
        }
    }

    public nodoTree<T> treeSuccessor(nodoTree<T> x) {
        if (x == null) return null;
        
        if (x.right != null) {
            return treeMinimum(x.right);
        }

        nodoTree<T> y = x.parent;
        while (y != null && x == y.right) {
            x = y;
            y = y.parent;
        }

        return y;
    }

    public nodoTree<T> treePredecessor(nodoTree<T> x) {
        if (x == null) return null;
        
        if (x.left != null) {
            return treeMaximum(x.left);
        }

        nodoTree<T> y = x.parent;
        while (y != null && x == y.left) {
            x = y;
            y = y.parent;
        }

        return y;
    }
}