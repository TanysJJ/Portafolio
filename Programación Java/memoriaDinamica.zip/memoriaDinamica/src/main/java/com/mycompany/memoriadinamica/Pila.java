/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.memoriadinamica;

import java.util.Stack;

public class Pila{

    private Stack<Integer> pila;

    public Pila() {
        pila = new Stack<>();
    }

    public void push(int elemento) {
        pila.push(elemento);
    }

    public int pop() {
        if (!pila.isEmpty()) {
            return pila.pop();
        } else {
            return -1; // O lanza una excepción, dependiendo de cómo quieras manejar la pila vacía
        }
    }

    public String mostrar() {
        return pila.toString();
    }
}