package com.mycompany.fisiogympf;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * 
 * @author 52444
 */
public class datosP {
    private ArrayList<paciente> pacientes;
    
    public datosP(){
        this.pacientes = new ArrayList<>();
        cargarPacientesDesdeBaseDatos(); 
    }

    private void cargarPacientesDesdeBaseDatos() {
        String sql = "SELECT * FROM pacientes ORDER BY Nombre";
        
        try (Connection conn = ConexionMysql.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            pacientes.clear(); // Limpiar lista antes de cargar
            
            while (rs.next()) {
                paciente p = new paciente(
                    rs.getString("Nombre"),
                    rs.getString("DNI"),
                    rs.getString("Telefono"),
                    rs.getInt("dia"),
                    rs.getInt("mes"),
                    rs.getInt("anio")
                );
                pacientes.add(p);
            }
            
            System.out.println("Pacientes cargados desde BD: " + pacientes.size());
            
        } catch (SQLException e) {
            System.err.println("Error al cargar pacientes desde BD: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al cargar datos de pacientes: " + e.getMessage(), 
                    "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
        }
    }
    
  
public paciente getPacientePorNombre(String nombre) {
    for (paciente p : pacientes) {
        if (p.getNombre().equals(nombre)) {
            return p;
        }
    }
    return null;
}
    public void refrescarDatos() {
        cargarPacientesDesdeBaseDatos();
    }
    
    /**
     * Agrega un paciente tanto al ArrayList como a la base de datos
     */
    public boolean agregarPaciente(paciente objPaciente) {
        // Primero guardar en la base de datos
        String sql = "INSERT INTO pacientes (Nombre, DNI, Telefono, Estado, dia, mes, anio) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionMysql.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, objPaciente.getNombre());
            pstmt.setString(2, objPaciente.getDNI());
            pstmt.setString(3, objPaciente.getTelefono());
            pstmt.setString(4, "Activo"); // Estado por defecto
            pstmt.setInt(5, objPaciente.getDia());
            pstmt.setInt(6, objPaciente.getMes());
            pstmt.setInt(7, objPaciente.getAño());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Si se guardó exitosamente en BD, agregarlo al ArrayList
                this.pacientes.add(objPaciente);
                System.out.println("Paciente agregado exitosamente");
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al agregar paciente: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al registrar paciente: " + e.getMessage(), 
                    "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
        }
        
        return false;
    }
    
    /**
     * Obtiene la lista de pacientes (desde memoria)
     */
    public ArrayList<paciente> getPacientes() {
        return pacientes;
    }
    
    /**
     * Actualiza un paciente tanto en el ArrayList como en la base de datos
     */
    public boolean actualizarPaciente(int indice, paciente pacienteActualizado) {
        if (indice >= 0 && indice < pacientes.size()) {
            paciente pacienteOriginal = pacientes.get(indice);
            String dniOriginal = pacienteOriginal.getDNI();
            
            // Actualizar en la base de datos
            String sql = "UPDATE pacientes SET Nombre = ?, DNI = ?, Telefono = ?, dia = ?, mes = ?, anio = ? WHERE DNI = ?";
            
            try (Connection conn = ConexionMysql.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                
                pstmt.setString(1, pacienteActualizado.getNombre());
                pstmt.setString(2, pacienteActualizado.getDNI());
                pstmt.setString(3, pacienteActualizado.getTelefono());
                pstmt.setInt(4, pacienteActualizado.getDia());
                pstmt.setInt(5, pacienteActualizado.getMes());
                pstmt.setInt(6, pacienteActualizado.getAño());
                pstmt.setString(7, dniOriginal);
                
                int rowsAffected = pstmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    // Si se actualizó exitosamente en BD, actualizar el ArrayList
                    pacientes.set(indice, pacienteActualizado);
                    System.out.println("Paciente actualizado exitosamente");
                    return true;
                }
                
            } catch (SQLException e) {
                System.err.println("Error al actualizar paciente: " + e.getMessage());
                JOptionPane.showMessageDialog(null, "Error al actualizar paciente: " + e.getMessage(), 
                        "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        return false;
    }
    
    /**
     * Elimina un paciente tanto del ArrayList como de la base de datos
     */
    public boolean eliminarPaciente(int indice) {
        if (indice >= 0 && indice < pacientes.size()) {
            paciente pacienteAEliminar = pacientes.get(indice);
            String dni = pacienteAEliminar.getDNI();
            
            // Eliminar de la base de datos
            String sql = "DELETE FROM pacientes WHERE DNI = ?";
            
            try (Connection conn = ConexionMysql.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                
                pstmt.setString(1, dni);
                
                int rowsAffected = pstmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    // Si se eliminó exitosamente de BD, eliminar del ArrayList
                    pacientes.remove(indice);
                    System.out.println("Paciente eliminado exitosamente");
                    return true;
                }
                
            } catch (SQLException e) {
                System.err.println("Error al eliminar paciente: " + e.getMessage());
                JOptionPane.showMessageDialog(null, "Error al eliminar paciente: " + e.getMessage(), 
                        "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        return false;
    }
    
    /**
     * Busca un paciente por DNI
     */
    public paciente buscarPacientePorDNI(String dni) {
        for (paciente p : pacientes) {
            if (p.getDNI().equals(dni)) {
                return p;
            }
        }
        return null;
    }
    
    /**
     * Verifica si un DNI ya existe
     */
    public boolean existeDNI(String dni) {
        String sql = "SELECT COUNT(*) FROM pacientes WHERE DNI = ?";
        
        try (Connection conn = ConexionMysql.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, dni);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al verificar DNI: " + e.getMessage());
        }
        
        return false;
    }
}