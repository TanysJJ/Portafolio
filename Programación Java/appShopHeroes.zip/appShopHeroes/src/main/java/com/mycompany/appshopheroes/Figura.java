/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appshopheroes;

/**
 *
 * @author 174177
 */
public class Figura {
   
     String codigo;
     double precio;
     Superheroe superheroe;
     Dimension dimensiones;

    
    public Figura(String codigo, double precio, Dimension dimensiones, Superheroe superheroe) {
        this.codigo = codigo;
        this.precio = precio;
        this.dimensiones = dimensiones;
        this.superheroe = superheroe;
    }

   
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Superheroe getSuperheroe() {
        return superheroe;
    }

    public void setSuperheroe(Superheroe superheroe) {
        this.superheroe = superheroe;
    }

    public Dimension getDimensiones() {
        return dimensiones;
    }

    public void setDimensiones(Dimension dimensiones) {
        this.dimensiones = dimensiones;
    }

    // Método para subir precio
    public void subirPrecio(double cantidad) {
        this.precio += cantidad;
    }

    // Método toString
    @Override
    public String toString() {
        return "Figura: " + 
               "\nCódigo: " + codigo + 
               "\nPrecio: " + precio + 
               "\nSuperhéroe:\n" + superheroe + 
               "\nDimensiones:\n" + dimensiones;
    }
}