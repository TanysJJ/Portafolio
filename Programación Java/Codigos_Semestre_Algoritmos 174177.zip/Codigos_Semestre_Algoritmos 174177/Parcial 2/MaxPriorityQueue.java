
public static <T extends Comparable<T>> T heapMaximum(T A[]) {
    
    if (heapSize < 1) {
        
        System.err.println("Error: Heap Underflow - Heap vacío.");
        return null;
    }
    return A[0];
}

public static <T extends Comparable<T>> T heapExtractMax(T A[]) {
    
    if (heapSize < 1) {
        System.err.println("Error: Heap Underflow");
        return null;
    }
    T max = A[0]; 
    A[0] = A[heapSize - 1]; 
    heapSize--; 
    maxHeapify(A, 0); 
    return max; 
}

public static <T extends Comparable<T>> void heapIncreaseKey(T A[], int i, T key) {
   
    if (key.compareTo(A[i]) < 0){
        return;
    }
    
    A[i] = key; 

    while (i > 0 && A[parent(i)].compareTo(A[i]) < 0) {
        
        T aux = A[i];
        A[i] = A[parent(i)];
        A[parent(i)] = aux;
        i = parent(i);
    }
}


public static <T extends Comparable<T>> void maxHeapInsert(T A[], T key) {
    
    heapSize++; 
    int i = heapSize - 1; 

    if (i < A.length) {
        heapIncreaseKey(A, i, key); 
    } else {
      
        heapSize--;
    }
}