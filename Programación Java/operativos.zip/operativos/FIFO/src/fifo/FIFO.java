/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fifo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author asesi
 */
public class FIFO extends JFrame{

    private JTextField frame;
    private JTextField pagina;
    private JTextArea resultadosTA;
    private JTable Tabla;
    private DefaultTableModel TM;
    
    public FIFO(){
        // Configuración básica de la ventana
        setTitle("FIFO");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        
        // Panel superior con inputs
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2, 10, 10));
        
        inputPanel.add(new JLabel("Número de marcos:"));
        frame = new JTextField();
        inputPanel.add(frame);
        
        inputPanel.add(new JLabel("Secuencia de páginas (separadas por comas):"));
        pagina = new JTextField();
        pagina.setEditable(false);
        inputPanel.add(pagina);
        
        JButton randomButton = new JButton("Generar Secuencia Aleatoria");
        inputPanel.add(randomButton);

        JButton simulateButton = new JButton("Inicio");
        inputPanel.add(simulateButton);
        
        // Tabla para representar los marcos
        TM = new DefaultTableModel();
        Tabla = new JTable(TM);
        JScrollPane tableScrollPane = new JScrollPane(Tabla);
        
        // Área de resultados
        resultadosTA = new JTextArea();
        resultadosTA.setEditable(false);
        JScrollPane resultScrollPane = new JScrollPane(resultadosTA);
        resultScrollPane.setPreferredSize(new Dimension(600, 200)); // Área de texto más grande
        
        // Añadir componentes al frame
        add(inputPanel, BorderLayout.NORTH);
        add(tableScrollPane, BorderLayout.CENTER);
        add(resultScrollPane, BorderLayout.SOUTH);
        
        // Acción para generar secuencia aleatoria
        randomButton.addActionListener(e -> generateRandomSequence());

        // Acción del botón de simulación
        simulateButton.addActionListener(e -> new Thread(this::Simular).start());

    }
    
    private void generateRandomSequence() {
        try {
            Random random = new Random();
            int sequenceLength = 10;
            StringBuilder sequence = new StringBuilder();
        
            for (int i = 0; i < sequenceLength; i++) {
            sequence.append(random.nextInt(9) + 1); // Números entre 1 y 9
            if (i < sequenceLength - 1) {
                sequence.append(",");
            }
        }

            pagina.setText(sequence.toString());
        } catch (Exception ex) {
            resultadosTA.setText("Error al generar la secuencia aleatoria.");
        }
    }
    
    private void Simular(){
        try{
            // Leer número de marcos
            int numFrames = Integer.parseInt(frame.getText().trim());
            if (numFrames <= 0) {
                resultadosTA.setText("El número de marcos debe ser mayor a 0.");
                return;
            }
            
            // Leer secuencia de páginas
            String[] pagesInput = pagina.getText().trim().split(",");
            int[] pages = new int[pagesInput.length];
            for (int i = 0; i < pagesInput.length; i++) {
                pages[i] = Integer.parseInt(pagesInput[i].trim());
            }
            
            // Configuración inicial de la tabla
            TM.setRowCount(numFrames);
            TM.setColumnCount(1);
            for (int i = 0; i < numFrames; i++) {
                TM.setValueAt("-", i, 0); // Inicializamos los marcos con "-"
            }

            // Simulación de FIFO
            Queue<Integer> frameQueue = new LinkedList<>();
            int pageFaults = 0;
            
            resultadosTA.setText(""); // Limpiamos resultados
            
            for (int page : pages) {
                if (!frameQueue.contains(page)) {
                    if (frameQueue.size() >= numFrames) {
                        frameQueue.poll(); // Quitamos el marco más antiguo
                        pageFaults++; 
                    }
                    frameQueue.add(page);
                    

                    // Actualizar la tabla
                    updateFrameTable(frameQueue, numFrames);

                    // Mostrar información en el área de texto
                    //resultadosTA.append("Cargando página " + page + " en los marcos: " + frameQueue + "\n");
                } else {
                    //resultadosTA.append("Página " + page + " ya está en memoria: " + frameQueue + "\n");
                }

                // Pausa para simular animación
                Thread.sleep(2000); // 1 segundo entre cada paso
                resultadosTA.append("\nTotal de fallos de página: " + pageFaults);
            }

        }catch(NumberFormatException ex){
            resultadosTA.setText("Por favor, ingresa datos válidos.");
        }catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    private void updateFrameTable(Queue<Integer> frameQueue, int numFrames) {
        Integer[] frames = frameQueue.toArray(new Integer[0]);
        for (int i = 0; i < numFrames; i++) {
            if (i < frames.length) {
                TM.setValueAt(frames[i], i, 0);
            } else {
                TM.setValueAt("-", i, 0);
            }
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FIFO frame = new FIFO();
            frame.setVisible(true);
        });
    }
    
}