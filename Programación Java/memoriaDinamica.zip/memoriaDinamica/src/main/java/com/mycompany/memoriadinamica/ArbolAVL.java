/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.memoriadinamica;

/**
 *
 * @author 52444
 */
public class ArbolAVL {
// Clase interna para representar un nodo del árbol
    static class Nodo {
        int valor;
        Nodo izquierda, derecha;
        int altura;

        // Constructor del nodo
        public Nodo(int valor) {
            this.valor = valor;
            this.altura = 1; // Inicializamos la altura como 1
        }
    }

    // Clase para el Árbol AVL
    static class Arbol {
        Nodo raiz;

        // Obtener la altura de un nodo
        private int obtenerAltura(Nodo nodo) {
            return nodo == null ? 0 : nodo.altura;
        }

        // Obtener el factor de balance de un nodo
        private int obtenerBalance(Nodo nodo) {
            return nodo == null ? 0 : obtenerAltura(nodo.izquierda) - obtenerAltura(nodo.derecha);
        }

        // Rotación a la derecha
        private Nodo rotarDerecha(Nodo y) {
            Nodo x = y.izquierda;
            Nodo T2 = x.derecha;

            // Realizar la rotación
            x.derecha = y;
            y.izquierda = T2;

            // Actualizar las alturas
            y.altura = Math.max(obtenerAltura(y.izquierda), obtenerAltura(y.derecha)) + 1;
            x.altura = Math.max(obtenerAltura(x.izquierda), obtenerAltura(x.derecha)) + 1;

            // Devolver la nueva raíz
            return x;
        }

        // Rotación a la izquierda
        private Nodo rotarIzquierda(Nodo x) {
            Nodo y = x.derecha;
            Nodo T2 = y.izquierda;

            // Realizar la rotación
            y.izquierda = x;
            x.derecha = T2;

            // Actualizar las alturas
            x.altura = Math.max(obtenerAltura(x.izquierda), obtenerAltura(x.derecha)) + 1;
            y.altura = Math.max(obtenerAltura(y.izquierda), obtenerAltura(y.derecha)) + 1;

            // Devolver la nueva raíz
            return y;
        }

        // Inserta un nuevo valor en el árbol y lo balancea
        public Nodo insertar(Nodo nodo, int valor) {
            // 1. Realizar la inserción normal
            if (nodo == null) {
                return new Nodo(valor);
            }

            if (valor < nodo.valor) {
                nodo.izquierda = insertar(nodo.izquierda, valor);
            } else if (valor > nodo.valor) {
                nodo.derecha = insertar(nodo.derecha, valor);
            } else {
                return nodo; // El valor ya está presente
            }

            // 2. Actualizar la altura del nodo
            nodo.altura = 1 + Math.max(obtenerAltura(nodo.izquierda), obtenerAltura(nodo.derecha));

            // 3. Obtener el factor de balance
            int balance = obtenerBalance(nodo);

            // 4. Realizar rotaciones para balancear el árbol

            // Caso de rotación a la derecha (Izquierda-Izquierda)
            if (balance > 1 && valor < nodo.izquierda.valor) {
                return rotarDerecha(nodo);
            }

            // Caso de rotación a la izquierda (Derecha-Derecha)
            if (balance < -1 && valor > nodo.derecha.valor) {
                return rotarIzquierda(nodo);
            }

            // Caso de rotación doble a la derecha (Izquierda-Derecha)
            if (balance > 1 && valor > nodo.izquierda.valor) {
                nodo.izquierda = rotarIzquierda(nodo.izquierda);
                return rotarDerecha(nodo);
            }

            // Caso de rotación doble a la izquierda (Derecha-Izquierda)
            if (balance < -1 && valor < nodo.derecha.valor) {
                nodo.derecha = rotarDerecha(nodo.derecha);
                return rotarIzquierda(nodo);
            }

            // Si el árbol ya está balanceado, no hacemos nada
            return nodo;
        }

        // Elimina un nodo del árbol y lo balancea
        public Nodo eliminar(Nodo nodo, int valor) {
            if (nodo == null) {
                return nodo;
            }

            // 1. Buscar el nodo a eliminar
            if (valor < nodo.valor) {
                nodo.izquierda = eliminar(nodo.izquierda, valor);
            } else if (valor > nodo.valor) {
                nodo.derecha = eliminar(nodo.derecha, valor);
            } else {
                // Nodo a eliminar encontrado
                if (nodo.izquierda == null || nodo.derecha == null) {
                    Nodo temp = nodo.izquierda != null ? nodo.izquierda : nodo.derecha;
                    if (temp == null) {
                        nodo = null; // Nodo sin hijos
                    } else {
                        nodo = temp; // Nodo con un solo hijo
                    }
                } else {
                    // Nodo con dos hijos
                    Nodo temp = obtenerNodoMinimo(nodo.derecha);
                    nodo.valor = temp.valor;
                    nodo.derecha = eliminar(nodo.derecha, temp.valor);
                }
            }

            // Si el árbol tiene un solo nodo, retornar
            if (nodo == null) {
                return nodo;
            }

            // 2. Actualizar la altura del nodo
            nodo.altura = Math.max(obtenerAltura(nodo.izquierda), obtenerAltura(nodo.derecha)) + 1;

            // 3. Obtener el balance
            int balance = obtenerBalance(nodo);

            // 4. Realizar rotaciones para balancear el árbol

            // Caso de rotación a la derecha (Izquierda-Izquierda)
            if (balance > 1 && obtenerBalance(nodo.izquierda) >= 0) {
                return rotarDerecha(nodo);
            }

            // Caso de rotación a la izquierda (Derecha-Derecha)
            if (balance < -1 && obtenerBalance(nodo.derecha) <= 0) {
                return rotarIzquierda(nodo);
            }

            // Caso de rotación doble a la derecha (Izquierda-Derecha)
            if (balance > 1 && obtenerBalance(nodo.izquierda) < 0) {
                nodo.izquierda = rotarIzquierda(nodo.izquierda);
                return rotarDerecha(nodo);
            }

            // Caso de rotación doble a la izquierda (Derecha-Izquierda)
            if (balance < -1 && obtenerBalance(nodo.derecha) > 0) {
                nodo.derecha = rotarDerecha(nodo.derecha);
                return rotarIzquierda(nodo);
            }

            return nodo;
        }

        // Obtener el nodo con el valor mínimo en el árbol
        private Nodo obtenerNodoMinimo(Nodo nodo) {
            Nodo actual = nodo;
            while (actual.izquierda != null) {
                actual = actual.izquierda;
            }
            return actual;
        }

        // Recorrido inorden para imprimir el árbol
        public void inorden(Nodo nodo) {
            if (nodo != null) {
                inorden(nodo.izquierda);
                System.out.print(nodo.valor + " ");
                inorden(nodo.derecha);
            }
        }

        // Métodos públicos para insertar, eliminar e imprimir
        public void insertar(int valor) {
            raiz = insertar(raiz, valor);
        }

        public void eliminar(int valor) {
            raiz = eliminar(raiz, valor);
        }

        public void imprimirInorden() {
            inorden(raiz);
            System.out.println();
        }
    }
}
