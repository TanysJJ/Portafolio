/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.operacionesdearreglos;

/**
 *
 * @author 52444
 */
public class Operaciones {
    
    public int sumarElementos(int[] arreglo) {
        int suma = 0;
        for (int num : arreglo) {
            suma += num;
        }
        return suma;
    }

    public double[] encontrarMayorYMenor(double[] arreglo) {
       
        double mayor = arreglo[0];
        double menor = arreglo[0];
        for (double num : arreglo) {
            if (num > mayor) {
                mayor = num;
            }
            if (num < menor) {
                menor = num;
            }
        }
        return new double[]{mayor, menor};
    }

   
    public int sumarElementosMayoresQue(int[] arreglo, int valor) {
        int suma = 0;
        for (int num : arreglo) {
            if (num > valor) {
                suma += num;
            }
        }
        return suma;
    }

   
    public void imprimirArreglo(int[] arreglo) {
        System.out.print("Arreglo de enteros: ");
        for (int num : arreglo) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

   
    public void imprimirArreglo(double[] arreglo) {
        System.out.print("Arreglo de dobles: ");
        for (double num : arreglo) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}