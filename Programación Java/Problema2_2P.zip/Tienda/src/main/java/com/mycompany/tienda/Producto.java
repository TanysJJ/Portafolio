/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tienda;

/**
 *
 * @author 52444
 */
abstract class Producto {
    String nombre;
    String marca;
    double precioBase;
    
    public Producto(String nombre, String marca,double precioBase) {
        this.nombre = nombre;
        this.marca = marca;
        this.precioBase = precioBase;
       
    }
     public void mostrarInfo() {
        System.out.println("Datos del producto:");
        System.out.println("Nombre: " + nombre);
        System.out.println("Marca: " + marca);
        System.out.println("Precio sin descuento: "+precioBase);
    }
    public abstract void calcularPrecioFinal();
}
