public static void countingSort(int[] A, int[] B, int k) {
 
    int[] C = new int[k + 1];
    for (int i = 0; i <= k; i++) {
        C[i] = 0;
    }
    for (int j = 0; j < A.length; j++) {
        C[A[j]] = C[A[j]] + 1;
    }

    for (int i = 1; i <= k; i++) {
        C[i] = C[i] + C[i - 1];
    }

    for (int j = A.length - 1; j >= 0; j--) {
        B[C[A[j]] - 1] = A[j]; 
        C[A[j]] = C[A[j]] - 1;
    }
}

//----------------------------------------------------------------

public class CountingSort {
    public static void main(String[] args) {
        int A[]={32,8,9,16,15,47,77,10,11,3,2,1,54,25,6,4,7};
        int  B[]= new int[A.length];
        countingSort(A,B,77);
        for(int i=0;i<B.length;i++){
            System.out.println(B[i]);
        }        
    }
    public static void countingSort(int A[],int B[],int k){
        int C[] = new int[k+1];
        for(int j=0;j<A.length;j++){
            C[A[j]]+=1;
        }
        for(int i=1;i<=k;i++){
            C[i]+=C[i-1];
        }
        for(int j=A.length-1;j>=0;j--){
            B[--C[A[j]]]=A[j];
        }
    }
}