/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.matrizbotonesimagen;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author 52444
 */
public class MatrizbotonesImagen  extends JFrame implements ActionListener{

   private final JButton[][] botones = new JButton[4][4];
 

    // Constructor de la ventana del juego
    public MatrizbotonesImagen () {
        // Configurar la ventana
        setTitle("Panel");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Centra la ventana en la pantalla

        // Configuración del layout
        setLayout(new GridLayout(4, 4));  // Un grid de 3x3 para los botones

        // Crear los botones para cada celda del juego
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                botones[i][j] = new JButton();
                botones[i][j].setFont(new Font("Arial", Font.PLAIN, 60));
                botones[i][j].setFocusPainted(false);
                botones[i][j].setEnabled(true);  // Habilitar el botón inicialmente
                botones[i][j].addActionListener(this);  // Añadir el escuchador de eventos
                add(botones[i][j]);
            }
        }
    }

   private void reiniciarJuego() {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            botones[i][j].setIcon(null);  // Quitar las imágenes
            botones[i][j].setEnabled(true);  
        }
    }
}


    public static void main(String[] args) {
        // Crear la ventana y mostrarla
        SwingUtilities.invokeLater(() -> {
            new MatrizbotonesImagen ().setVisible(true);
        });
    }

    @Override
  public void actionPerformed(ActionEvent e) {
    JButton fuente = (JButton) e.getSource();

    if (fuente.getIcon() == null) {  
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/img/lbt1.jpg"));
        Image imagenRedimensionada = iconoOriginal.getImage().getScaledInstance(fuente.getWidth(), fuente.getHeight(), Image.SCALE_SMOOTH);
        fuente.setIcon(new ImageIcon(imagenRedimensionada));
    }
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            if (botones[i][j].getIcon() == null) {
                return; 
            }
        }
    }
    reiniciarJuego();
}
    
}

