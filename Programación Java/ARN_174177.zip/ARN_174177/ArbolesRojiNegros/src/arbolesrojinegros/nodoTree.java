

package arbolesrojinegros;


public class nodoTree<T extends Comparable<T>> {

    T key;
    nodoTree left;
    nodoTree right;
    nodoTree parent;
    boolean color;

    public nodoTree(T key) {
        this.key = key;
        this.left = null;
        this.right = null;
        this.parent = null;
        this.color = false;
    }

}
