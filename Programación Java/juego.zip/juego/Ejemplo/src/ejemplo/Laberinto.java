/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ejemplo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.Scanner;

public class Laberinto extends javax.swing.JFrame implements KeyListener {

    private int personajeSeleccionado = 0;
    private Image imagenPersonaje; 
    private int personajeX = 1;
    private int personajeY = 1;
    private final int CELDA_SIZE = 40;
    private int[][] celdas = new int[10][10];
    
    public datos objDatos;
    
    public Laberinto() {
        initComponents();
        this.objDatos = new datos();
        configurarComponentes();
    }
    public Laberinto(datos objd) {
       initComponents();
        this.objDatos = objd;
        if (objd != null && objd.getPersonajeSeleccionado() >= 0) {
            personajeSeleccionado = objd.getPersonajeSeleccionado();
            //System.out.println("Personaje seleccionado: " + personajeSeleccionado);
        }
        configurarComponentes();
    }
    
    private void configurarComponentes() {
       
        getContentPane().removeAll();
        getContentPane().setLayout(null);
        
      
        setSize(450, 450);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Laberinto");
        
        
        cargarLaberinto("laberinto.txt");
        
        
        cargarImagenPersonaje();
        
       
        MiPanel panel = new MiPanel();
        panel.setBounds(0, 0, 450, 450);
        getContentPane().add(panel);
        
       
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int keyCode = e.getKeyCode();
                int nuevaX = personajeX;
                int nuevaY = personajeY;
                
                switch (keyCode) {
                    case KeyEvent.VK_UP:
                        nuevaY--;
                        break;
                    case KeyEvent.VK_DOWN:
                        nuevaY++;
                        break;
                    case KeyEvent.VK_LEFT:
                        nuevaX--;
                        break;
                    case KeyEvent.VK_RIGHT:
                        nuevaX++;
                        break;
                }
                if (nuevaX >= 0 && nuevaX < 10 && nuevaY >= 0 && nuevaY < 10 && celdas[nuevaY][nuevaX] == 0) {
                    personajeX = nuevaX;
                    personajeY = nuevaY;
                    panel.repaint(); 
                    //System.out.println("Personaje movido a: " + personajeX + "," + personajeY);
                }
            }
        });
        
        setFocusable(true);
        requestFocus();
    }
    
  private void cargarLaberinto(String ruta) {
        try {
            File archivo = new File(ruta);
            //System.out.println("Intentando cargar laberinto desde: " + archivo.getAbsolutePath());
            
            if (!archivo.exists()) {
                System.out.println("Archivo no encontrado. Creando laberinto por defecto.");
                
                return;
            }
            
            Scanner scanner = new Scanner(archivo);
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    if (scanner.hasNextInt()) {
                        celdas[i][j] = scanner.nextInt();
                    } else {
                        celdas[i][j] = 1; 
                    }
                }
            }
            scanner.close();
            //System.out.println("Laberinto cargado con éxito");

            //imprimirLaberinto();
            
        } catch (Exception e) {
            System.err.println("Error al cargar el laberinto: " + e.getMessage());
            e.printStackTrace();
           
        }
    }
    
    /*private void imprimirLaberinto() {
        System.out.println("Estado del laberinto:");
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print(celdas[i][j] + " ");
            }
            System.out.println();
        }
    }*/



  
    private void cargarImagenPersonaje() {
        try {
            String rutaImagen = "/img/P" + (personajeSeleccionado + 1) + ".jpeg";
            //System.out.println("Intentando cargar imagen: " + rutaImagen);
            
            ImageIcon icono = new ImageIcon(getClass().getResource(rutaImagen));
            if (icono.getIconWidth() <= 0) {
                System.out.println("No se pudo cargar la imagen, usando imagen por defecto");
                return;
            }
            imagenPersonaje = icono.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
            //System.out.println("Imagen cargada correctamente");
        } catch (Exception e) {
            System.err.println("Error al cargar la imagen: " + e.getMessage());
            e.printStackTrace();
            
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
       
    }

    @Override
    public void keyPressed(KeyEvent e) {
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
    
  
    class MiPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, getWidth(), getHeight());
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    if (celdas[i][j] == 1) {
                        g.setColor(Color.BLACK);
                        g.fillRect(j * CELDA_SIZE, i * CELDA_SIZE, CELDA_SIZE, CELDA_SIZE);
                    } else {
                        g.setColor(Color.LIGHT_GRAY);
                        g.drawRect(j * CELDA_SIZE, i * CELDA_SIZE, CELDA_SIZE, CELDA_SIZE);
                    }
                }
            }
            if (imagenPersonaje != null) {
                g.drawImage(imagenPersonaje, personajeX * CELDA_SIZE + 5, personajeY * CELDA_SIZE + 5, this); 
            } else {
                g.setColor(Color.RED);
                g.fillOval(personajeX * CELDA_SIZE + 5, personajeY * CELDA_SIZE + 5, 30, 30);
                
            }
        }
    }

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Laberinto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Laberinto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Laberinto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Laberinto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Laberinto().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
