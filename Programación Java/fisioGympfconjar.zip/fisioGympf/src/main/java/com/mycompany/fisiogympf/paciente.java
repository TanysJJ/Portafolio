/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fisiogympf;

/**
 *
 * @author 52444
 */
public class paciente {
    String nombre;
    String DNI; 
    String telefono;
    String estado;  
    int dia;
    int mes;
    int anio;  
    boolean bandera = true;
    private paciente pacienteObj;

   
    public paciente(String nombre, String DNI, String telefono, int dia, int mes, int anio) {
        this.nombre = nombre;
        this.DNI = DNI;
        this.telefono = telefono;
        this.estado = "Activo";  
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
        this.pacienteObj = null;
    }
    
   
    public paciente(String nombre, String DNI, String telefono, int dia, int mes, int anio, String estado) {
        this.nombre = nombre;
        this.DNI = DNI;
        this.telefono = telefono;
        this.estado = estado;
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
        this.pacienteObj = null;
    }

    
    public paciente(String nombre, String DNI, String telefono, int dia, int mes, int anio, int estadoInt) {
        this.nombre = nombre;
        this.DNI = DNI;
        this.telefono = telefono;
        this.estado = (estadoInt == 1) ? "Activo" : "Inactivo";
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
        this.pacienteObj = null;
    }

   
    public String getNombre() {
        return nombre;
    }

    public String getDNI() {
        return DNI;
    }

    public String getTelefono() {
        return telefono;
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAño() { 
        return anio;
    }
    
    public int getAnio() {  
        return anio;
    }

    public String getEstado() {
        return estado;
    }
    
   
    public int getEstadoInt() {
        return estado.equals("Activo") ? 1 : 2;
    }
    
    // Setters
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void setDNI(String DNI) {
        this.DNI = DNI;
    }
    
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public void setEstado(int estadoInt) {
        this.estado = (estadoInt == 1) ? "Activo" : "Inactivo";
    }
    
    public void setDia(int dia) {
        this.dia = dia;
    }
    
    public void setMes(int mes) {
        this.mes = mes;
    }
    
    public void setAnio(int anio) {
        this.anio = anio;
    }
    
    /**
     * Método para obtener la fecha de nacimiento formateada
     */
    public String getFechaNacimientoFormateada() {
        String[] meses = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", 
                         "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};
        String nombreMes = (mes >= 1 && mes <= 12) ? meses[mes-1] : "Desconocido";
        return dia + "/" + nombreMes + "/" + anio;
    }
    
    /**
     * Método toString para mostrar información del paciente
     * @return 
     */
    @Override
    public String toString() {
        return "Paciente{" +
                "nombre='" + nombre + '\'' +
                ", DNI='" + DNI + '\'' +
                ", telefono='" + telefono + '\'' +
                ", estado='" + estado + '\'' +
                ", fechaNacimiento=" + getFechaNacimientoFormateada() +
                '}';
    }
    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        paciente paciente = (paciente) obj;
        return DNI.equals(paciente.DNI);
    }
    
    /**
     * Método hashCode basado en el DNI
     * @return 
     */
    @Override
    public int hashCode() {
        return DNI.hashCode();
    }
}