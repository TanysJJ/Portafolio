public class HeapSort<E extends Comparable<E>> {
    private int heapSize;
    
    private void exchange(E A[], int i, int j) {
        E t = A[i - 1];
        A[i - 1] = A[j - 1];
        A[j - 1] = t;
    }
    
    private void maxHeapify(E A[], int i) {
        int l = 2 * i;
        int r = l + 1;
        int largest = 0;
        if (l <= heapSize && A[l - 1].compareTo(A[i - 1]) > 0)
            largest = l;
        else
            largest = i;
        if (r <= heapSize && A[r - 1].compareTo(A[largest - 1]) > 0)
            largest = r;
        if (largest != i) {
            exchange(A, i, largest);
            maxHeapify(A, largest);
        }
    }
    
    private void buildMaxHeap(E A[]) {
        heapSize = A.length;
        for (int i = A.length / 2; i > 0; i--)
            maxHeapify(A, i);
    }
    
    public void heapSort(E A[]) {
        buildMaxHeap(A); 
        for (int i = A.length; i > 1; i--) {
            exchange(A, 1, i);
            heapSize--;
            maxHeapify(A, 1); 
        }
    }
    
    public static void main(String[] args) {
        Integer A[] = {5, 9, 4, 8, 1, 3, 2};
        HeapSort heap = new HeapSort();
        heap.heapSort(A);
        for (int i = 0; i < A.length; i++){

            System.out.print(A[i] + ", ");
    }
}
