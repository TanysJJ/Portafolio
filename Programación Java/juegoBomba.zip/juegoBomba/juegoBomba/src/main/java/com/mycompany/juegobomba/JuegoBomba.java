/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.juegobomba;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JuegoBomba extends JFrame implements ActionListener{

   private final JButton[][] botones = new JButton[10][10];
   private final JButton [][] imagenes = new JButton[10][10];

    
    public JuegoBomba() {
     
        setTitle("Buscaminas");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  

       
        setLayout(new GridLayout(10, 10)); 

        
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                botones[i][j] = new JButton();
                botones[i][j].setFont(new Font("Arial", Font.PLAIN, 60));
                botones[i][j].setFocusPainted(false);
                botones[i][j].setEnabled(true); 
                botones[i][j].addActionListener(this);  
                add(botones[i][j]);
            }
        }
    }
    /*
    private void reiniciarJuego() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                botones[i][j].setText("");  // Limpiar el texto de los botones
                botones[i][j].setEnabled(true);  // Habilitar los botones nuevamente
            }
        }

    }
*/
    public static void main(String[] args) {
            new JuegoBomba().setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton fuente = (JButton) e.getSource();
       if (fuente.getIcon() == null) {  
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/img/bomba.jpg"));
        Image imagenRedimensionada = iconoOriginal.getImage().getScaledInstance(fuente.getWidth(), fuente.getHeight(), Image.SCALE_SMOOTH);
        fuente.setIcon(new ImageIcon(imagenRedimensionada));
        }
      }
}
