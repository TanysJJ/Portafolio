<?php
echo "<style>";
echo "table { 
    margin: 20px auto; /* Margen superior e inferior de 20px y centrado horizontal */
    border-collapse: collapse; /* Colapso de bordes para que se vean como una sola línea */
    width: 90%; /* Ancho del 90% del contenedor */
}";
echo "th, td { 
    padding: 10px; /* Añade espacio interno a celdas */
    text-align: center; /* Alineación del texto en el centro */
    border: 1px solid #ddd; /* Borde de 1px sólido de color gris */
}";
echo "th { 
    background-color: #7FB3D5 ; /* Color de fondo para los encabezados */
}";
echo "</style>";

echo "<table>";
echo "<tr>";
echo "<th>Id</th>";
echo "<th>Nombre</th>";
echo "<th>E-mail</th>";
echo "</tr>";

$conexion=mysqli_connect("localhost","id21895581_prograweb2","bd1Web2%","id21895581_bd1wb2") or die("Problemas en la conexion");

$registros=mysqli_query($conexion,"SELECT id, nombre, correo FROM personas WHERE id >= 1 AND id <= 50")
    or die("Problemas en el select: ".mysqli_error($conexion));

while($reg=mysqli_fetch_array($registros))
{
    echo "<tr>";
    echo "<td>".$reg['id']."</td>";
    echo "<td>".$reg['nombre']."</td>";
    echo "<td>".$reg['correo']."</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conexion);
?>
