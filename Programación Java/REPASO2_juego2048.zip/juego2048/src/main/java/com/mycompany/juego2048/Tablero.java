/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.juego2048;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Random;

public final class Tablero {
    private int[][] tablero;
    private final int FIL = 4;
    private final int COL = 4;
    private final Random random;
    
    private static final int[][] tableroGuardado = null;
 
    public Tablero() {
        tablero = new int[FIL][COL];
        random = new Random();
        for (int i = 0; i < FIL; i++) {
            for (int j = 0; j < COL; j++) {
                tablero[i][j] = 0;
            }
        }
        generarNuevoNumero();
        generarNuevoNumero();
    }
    
    public int getValor(int fila, int col) {
        return tablero[fila][col];
    }
    public boolean generarNuevoNumero() {
       
        ArrayList<int[]> celdasVacias = new ArrayList<>();
        for (int i = 0; i < FIL; i++) {
            for (int j = 0; j < COL; j++) {
                if (tablero[i][j] == 0) {
                    celdasVacias.add(new int[]{i, j});
                }
            }
        }
        if (celdasVacias.isEmpty()) {
            return false;
        }

        int[] posicion = celdasVacias.get(random.nextInt(celdasVacias.size()));
        tablero[posicion[0]][posicion[1]] = 2;
        
        return true;
    }
    public boolean moverArriba() {
        boolean movido = false; 
        for (int j = 0; j < COL; j++) {
            for (int i = 0; i < FIL; i++) {
                if (tablero[i][j] != 0) {
                    int fila = i;
                    while (fila > 0 && tablero[fila-1][j] == 0) {
                        tablero[fila-1][j] = tablero[fila][j];
                        tablero[fila][j] = 0;
                        fila--;
                        movido = true;
                    }
                }
            }
            for (int i = 0; i < FIL-1; i++) {
                if (tablero[i][j] != 0 && tablero[i][j] == tablero[i+1][j]) {
                    tablero[i][j] *= 2;
                    tablero[i+1][j] = 0;
                    movido = true;
                    
                    
                    for (int k = i+1; k < FIL-1; k++) {
                        tablero[k][j] = tablero[k+1][j];
                        tablero[k+1][j] = 0;
                    }
                }
            }
        }
        if (movido) {
            generarNuevoNumero();
        }
        
        return movido;
    }
    public boolean moverAbajo() {
        boolean movido = false;
        for (int j = 0; j < COL; j++) {
           
            for (int i = FIL-1; i >= 0; i--) {
                if (tablero[i][j] != 0) {
                    int fila = i;
                    while (fila < FIL-1 && tablero[fila+1][j] == 0) {
                        tablero[fila+1][j] = tablero[fila][j];
                        tablero[fila][j] = 0;
                        fila++;
                        movido = true;
                    }
                }
            }
            for (int i = FIL-1; i > 0; i--) {
                if (tablero[i][j] != 0 && tablero[i][j] == tablero[i-1][j]) {
                    tablero[i][j] *= 2;
                    tablero[i-1][j] = 0;
                    movido = true;
                    
                    
                    for (int k = i-1; k > 0; k--) {
                        tablero[k][j] = tablero[k-1][j];
                        tablero[k-1][j] = 0;
                    }
                }
            }
        }
        if (movido) {
            generarNuevoNumero();
        }
        return movido;
    }
    public boolean moverIzquierda() {
        boolean movido = false;
        for (int i = 0; i < FIL; i++) {
            for (int j = 0; j < COL; j++) {
                if (tablero[i][j] != 0) {
                    int col = j;
                    while (col > 0 && tablero[i][col-1] == 0) {
                        tablero[i][col-1] = tablero[i][col];
                        tablero[i][col] = 0;
                        col--;
                        movido = true;
                    }
                }
            }      
            for (int j = 0; j < COL-1; j++) {
                if (tablero[i][j] != 0 && tablero[i][j] == tablero[i][j+1]) {
                    tablero[i][j] *= 2;
                    tablero[i][j+1] = 0;
                    movido = true;
                    
                    
                    for (int k = j+1; k < COL-1; k++) {
                        tablero[i][k] = tablero[i][k+1];
                        tablero[i][k+1] = 0;
                    }
                }
            }
        }
        if (movido) {
            generarNuevoNumero();
        }
        
        return movido;
    }
    public boolean moverDerecha() {
        boolean movido = false;
        for (int i = 0; i < FIL; i++) {
            
            for (int j = COL-1; j >= 0; j--) {
                if (tablero[i][j] != 0) {
                    int col = j;
                    while (col < COL-1 && tablero[i][col+1] == 0) {
                        tablero[i][col+1] = tablero[i][col];
                        tablero[i][col] = 0;
                        col++;
                        movido = true;
                    }
                }
            }
            for (int j = COL-1; j > 0; j--) {
                if (tablero[i][j] != 0 && tablero[i][j] == tablero[i][j-1]) {
                    tablero[i][j] *= 2;
                    tablero[i][j-1] = 0;
                    movido = true;

                    for (int k = j-1; k > 0; k--) {
                        tablero[i][k] = tablero[i][k-1];
                        tablero[i][k-1] = 0;
                    }
                }
            }
        }
        if (movido) {
            generarNuevoNumero();
        }
        return movido;
    }
    public boolean ganador() {
        for (int i = 0; i < FIL; i++) {
            for (int j = 0; j < COL; j++) {
                if (tablero[i][j] == 2048) {
                    return true;
                }
            }
        }
        return false;
    }
    public boolean finPartida() {
       
        if (ganador()) {
            return true;
        } 
        for (int i = 0; i < FIL; i++) {
            for (int j = 0; j < COL; j++) {
                if (tablero[i][j] == 0) {
                    return false;
                }
            }
        }
        for (int i = 0; i < FIL; i++) {
            for (int j = 0; j < COL-1; j++) {
                if (tablero[i][j] == tablero[i][j+1]) {
                    return false;
                }
            }
        } 
        for (int i = 0; i < FIL-1; i++) {
            for (int j = 0; j < COL; j++) {
                if (tablero[i][j] == tablero[i+1][j]) {
                    return false;
                }
            }
        }
        return true;
    }
    public void guardarEstado() {
    try {
        
        File tempFile = File.createTempFile("tablero_temp", ".dat");
        tempFile.deleteOnExit(); 
        
        try (FileOutputStream fos = new FileOutputStream(tempFile);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
           
            oos.writeObject(this.tablero);
        }
        
        
        File archivoGuardado = new File("tablero_guardado.dat");
        if (archivoGuardado.exists()) {
            archivoGuardado.delete();
        }
        
        
        tempFile.renameTo(archivoGuardado);
        
    } catch (IOException e) {
        System.err.println("Error al guardar el estado: " + e.getMessage());
    }
}
    public static Tablero cargarEstado() {
     Tablero nuevoTablero = new Tablero();
    
        try {
        File archivoGuardado = new File("tablero_guardado.dat");
            if (archivoGuardado.exists()) {
                try (FileInputStream fis = new FileInputStream(archivoGuardado);
                 ObjectInputStream ois = new ObjectInputStream(fis)) {
                
              
                 int[][] matrizGuardada = (int[][]) ois.readObject();
                 nuevoTablero.setMatriz(matrizGuardada);
            }
        }
    } catch (IOException | ClassNotFoundException e) {
        System.err.println("Error al cargar el estado: " + e.getMessage());
    }
    
    return nuevoTablero;
}
    public static boolean hayPartidaGuardada() {
        File archivoGuardado = new File("tablero_guardado.dat");
        return archivoGuardado.exists() && archivoGuardado.length() > 0;
    }
    public void setMatriz(int[][] matriz) {
        this.tablero = matriz;  
    }
}