/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fisiogympf;
import java.util.*;
/**
 *
 * @author 52444
 */
public class datosP {
    private ArrayList<paciente> pacientes;
    
    public datosP(){
        this.pacientes = new ArrayList();
    }
    
    public void agregarPaciente(paciente objPaciente){
        this.pacientes.add(objPaciente);
    }
    
    public ArrayList<paciente> getPacientes(){
        return pacientes;
    }
    
    
    public void actualizarPaciente(int indice, paciente pacienteActualizado) {
        if (indice >= 0 && indice < pacientes.size()) {
            pacientes.set(indice, pacienteActualizado);
        }
    }
    
    public void eliminarPaciente(int indice) {
    if (indice >= 0 && indice < pacientes.size()) {
        pacientes.remove(indice);
    }
}
}