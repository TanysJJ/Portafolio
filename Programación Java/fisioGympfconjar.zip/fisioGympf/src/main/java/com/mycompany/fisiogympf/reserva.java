/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.fisiogympf;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Map;
import java.util.HashMap;
import javax.swing.*;
import javax.swing.border.EmptyBorder;



public class reserva extends javax.swing.JFrame {

    private datosP objDatos;
    private datosC objDatosCitas;
    private JPanel calendarPanel;
    private JLabel monthYearLabel;
    private JButton prevMonthButton;
    private JButton nextMonthButton;
    private JButton[][] calendarDays;
    private LocalDate currentDate;
    private LocalDate selectedDate;
    private static final int START_HOUR = 8; // 8 AM
    private static final int END_HOUR = 18; // 6 PM
    private static final int MAX_SLOTS_PER_AREA = 3;
     private SalaEspera salaDeEspera; 
    
    public reserva() {
        initComponents();
        this.objDatos = new datosP();
        this.objDatosCitas = new datosC();
        initializeCalendar();
        this.salaDeEspera = new SalaEspera();
        cargarPacientes();
    }
    
    public reserva(datosP objd) {
        initComponents(); 
        this.objDatos = objd;
        this.objDatosCitas = new datosC();
        initializeCalendar();
        cargarPacientes();
        this.salaDeEspera = new SalaEspera(); 
    }
    
    public reserva(datosP objd, datosC objc) {
        initComponents(); 
        this.objDatos = objd;
        this.objDatosCitas = objc;
        initializeCalendar();
        cargarPacientes();
        this.salaDeEspera = new SalaEspera();
        guardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarCita();
            }
        });

        actualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarCita();
            }
        });

        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarCita();
            }
        });
    }
    
    private void cargarPacientes() {
        paciente.removeAllItems();
        if (objDatos.getPacientes().isEmpty()) {
            paciente.addItem("No hay pacientes registrados");
        } else {
            for (paciente p : objDatos.getPacientes()) {
                paciente.addItem(p.getNombre());
            }
        }
    }
    
    private void initializeCalendar() {
        currentDate = LocalDate.now();
        selectedDate = null;
        
        calendarPanel = new JPanel();
        calendarPanel.setLayout(new BorderLayout());
        calendarPanel.setBackground(new Color(255, 255, 255));
        
        // Panel de navegación
        JPanel navigationPanel = new JPanel();
        navigationPanel.setBackground(new Color(204, 204, 255));
        
        prevMonthButton = new JButton("<<");
        monthYearLabel = new JLabel("", JLabel.CENTER);
        monthYearLabel.setFont(new Font("Verdana", Font.BOLD, 14));
        nextMonthButton = new JButton(">>");
        
        navigationPanel.add(prevMonthButton);
        navigationPanel.add(monthYearLabel);
        navigationPanel.add(nextMonthButton);
        
        // Panel de días de la semana
        JPanel weekDaysPanel = new JPanel(new GridLayout(1, 7));
        weekDaysPanel.setBackground(new Color(204, 224, 255));
        String[] weekDays = {"Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"};
        for (String day : weekDays) {
            JLabel label = new JLabel(day, JLabel.CENTER);
            label.setFont(new Font("Verdana", Font.BOLD, 12));
            weekDaysPanel.add(label);
        }
        
        // Panel de días del mes
        JPanel daysPanel = new JPanel(new GridLayout(6, 7));
        daysPanel.setBackground(new Color(255, 255, 255));
        
        calendarDays = new JButton[6][7];
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                calendarDays[i][j] = new JButton();
                calendarDays[i][j].setBackground(Color.WHITE);
                calendarDays[i][j].setBorder(new EmptyBorder(2, 2, 2, 2));
                final int row = i;
                final int col = j;
                calendarDays[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        dayButtonClicked(row, col);
                    }
                });
                daysPanel.add(calendarDays[i][j]);
            }
        }
        
        // Listeners para navegación
        prevMonthButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentDate = currentDate.minusMonths(1);
                updateCalendar();
            }
        });
        
        nextMonthButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentDate = currentDate.plusMonths(1);
                updateCalendar();
            }
        });
        
        // Ensamblar calendario
        calendarPanel.add(navigationPanel, BorderLayout.NORTH);
        calendarPanel.add(weekDaysPanel, BorderLayout.CENTER);
        calendarPanel.add(daysPanel, BorderLayout.SOUTH);
        
        // Colocar en el scroll
        jScrollPane1.setViewportView(calendarPanel);
        
        // Actualizar calendario
        updateCalendar();
        
        // Listener para área
        area.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (selectedDate != null) {
                    updateAvailableHours();
                }
            }
        });
        
        // Listener para duración
        elegirhora.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (selectedDate != null) {
                    updateAvailableHours();
                }
            }
        });
    }
    
    private void updateCalendar() {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
    monthYearLabel.setText(currentDate.format(formatter));

    YearMonth yearMonth = YearMonth.from(currentDate);
    int daysInMonth = yearMonth.lengthOfMonth();
    LocalDate firstDayOfMonth = currentDate.withDayOfMonth(1);
    int dayOfWeek = firstDayOfMonth.getDayOfWeek().getValue() % 7; 

    LocalDate today = LocalDate.now();

   
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 7; j++) {
            calendarDays[i][j].setText("");
            calendarDays[i][j].setEnabled(false);
            calendarDays[i][j].setBackground(Color.WHITE);
            calendarDays[i][j].setForeground(Color.BLACK);
        }
    }

   
    int day = 1;
    for (int i = 0; i < 6 && day <= daysInMonth; i++) {
        for (int j = 0; j < 7 && day <= daysInMonth; j++) {
            if (i == 0 && j < dayOfWeek) {
                continue;
            }

            LocalDate dateToCheck = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), day);
            calendarDays[i][j].setText(String.valueOf(day));

          
            if (dateToCheck.isBefore(today)) {
                if (tieneCitas(dateToCheck)) {
                    calendarDays[i][j].setEnabled(true); // ✅ Permitir clic en días pasados con citas
                    calendarDays[i][j].setBackground(new Color(255, 230, 230)); // Fondo rosa claro
                    calendarDays[i][j].setForeground(Color.RED); // Texto rojo
                } else {
                    calendarDays[i][j].setEnabled(false);
                    calendarDays[i][j].setForeground(Color.GRAY);
                }
            } else {
                calendarDays[i][j].setEnabled(true);
                
              
                if (dateToCheck.equals(today)) {
                    calendarDays[i][j].setBackground(new Color(173, 216, 230)); 
                }

                // **Marcar días con citas en rojo**
                if (tieneCitas(dateToCheck)) {
                    calendarDays[i][j].setForeground(Color.RED);
                } else {
                    calendarDays[i][j].setForeground(Color.BLACK);
                }
            }

           
            if (selectedDate != null && dateToCheck.equals(selectedDate)) {
                calendarDays[i][j].setBackground(new Color(144, 238, 144)); 
            }

            day++;
        }
    }
}
    
    private boolean tieneCitas(LocalDate fecha) {
        for (citas cita : objDatosCitas.getCitas()) {
            if (cita.getDia() == fecha.getDayOfMonth() && 
                cita.getMes() == fecha.getMonthValue() && 
                cita.getAño() == fecha.getYear()) {
                return true;
            }
        }
        return false;
    }
    private void updateAvailableHoursHistorico() {
    if (selectedDate == null) return;
    
    StringBuilder sb = new StringBuilder();
    String selectedAreaText = (String) area.getSelectedItem();
    
    sb.append("📅 HISTORIAL DE CITAS - ").append(formatDate(selectedDate)).append("\n");
    sb.append("Área: ").append(selectedAreaText).append("\n");
    sb.append("(Solo lectura - día pasado)\n\n");
    
    
    ArrayList<citas> citasDelDia = new ArrayList<>();
    for (citas cita : objDatosCitas.getCitas()) {
        if (cita.getDia() == selectedDate.getDayOfMonth() && 
            cita.getMes() == selectedDate.getMonthValue() && 
            cita.getAño() == selectedDate.getYear()) {
            citasDelDia.add(cita);
        }
    }
    
    if (citasDelDia.isEmpty()) {
        sb.append("No hubo citas este día.\n");
    } else {
        sb.append("--- CITAS REALIZADAS ---\n");
        
        
        Map<String, ArrayList<citas>> citasPorArea = new HashMap<>();
        for (citas c : citasDelDia) {
            citasPorArea.computeIfAbsent(c.getServicio(), k -> new ArrayList<>()).add(c);
        }
        
        for (Map.Entry<String, ArrayList<citas>> entry : citasPorArea.entrySet()) {
            String area = entry.getKey();
            ArrayList<citas> citasArea = entry.getValue();
            citasArea.sort((c1, c2) -> Integer.compare(c1.getHora(), c2.getHora()));
            
            sb.append("\n🏥 ").append(area).append(":\n");
            
            
            Map<String, ArrayList<citas>> citasPorPaciente = new HashMap<>();
            for (citas c : citasArea) {
                citasPorPaciente.computeIfAbsent(c.getPaciente(), k -> new ArrayList<>()).add(c);
            }
            
            for (Map.Entry<String, ArrayList<citas>> entryPaciente : citasPorPaciente.entrySet()) {
                String paciente = entryPaciente.getKey();
                ArrayList<citas> citasPaciente = entryPaciente.getValue();
                citasPaciente.sort((c1, c2) -> Integer.compare(c1.getHora(), c2.getHora()));
                
                if (citasPaciente.size() == 1) {
                    citas c = citasPaciente.get(0);
                    sb.append("   ").append(formatHour(c.getHora())).append(" - ")
                      .append(paciente).append(" (1 hora)\n");
                } else {
                  
                    boolean consecutivas = true;
                    for (int i = 1; i < citasPaciente.size(); i++) {
                        if (citasPaciente.get(i).getHora() != citasPaciente.get(i-1).getHora() + 1) {
                            consecutivas = false;
                            break;
                        }
                    }
                    
                    if (consecutivas) {
                        citas primera = citasPaciente.get(0);
                        sb.append("   ").append(formatHour(primera.getHora())).append("-")
                          .append(formatHour(primera.getHora() + citasPaciente.size()))
                          .append(" - ").append(paciente).append(" (")
                          .append(citasPaciente.size()).append(" horas)\n");
                    } else {
                        for (citas c : citasPaciente) {
                            sb.append("   ").append(formatHour(c.getHora())).append(" - ")
                              .append(paciente).append(" (1 hora)\n");
                        }
                    }
                }
            }
        }
        
        sb.append("\nTotal de citas: ").append(citasDelDia.size()).append("\n");
    }
    
    horario.setText(sb.toString());
}
private void dayButtonClicked(int row, int col) {
    String dayText = calendarDays[row][col].getText();
    if (!dayText.isEmpty()) {
        int day = Integer.parseInt(dayText);
        selectedDate = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), day);
        
        LocalDate today = LocalDate.now();
        
        updateCalendar();
        actualizarEstadoBotones(); 
        
        if (selectedDate.isBefore(today)) {
            updateAvailableHoursHistorico();
        } else {
            updateAvailableHours();
        }
    }
}
private boolean guardandoCita = false;

   private void updateAvailableHours() {
    if (selectedDate == null) return;
    
    // EVITAR ACTUALIZACIONES DURANTE EL GUARDADO
    if (guardandoCita) return;
    
    StringBuilder sb = new StringBuilder();
    String selectedAreaText = (String) area.getSelectedItem();
    
    sb.append("Horarios para ").append(formatDate(selectedDate)).append("\n");
    sb.append("Área: ").append(selectedAreaText).append("\n\n");
    
    for (int hour = START_HOUR; hour < END_HOUR; hour++) {
        int occupiedSlots = getOccupiedSlots(selectedDate, hour, selectedAreaText);
        int availableSlots = MAX_SLOTS_PER_AREA - occupiedSlots;
        
        String timeStr = formatHour(hour);
        String status = (availableSlots > 0) ? 
                "Disponible (" + availableSlots + " espacios)" : 
                "Completo";
        
        sb.append(timeStr).append(": ").append(status).append("\n");
    }
    
    // MOSTRAR CITAS AGRUPADAS POR PACIENTE
    ArrayList<citas> citasDelDia = new ArrayList<>();
    for (citas cita : objDatosCitas.getCitas()) {
        if (cita.getDia() == selectedDate.getDayOfMonth() && 
            cita.getMes() == selectedDate.getMonthValue() && 
            cita.getAño() == selectedDate.getYear()) {
            citasDelDia.add(cita);
        }
    }
    
    if (!citasDelDia.isEmpty()) {
        sb.append("\n--- CITAS PROGRAMADAS ---\n");
        
        // Agrupar citas por paciente y servicio
        Map<String, ArrayList<citas>> citasPorGrupo = new HashMap<>();
        for (citas c : citasDelDia) {
            String key = c.getPaciente() + "_" + c.getServicio();
            citasPorGrupo.computeIfAbsent(key, k -> new ArrayList<>()).add(c);
        }
        
        for (Map.Entry<String, ArrayList<citas>> entry : citasPorGrupo.entrySet()) {
            ArrayList<citas> citasGrupo = entry.getValue();
            citasGrupo.sort((c1, c2) -> Integer.compare(c1.getHora(), c2.getHora()));
            
            String[] partes = entry.getKey().split("_");
            String pacienteNombre = partes[0];
            String servicio = partes[1];
            
            if (citasGrupo.size() == 1) {
                citas c = citasGrupo.get(0);
                sb.append(formatHour(c.getHora())).append(" - ")
                  .append(pacienteNombre).append(" (")
                  .append(servicio).append(") - 1 hora\n");
            } else {
                // Verificar si son consecutivas (cita de 2 horas)
                boolean consecutivas = true;
                for (int i = 1; i < citasGrupo.size(); i++) {
                    if (citasGrupo.get(i).getHora() != citasGrupo.get(i-1).getHora() + 1) {
                        consecutivas = false;
                        break;
                    }
                }
                
                if (consecutivas) {
                    citas primera = citasGrupo.get(0);
                    sb.append(formatHour(primera.getHora())).append("-")
                      .append(formatHour(primera.getHora() + citasGrupo.size()))
                      .append(" - ").append(pacienteNombre).append(" (")
                      .append(servicio).append(") - ")
                      .append(citasGrupo.size()).append(" horas\n");
                } else {
                    // Mostrar individualmente si no son consecutivas
                    for (citas c : citasGrupo) {
                        sb.append(formatHour(c.getHora())).append(" - ")
                          .append(pacienteNombre).append(" (")
                          .append(servicio).append(") - 1 hora\n");
                    }
                }
            }
        }
    }
    
    horario.setText(sb.toString());
}
    private int getOccupiedSlots(LocalDate date, int hour, String areaName) {
        int count = 0;
        for (citas cita : objDatosCitas.getCitas()) {
            if (cita.getDia() == date.getDayOfMonth() && 
                cita.getMes() == date.getMonthValue() && 
                cita.getAño() == date.getYear() && 
                cita.getHora() == hour && 
                cita.getServicio().equals(areaName)) {
                count++;
            }
        }
        return count;
    }
    
    private String formatDate(LocalDate date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return date.format(formatter);
    }
    
    private String formatHour(int hour) {
        return hour + ":00";
    }
    
   private void guardarCita() {
    if (selectedDate == null) {
        JOptionPane.showMessageDialog(this, "Por favor seleccione una fecha en el calendario", 
                "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (paciente.getSelectedItem() == null || paciente.getSelectedItem().equals("No hay pacientes registrados")) {
        JOptionPane.showMessageDialog(this, "No hay pacientes registrados para agendar cita", 
                "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String pacienteNombre = (String) paciente.getSelectedItem();
    String areaSeleccionada = (String) area.getSelectedItem();
    
  
    String[] horasDisponibles = getHorasDisponibles(selectedDate, areaSeleccionada);
    
    if (horasDisponibles.length == 0) {
        JOptionPane.showMessageDialog(this, "No hay horarios disponibles para esta fecha, área y duración", 
                "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    String horaSeleccionada = (String) JOptionPane.showInputDialog(
        this,
        "Seleccione un horario disponible:",
        "Seleccionar Horario",
        JOptionPane.PLAIN_MESSAGE,
        null,
        horasDisponibles,
        horasDisponibles[0]);

    if (horaSeleccionada == null) {
        return; 
    }

    int hora = Integer.parseInt(horaSeleccionada.split(":")[0]);
    int duracion = elegirhora.getSelectedIndex() + 1; // 1 o 2 horas

  
    if (duracion == 2) {
        if (hora + 1 >= END_HOUR) { 
            JOptionPane.showMessageDialog(this, "No es posible reservar 2 horas en este horario.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (getOccupiedSlots(selectedDate, hora, areaSeleccionada) >= MAX_SLOTS_PER_AREA ||
            getOccupiedSlots(selectedDate, hora + 1, areaSeleccionada) >= MAX_SLOTS_PER_AREA) {
            JOptionPane.showMessageDialog(this, "No hay suficiente espacio para una sesión de 2 horas.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }

    // USAR UNA BANDERA PARA EVITAR LLAMADAS AUTOMÁTICAS
    boolean guardandoCita = true;

    try {
        // Crear las citas según la duración
        boolean exitoTotal = true;
        for (int i = 0; i < duracion; i++) {
            citas nuevaCita = new citas(
                pacienteNombre,
                selectedDate.getDayOfMonth(),
                selectedDate.getMonthValue(),
                selectedDate.getYear(),
                hora + i,
                areaSeleccionada);
            
            if (!objDatosCitas.agregarCita(nuevaCita)) {
                exitoTotal = false;
                break;
            }
        }

        if (exitoTotal) {
            String mensaje = duracion == 1 ? 
                "Cita guardada exitosamente!" : 
                "Cita de " + duracion + " horas guardada exitosamente!";
            JOptionPane.showMessageDialog(this, mensaje, "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Error al guardar la cita", 
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    } finally {
        guardandoCita = false;
        
        updateCalendar();
        updateAvailableHours();
    }
}

    private String[] getHorasDisponibles(LocalDate date, String areaName) {
        ArrayList<String> horasDisp = new ArrayList<>();
        
       
        int duracion = elegirhora.getSelectedIndex() + 1; // 1 o 2 horas
        
        for (int hour = START_HOUR; hour <= END_HOUR - duracion; hour++) {
            boolean disponible = true;
            
            
            for (int i = 0; i < duracion; i++) {
                int occupiedSlots = getOccupiedSlots(date, hour + i, areaName);
                if (occupiedSlots >= MAX_SLOTS_PER_AREA) {
                    disponible = false;
                    break;
                }
            }
            
            if (disponible) {
                horasDisp.add(formatHour(hour));
            }
        }
        
        return horasDisp.toArray(new String[0]);
    }
    private void cambiarHoraCita(ArrayList<citas> citasActuales) {
    citas citaBase = citasActuales.get(0);
    int duracionActual = citasActuales.size();
    
   
    elegirhora.setSelectedIndex(duracionActual - 1); // Establecer duración actual
    String[] horasDisponibles = getHorasDisponibles(selectedDate, citaBase.getServicio());
    
    if (horasDisponibles.length == 0) {
        JOptionPane.showMessageDialog(this, 
            "No hay horarios disponibles para " + duracionActual + " hora(s) en esta área", 
            "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    String nuevaHoraStr = (String) JOptionPane.showInputDialog(
            this, 
            "Seleccione la nueva hora para la cita de " + duracionActual + " hora(s):", 
            "Cambiar hora", 
            JOptionPane.QUESTION_MESSAGE, 
            null, 
            horasDisponibles, 
            horasDisponibles[0]);
    
    if (nuevaHoraStr == null) return;
    
    int nuevaHora = Integer.parseInt(nuevaHoraStr.split(":")[0]);
    
  
    for (citas cita : citasActuales) {
        objDatosCitas.getCitas().remove(cita);
    }
    
    
    for (int i = 0; i < duracionActual; i++) {
        citas nuevaCita = new citas(
                citaBase.getPaciente(), 
                citaBase.getDia(), 
                citaBase.getMes(), 
                citaBase.getAño(), 
                nuevaHora + i, 
                citaBase.getServicio());
        objDatosCitas.agregarCita(nuevaCita);
    }
    
    JOptionPane.showMessageDialog(this, "Hora actualizada correctamente", 
            "Éxito", JOptionPane.INFORMATION_MESSAGE);
    
    updateCalendar();
    updateAvailableHours();
   }
    private void agregarHoraCita(ArrayList<citas> citasActuales) {
    citas citaBase = citasActuales.get(0);
    
    // Determinar si se puede agregar antes o después
    ArrayList<String> opciones = new ArrayList<>();
    
    // Verificar si se puede agregar antes
    int horaAnterior = citasActuales.get(0).getHora() - 1;
    if (horaAnterior >= START_HOUR && 
        getOccupiedSlots(selectedDate, horaAnterior, citaBase.getServicio()) < MAX_SLOTS_PER_AREA) {
        opciones.add("Agregar 1 hora ANTES (" + formatHour(horaAnterior) + ")");
    }
    
    // Verificar si se puede agregar después
    int horaPosterior = citasActuales.get(citasActuales.size()-1).getHora() + 1;
    if (horaPosterior < END_HOUR && 
        getOccupiedSlots(selectedDate, horaPosterior, citaBase.getServicio()) < MAX_SLOTS_PER_AREA) {
        opciones.add("Agregar 1 hora DESPUÉS (" + formatHour(horaPosterior) + ")");
    }
    
    if (opciones.isEmpty()) {
        JOptionPane.showMessageDialog(this, 
            "No se puede agregar hora adicional. No hay espacios disponibles antes o después.", 
            "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    String opcionSeleccionada = (String) JOptionPane.showInputDialog(
            this, 
            "Seleccione dónde agregar la hora adicional:", 
            "Agregar hora", 
            JOptionPane.QUESTION_MESSAGE, 
            null, 
            opciones.toArray(new String[0]), 
            opciones.get(0));
    
    if (opcionSeleccionada == null) return;
    
    int nuevaHora;
    if (opcionSeleccionada.contains("ANTES")) {
        nuevaHora = horaAnterior;
    } else {
        nuevaHora = horaPosterior;
    }
    
    // Crear la nueva cita
    citas nuevaCita = new citas(
            citaBase.getPaciente(), 
            citaBase.getDia(), 
            citaBase.getMes(), 
            citaBase.getAño(), 
            nuevaHora, 
            citaBase.getServicio());
    
    objDatosCitas.agregarCita(nuevaCita);
    
    JOptionPane.showMessageDialog(this, 
        "Hora adicional agregada correctamente en " + formatHour(nuevaHora), 
        "Éxito", JOptionPane.INFORMATION_MESSAGE);
    
    updateCalendar();
    updateAvailableHours();
}
    private void actualizarEstadoBotones() {
    LocalDate today = LocalDate.now();
    boolean esDiaPasado = selectedDate != null && selectedDate.isBefore(today);
    
    // Deshabilitar botones de modificación para días pasados
    guardar.setEnabled(!esDiaPasado);
    actualizar.setEnabled(!esDiaPasado);
    eliminar.setEnabled(!esDiaPasado);
    
    if (esDiaPasado) {
        guardar.setToolTipText("No se pueden crear citas en días pasados");
        actualizar.setToolTipText("No se pueden modificar citas de días pasados");
        eliminar.setToolTipText("No se pueden eliminar citas de días pasados");
    } else {
        guardar.setToolTipText(null);
        actualizar.setToolTipText(null);
        eliminar.setToolTipText(null);
    }
}
    private void actualizarCita() {
         if (selectedDate == null) {
        JOptionPane.showMessageDialog(this, "Por favor seleccione una fecha en el calendario", 
                "Error", JOptionPane.ERROR_MESSAGE);
        return;
        }
        LocalDate today = LocalDate.now();
        if (selectedDate.isBefore(today)) {
            JOptionPane.showMessageDialog(this, "No se pueden modificar citas de días pasados", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        ArrayList<citas> citasDelDia = new ArrayList<>();
        for (citas cita : objDatosCitas.getCitas()) {
            if (cita.getDia() == selectedDate.getDayOfMonth() && 
                cita.getMes() == selectedDate.getMonthValue() && 
                cita.getAño() == selectedDate.getYear()) {
                citasDelDia.add(cita);
            }
        }
        
        if (citasDelDia.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay citas para actualizar en esta fecha", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
       
        Map<String, ArrayList<citas>> citasPorGrupo = new HashMap<>();
        for (citas c : citasDelDia) {
            String key = c.getPaciente() + "_" + c.getServicio();
            citasPorGrupo.computeIfAbsent(key, k -> new ArrayList<>()).add(c);
        }
        
        ArrayList<String> opcionesMostrar = new ArrayList<>();
        ArrayList<ArrayList<citas>> gruposCitas = new ArrayList<>();
        
        for (Map.Entry<String, ArrayList<citas>> entry : citasPorGrupo.entrySet()) {
            ArrayList<citas> grupo = entry.getValue();
            grupo.sort((c1, c2) -> Integer.compare(c1.getHora(), c2.getHora()));
            
            String[] partes = entry.getKey().split("_");
            String pacienteNombre = partes[0];
            String servicio = partes[1];
            
            if (grupo.size() == 1) {
                citas c = grupo.get(0);
                opcionesMostrar.add(pacienteNombre + " - " + formatHour(c.getHora()) + 
                                  " - " + servicio + " (1 hora)");
            } else {
                boolean consecutivas = true;
                for (int i = 1; i < grupo.size(); i++) {
                    if (grupo.get(i).getHora() != grupo.get(i-1).getHora() + 1) {
                        consecutivas = false;
                        break;
                    }
                }
                
                if (consecutivas) {
                    citas primera = grupo.get(0);
                    opcionesMostrar.add(pacienteNombre + " - " + formatHour(primera.getHora()) + 
                                      "-" + formatHour(primera.getHora() + grupo.size()) + 
                                      " - " + servicio + " (" + grupo.size() + " horas)");
                } else {
                    for (citas c : grupo) {
                        opcionesMostrar.add(pacienteNombre + " - " + formatHour(c.getHora()) + 
                                          " - " + servicio + " (1 hora)");
                        ArrayList<citas> grupoIndividual = new ArrayList<>();
                        grupoIndividual.add(c);
                        gruposCitas.add(grupoIndividual);
                    }
                    continue;
                }
            }
            gruposCitas.add(grupo);
        }
        
        String[] citasInfo = opcionesMostrar.toArray(new String[0]);
        
        String citaSeleccionada = (String) JOptionPane.showInputDialog(
                this, 
                "Seleccione la cita a actualizar:", 
                "Actualizar cita", 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                citasInfo, 
                citasInfo[0]);
        
        if (citaSeleccionada == null) {
            return;
        }
        
        int indexSeleccionado = -1;
        for (int i = 0; i < citasInfo.length; i++) {
            if (citasInfo[i].equals(citaSeleccionada)) {
                indexSeleccionado = i;
                break;
            }
        }
        
        if (indexSeleccionado == -1) return;
        
        ArrayList<citas> citasAActualizar = gruposCitas.get(indexSeleccionado);
        citas citaBase = citasAActualizar.get(0);
        
        String[] opciones = {"Paciente", "Hora", "Área de servicio", "Cancelar"};
        int opcionSeleccionada = JOptionPane.showOptionDialog(
                this, 
                "¿Qué desea actualizar?", 
                "Actualizar cita", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                opciones, 
                opciones[0]);
        
        switch (opcionSeleccionada) {
            case 0: 
                if (objDatos.getPacientes().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "No hay pacientes registrados", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                String[] pacientesNombres = new String[objDatos.getPacientes().size()];
                for (int i = 0; i < objDatos.getPacientes().size(); i++) {
                    pacientesNombres[i] = objDatos.getPacientes().get(i).getNombre();
                }
                
                String nuevoPaciente = (String) JOptionPane.showInputDialog(
                        this, 
                        "Seleccione el nuevo paciente:", 
                        "Actualizar paciente", 
                        JOptionPane.QUESTION_MESSAGE, 
                        null, 
                        pacientesNombres, 
                        citaBase.getPaciente());
                
                if (nuevoPaciente != null && !nuevoPaciente.equals(citaBase.getPaciente())) {
                    for (citas cita : citasAActualizar) {
                        int indexEnLista = objDatosCitas.getCitas().indexOf(cita);
                        citas citaActualizada = new citas(
                                nuevoPaciente, 
                                cita.getDia(), 
                                cita.getMes(), 
                                cita.getAño(), 
                                cita.getHora(), 
                                cita.getServicio());
                        objDatosCitas.getCitas().set(indexEnLista, citaActualizada);
                    }
                    JOptionPane.showMessageDialog(this, "Paciente actualizado correctamente", 
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
                break;
                
            case 1: 
                 String[] opcionesHora = {"Cambiar hora (mantener duración)", "Agregar hora adicional", "Cancelar"};
            int opcionHora = JOptionPane.showOptionDialog(
                    this, 
                    "¿Qué desea hacer con la hora?", 
                    "Modificar horario", 
                    JOptionPane.DEFAULT_OPTION, 
                    JOptionPane.QUESTION_MESSAGE, 
                    null, 
                    opcionesHora, 
                    opcionesHora[0]);

            switch (opcionHora) {
                case 0: // Cambiar hora
                    cambiarHoraCita(citasAActualizar);
                    break;
                case 1: // Agregar hora
                    agregarHoraCita(citasAActualizar);
                    break;
                default:
                    return;
        }
        break;
                
            case 2: 
                String[] areasServicio = {"Electroterapia", "Hidroterapia", "Reahabilitacion cardiaca", 
                        "Rehabilitacion neurologica", "Rehabilitacion ortopedica"};
                
                String nuevaArea = (String) JOptionPane.showInputDialog(
                        this, 
                        "Seleccione la nueva área de servicio:", 
                        "Actualizar área", 
                        JOptionPane.QUESTION_MESSAGE, 
                        null, 
                        areasServicio, 
                        citaBase.getServicio());
                
                if (nuevaArea != null && !nuevaArea.equals(citaBase.getServicio())) {
                  
                    boolean disponible = true;
                    for (citas cita : citasAActualizar) {
                        int occupiedSlots = getOccupiedSlots(selectedDate, cita.getHora(), nuevaArea);
                        if (occupiedSlots >= MAX_SLOTS_PER_AREA) {
                            disponible = false;
                            break;
                        }
                    }
                    
                    if (!disponible) {
                        JOptionPane.showMessageDialog(this, "No hay espacio disponible en esa área para todas las horas", 
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    
                    for (citas cita : citasAActualizar) {
                        int indexEnLista = objDatosCitas.getCitas().indexOf(cita);
                        citas citaActualizada = new citas(
                                cita.getPaciente(), 
                                cita.getDia(), 
                                cita.getMes(), 
                                cita.getAño(), 
                                cita.getHora(), 
                                nuevaArea);
                        objDatosCitas.getCitas().set(indexEnLista, citaActualizada);
                    }
                    JOptionPane.showMessageDialog(this, "Área actualizada correctamente", 
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
                break;
                
            default:
                return;
        }
        
        updateCalendar();
        updateAvailableHours();
    }
    
    private void eliminarCita() {
        if (selectedDate == null) {
            JOptionPane.showMessageDialog(this, "Por favor seleccione una fecha en el calendario", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Obtener citas del día
        ArrayList<citas> citasDelDia = new ArrayList<>();
        for (citas cita : objDatosCitas.getCitas()) {
            if (cita.getDia() == selectedDate.getDayOfMonth() && 
                cita.getMes() == selectedDate.getMonthValue() && 
                cita.getAño() == selectedDate.getYear()) {
                citasDelDia.add(cita);
            }
        }
        
        if (citasDelDia.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay citas para eliminar en esta fecha", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // AGRUPAR CITAS POR PACIENTE Y SERVICIO para mostrar correctamente
        Map<String, ArrayList<citas>> citasPorGrupo = new HashMap<>();
        for (citas c : citasDelDia) {
            String key = c.getPaciente() + "_" + c.getServicio();
            citasPorGrupo.computeIfAbsent(key, k -> new ArrayList<>()).add(c);
        }
        
        ArrayList<String> opcionesMostrar = new ArrayList<>();
        ArrayList<ArrayList<citas>> gruposCitas = new ArrayList<>();
        
        for (Map.Entry<String, ArrayList<citas>> entry : citasPorGrupo.entrySet()) {
            ArrayList<citas> grupo = entry.getValue();
            grupo.sort((c1, c2) -> Integer.compare(c1.getHora(), c2.getHora()));
            
            String[] partes = entry.getKey().split("_");
            String pacienteNombre = partes[0];
            String servicio = partes[1];
            
            if (grupo.size() == 1) {
                citas c = grupo.get(0);
                opcionesMostrar.add(pacienteNombre + " - " + formatHour(c.getHora()) + 
                                  " - " + servicio + " (1 hora)");
            } else {
                // Verificar si son consecutivas
                boolean consecutivas = true;
                for (int i = 1; i < grupo.size(); i++) {
                    if (grupo.get(i).getHora() != grupo.get(i-1).getHora() + 1) {
                        consecutivas = false;
                        break;
                    }
                }
                
                if (consecutivas) {
                    citas primera = grupo.get(0);
                    opcionesMostrar.add(pacienteNombre + " - " + formatHour(primera.getHora()) + 
                                      "-" + formatHour(primera.getHora() + grupo.size()) + 
                                      " - " + servicio + " (" + grupo.size() + " horas)");
                } else {
                    // Si no son consecutivas, mostrar cada una por separado
                    for (citas c : grupo) {
                        opcionesMostrar.add(pacienteNombre + " - " + formatHour(c.getHora()) + 
                                          " - " + servicio + " (1 hora)");
                        ArrayList<citas> grupoIndividual = new ArrayList<>();
                        grupoIndividual.add(c);
                        gruposCitas.add(grupoIndividual);
                    }
                    continue; // Saltar la adición del grupo completo
                }
            }
            gruposCitas.add(grupo);
        }
        
        String[] citasInfo = opcionesMostrar.toArray(new String[0]);
        
        String citaSeleccionada = (String) JOptionPane.showInputDialog(
                this, 
                "Seleccione la cita a eliminar:", 
                "Eliminar cita", 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                citasInfo, 
                citasInfo[0]);
        
        if (citaSeleccionada == null) {
            return;
        }
        
        int indexSeleccionado = -1;
        for (int i = 0; i < citasInfo.length; i++) {
            if (citasInfo[i].equals(citaSeleccionada)) {
                indexSeleccionado = i;
                break;
            }
        }
        
        if (indexSeleccionado == -1) return;
        
        ArrayList<citas> citasAEliminar = gruposCitas.get(indexSeleccionado);
        
        // Confirmar eliminación
        StringBuilder mensaje = new StringBuilder();
        mensaje.append("¿Está seguro que desea eliminar esta(s) cita(s)?\n\n");
        mensaje.append("Paciente: ").append(citasAEliminar.get(0).getPaciente()).append("\n");
        mensaje.append("Fecha: ").append(formatDate(selectedDate)).append("\n");
        mensaje.append("Servicio: ").append(citasAEliminar.get(0).getServicio()).append("\n");
        
        if (citasAEliminar.size() == 1) {
            mensaje.append("Hora: ").append(formatHour(citasAEliminar.get(0).getHora()));
        } else {
            mensaje.append("Horas: ").append(formatHour(citasAEliminar.get(0).getHora()))
                   .append(" - ").append(formatHour(citasAEliminar.get(citasAEliminar.size()-1).getHora() + 1));
        }
        
        int confirmacion = JOptionPane.showConfirmDialog(
                this, 
                mensaje.toString(), 
                "Confirmar eliminación", 
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            // Eliminar todas las citas del grupo
            for (citas citaAEliminar : citasAEliminar) {
                objDatosCitas.getCitas().remove(citaAEliminar);
            }
            
            String mensajeExito = citasAEliminar.size() == 1 ? 
                "Cita eliminada correctamente" : 
                "Citas eliminadas correctamente";
            JOptionPane.showMessageDialog(this, mensajeExito, 
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
            updateCalendar();
            updateAvailableHours();
        }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        calendario = new javax.swing.JTextArea();
        paciente = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        area = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        horario = new javax.swing.JTextArea();
        regresar = new javax.swing.JButton();
        guardar = new javax.swing.JButton();
        actualizar = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        verSala = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        elegirhora = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        calendario.setColumns(20);
        calendario.setRows(5);
        jScrollPane1.setViewportView(calendario);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 450, 390));

        paciente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        getContentPane().add(paciente, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 70, 220, -1));

        jLabel2.setText("Paciente");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 50, -1, -1));

        jLabel3.setText("Area");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 110, -1, -1));

        area.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Electroterapia", "Hidroterapia", "Reahabilitacion cardiaca", "Rehabilitacion neurologica", "Rehabilitacion ortopedica" }));
        getContentPane().add(area, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 130, 220, -1));

        horario.setColumns(20);
        horario.setRows(5);
        jScrollPane2.setViewportView(horario);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 260, -1, 200));

        regresar.setText("Regresar");
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });
        getContentPane().add(regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 510, -1, -1));

        guardar.setText("Guardar");
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });
        getContentPane().add(guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 510, -1, -1));

        actualizar.setText("Actualizar");
        actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                actualizarActionPerformed(evt);
            }
        });
        getContentPane().add(actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 510, -1, -1));

        eliminar.setText("Eliminar");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });
        getContentPane().add(eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 510, -1, -1));

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        verSala.setText("Sala de Espera");
        verSala.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verSalaActionPerformed(evt);
            }
        });
        jPanel1.add(verSala, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 490, 670, 60));

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setText("Horas disponibles");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        jLabel5.setText("Duracion");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));

        elegirhora.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1 hora", "2 horas" }));
        jPanel2.add(elegirhora, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 220, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 40, 240, 440));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:/Users/52444/Documents/P3-PRIM-25/fisioGympf/src/main/java/resources/img/fondo1.jpg"));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 570));

        jPanel3.setBackground(new java.awt.Color(153, 153, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 470, 410));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        menu m1 = new menu(this.objDatos);  
        m1.setVisible(true); 
        this.dispose();
    }//GEN-LAST:event_regresarActionPerformed

    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
         guardarCita();
    }//GEN-LAST:event_guardarActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        eliminarCita();
    }//GEN-LAST:event_eliminarActionPerformed

    private void actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualizarActionPerformed
       actualizarCita();
    }//GEN-LAST:event_actualizarActionPerformed

    private void verSalaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verSalaActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(this, 
        "Pacientes en sala de espera: " + salaDeEspera.pacientesEnEspera() + "\n" +
        "Capacidad máxima: " + SalaEspera.CAPACIDAD_MAXIMA,
        "Estado sala de espera", 
        JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_verSalaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new reserva().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton actualizar;
    private javax.swing.JComboBox<String> area;
    private javax.swing.JTextArea calendario;
    private javax.swing.JComboBox<String> elegirhora;
    private javax.swing.JButton eliminar;
    private javax.swing.JButton guardar;
    private javax.swing.JTextArea horario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JComboBox<String> paciente;
    private javax.swing.JButton regresar;
    private javax.swing.JButton verSala;
    // End of variables declaration//GEN-END:variables
}
