/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appshopheroes;

import java.util.ArrayList;

public class Coleccion {

     String nombreColeccion;
     ArrayList<Figura> listaFiguras;

   
    public Coleccion(String nombreColeccion) {
        this.nombreColeccion = nombreColeccion;
        this.listaFiguras = new ArrayList<>();
    }

   
    public String getNombreColeccion() {
        return nombreColeccion;
    }

    public void setNombreColeccion(String nombreColeccion) {
        this.nombreColeccion = nombreColeccion;
    }

    // Método para añadir figura
    public void añadirFigura(Figura fig) {
        listaFiguras.add(fig);
    }

    // Método para subir precio de una figura específica
    public void subirPrecio(double cantidad, String id) {
        for (Figura figura : listaFiguras) {
            if (figura.getCodigo().equals(id)) {
                figura.subirPrecio(cantidad);
                break;
            }
        }
    }


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Colección: " + nombreColeccion + "\n");
        for (Figura figura : listaFiguras) {
            sb.append(figura.toString()).append("\n---\n");
        }
        return sb.toString();
    }


    public String conCapa() {
        StringBuilder sb = new StringBuilder("Figuras con capa en la colección " + nombreColeccion + ":\n");
        for (Figura figura : listaFiguras) {
            if (figura.getSuperheroe().isCapa()) {
                sb.append(figura.toString()).append("\n---\n");
            }
        }
        return sb.toString();
    }

   
    public Figura masValioso() {
        Figura figuraMax = null;
        double precioMax = 0;
        for (Figura figura : listaFiguras) {
            if (figura.getPrecio() > precioMax) {
                precioMax = figura.getPrecio();
                figuraMax = figura;
            }
        }
        return figuraMax;
    }

  
    public double getValorColeccion() {
        double total = 0;
        for (Figura figura : listaFiguras) {
            total += figura.getPrecio();
        }
        return total;
    }

  
    public double getVolumenColeccion() {
        double volumenTotal = 0;
        for (Figura figura : listaFiguras) {
            volumenTotal += figura.getDimensiones().getVolumen();
        }
        return volumenTotal + 200;
    }
}