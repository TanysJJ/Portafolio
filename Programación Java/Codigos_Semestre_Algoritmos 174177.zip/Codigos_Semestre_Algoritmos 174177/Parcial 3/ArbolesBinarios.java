class Node<T extends Comparable<T>> {
    T key; 
    String data; 
    Node<T> left; 
    Node<T> right; 
    Node<T> p; 

    public Node(T key, String data) {
        this.key = key;
        this.data = data;
        this.left = null; 
        this.right = null; 
        this.p = null; 
    }

    @Override
    public String toString() {
        return key.toString();
    }
}

//-----------------------------------------------------------------------------------------------------------------------------------------


public class BinarySearchTree<T extends Comparable<T>> {

    private Node<T> root;

    public BinarySearchTree() {
        this.root = null; 
    }

    public void inorderTreeWalk(Node<T> x) {
        // 1 if x != NIL
        if (x != null) {
            inorderTreeWalk(x.left);
            System.out.print(x.key + " ");
            inorderTreeWalk(x.right);
        }
    }

    public Node<T> treeSearch(Node<T> x, T k) {
       
        if (x == null || k.compareTo(x.key) == 0) {
            return x;
        }
        if (k.compareTo(x.key) < 0) {
            return treeSearch(x.left, k);
        } 
        return treeSearch(x.right, k);
    }

    public Node<T> iterativeTreeSearch(Node<T> x, T k) {
        while (x != null && k.compareTo(x.key) != 0) {
            if (k.compareTo(x.key) < 0) {
                x = x.left;
            } 
            else {
                x = x.right;
            }
        }
        return x;
    }

    public Node<T> treeMinimum(Node<T> x) {
        while (x.left != null) {
            x = x.left;
        }
        return x;
    }

    public Node<T> treeMaximum(Node<T> x) {
        while (x.right != null) {
            x = x.right;
        }
        return x;
    }

  
    public Node<T> treeSuccessor(Node<T> x) {
        if (x.right != null) {
            return treeMinimum(x.right);
        }
        Node<T> y = x.p;
        while (y != null && x == y.right) {
            x = y;
            y = y.p;
        }
        return y;
    }

    public Node<T> treePredecessor(Node<T> x) {
        if (x.left != null) {
            return treeMaximum(x.left);
        }
        Node<T> y = x.p;
        while (y != null && x == y.left) { 
            x = y;
            y = y.p;
        }
        return y;
    }

    public void treeInsert(Node<T> z) {
        Node<T> y = null;
        Node<T> x = this.root;

        while (x != null) {
            y = x;
            if (z.key.compareTo(x.key) < 0) {
                x = x.left;
            } 
            else {
                x = x.right;
            }
        }
        
        z.p = y;
        if (y == null) {
            this.root = z;
        } 
        else if (z.key.compareTo(y.key) < 0) {
            y.left = z;
        } 
        else {
            y.right = z;
        }
    }
    
    private void transplant(Node<T> u, Node<T> v) {
        if (u.p == null) {
            this.root = v;
        } 
        else if (u == u.p.left) {
            u.p.left = v;
        }
        else {
            u.p.right = v;
        }
        if (v != null) {
            v.p = u.p;
        }
    }

    public void treeDelete(Node<T> z) {
        if (z.left == null) {
            transplant(z, z.right);
        }
        else if (z.right == null) {
            transplant(z, z.left);
        } 
        else {
            Node<T> y = treeMinimum(z.right);z
            if (y.p != z) {
                transplant(y, y.right);
                y.right = z.right;
                y.right.p = y;
            }
            transplant(z, y);
            y.left = z.left;
            y.left.p = y;
        }
    }

   