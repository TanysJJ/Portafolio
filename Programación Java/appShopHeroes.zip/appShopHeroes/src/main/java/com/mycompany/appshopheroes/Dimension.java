/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appshopheroes;

/**
 *
 * @author 174177
 */
public class Dimension {
   
     double alto;
     double ancho;
     double profundidad;

    // Constructor sin parámetros
    public Dimension() {
        this.alto = 0;
        this.ancho = 0;
        this.profundidad = 0;
    }

  
    public Dimension(double alto, double ancho, double profundidad) {
        this.alto = alto;
        this.ancho = ancho;
        this.profundidad = profundidad;
    }


    public double getAlto() {
        return alto;
    }

    public void setAlto(double alto) {
        this.alto = alto;
    }

    public double getAncho() {
        return ancho;
    }

    public void setAncho(double ancho) {
        this.ancho = ancho;
    }

    public double getProfundidad() {
        return profundidad;
    }

    public void setProfundidad(double profundidad) {
        this.profundidad = profundidad;
    }


    public double getVolumen() {
        return alto * ancho * profundidad;
    }

    // Método toString
    @Override
    public String toString() {
        return "Dimensiones: " + 
               "\nAlto: " + alto + 
               "\nAncho: " + ancho + 
               "\nProfundidad: " + profundidad + 
               "\nVolumen máximo: " + getVolumen();
    }
}