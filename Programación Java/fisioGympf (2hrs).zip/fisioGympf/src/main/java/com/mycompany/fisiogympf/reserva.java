/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.fisiogympf;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class reserva extends javax.swing.JFrame {

    private datosP objDatos;
    private datosC objDatosCitas;
    private JPanel calendarPanel;
    private JLabel monthYearLabel;
    private JButton prevMonthButton;
    private JButton nextMonthButton;
    private JButton[][] calendarDays;
    private LocalDate currentDate;
    private LocalDate selectedDate;
    private JComboBox<String> duracionComboBox;
    private static final int START_HOUR = 8; // 8 AM
    private static final int END_HOUR = 18; // 6 PM
    private static final int MAX_SLOTS_PER_AREA = 3;
 public reserva() {
        initComponents();
        this.objDatos = new datosP();
        this.objDatosCitas = new datosC();
        duracionComboBox = new JComboBox<>(new String[]{"1 hora", "2 horas"});
        initializeCalendar();
    }
    
    public reserva(datosP objd) {
        initComponents(); 
        this.objDatos = objd;
        this.objDatosCitas = new datosC();
        initializeCalendar();
        cargarPacientes();
    }
    
    public reserva(datosP objd, datosC objc) {
    initComponents(); 
    this.objDatos = objd;
    this.objDatosCitas = objc;
    initializeCalendar();
    cargarPacientes();
    
   
    guardar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            guardarCita();
        }
    });

    actualizar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            actualizarCita();
        }
    });

    eliminar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            eliminarCita();
        }
    });
}
    
 private void cargarPacientes() {
    paciente.removeAllItems();
    if (objDatos.getPacientes().isEmpty()) {
        paciente.addItem("No hay pacientes registrados");
        
        
    } else {
        
        for (paciente p : objDatos.getPacientes()) {
            paciente.addItem(p.getNombre());
        }
    }
}
    
    private void initializeCalendar() {
        
        currentDate = LocalDate.now();
        selectedDate = null;
        
        
        calendarPanel = new JPanel();
        calendarPanel.setLayout(new BorderLayout());
        calendarPanel.setBackground(new Color(255, 255, 255));
        
        
        JPanel navigationPanel = new JPanel();
        navigationPanel.setBackground(new Color(204, 204, 255));
        
        prevMonthButton = new JButton("<<");
        monthYearLabel = new JLabel("", JLabel.CENTER);
        monthYearLabel.setFont(new Font("Verdana", Font.BOLD, 14));
        nextMonthButton = new JButton(">>");
        
        navigationPanel.add(prevMonthButton);
        navigationPanel.add(monthYearLabel);
        navigationPanel.add(nextMonthButton);
        
       
        JPanel weekDaysPanel = new JPanel(new GridLayout(1, 7));
        weekDaysPanel.setBackground(new Color(204, 224, 255));
        String[] weekDays = {"Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"};
        for (String day : weekDays) {
            JLabel label = new JLabel(day, JLabel.CENTER);
            label.setFont(new Font("Verdana", Font.BOLD, 12));
            weekDaysPanel.add(label);
        }
        
        
        JPanel daysPanel = new JPanel(new GridLayout(6, 7));
        daysPanel.setBackground(new Color(255, 255, 255));
        
        calendarDays = new JButton[6][7];
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                calendarDays[i][j] = new JButton();
                calendarDays[i][j].setBackground(Color.WHITE);
                calendarDays[i][j].setBorder(new EmptyBorder(2, 2, 2, 2));
                final int row = i;
                final int col = j;
                calendarDays[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        dayButtonClicked(row, col);
                    }
                });
                daysPanel.add(calendarDays[i][j]);
            }
        }
        
        
        prevMonthButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentDate = currentDate.minusMonths(1);
                updateCalendar();
            }
        });
        
        nextMonthButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentDate = currentDate.plusMonths(1);
                updateCalendar();
            }
        });
        
        
        calendarPanel.add(navigationPanel, BorderLayout.NORTH);
        calendarPanel.add(weekDaysPanel, BorderLayout.CENTER);
        calendarPanel.add(daysPanel, BorderLayout.SOUTH);
        
       
        jScrollPane1.setViewportView(calendarPanel);
        
        
        updateCalendar();
        
       
        area.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (selectedDate != null) {
                    updateAvailableHours();
                }
            }
        });
    }
    
 private void updateCalendar() {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
    monthYearLabel.setText(currentDate.format(formatter));

    YearMonth yearMonth = YearMonth.from(currentDate);
    int daysInMonth = yearMonth.lengthOfMonth();
    LocalDate firstDayOfMonth = currentDate.withDayOfMonth(1);
    int dayOfWeek = firstDayOfMonth.getDayOfWeek().getValue() % 7; 

    LocalDate today = LocalDate.now(); // Obtener la fecha actual

    // Limpiar la tabla de días
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 7; j++) {
            calendarDays[i][j].setText("");
            calendarDays[i][j].setEnabled(false);
            calendarDays[i][j].setBackground(Color.WHITE);
        }
    }

    // Asignar números a los días del mes
    int day = 1;
    for (int i = 0; i < 6 && day <= daysInMonth; i++) {
        for (int j = 0; j < 7 && day <= daysInMonth; j++) {
            if (i == 0 && j < dayOfWeek) {
                continue;
            }

            LocalDate dateToCheck = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), day);
            calendarDays[i][j].setText(String.valueOf(day));

            // **Deshabilitar días pasados**
            if (dateToCheck.isBefore(today)) {
                calendarDays[i][j].setEnabled(false);
                calendarDays[i][j].setForeground(Color.GRAY); // Opcional: Mostrarlo en gris
            } else {
                calendarDays[i][j].setEnabled(true);
            }

            // **Resaltar el día actual**
            if (dateToCheck.equals(today)) {
                calendarDays[i][j].setBackground(new Color(173, 216, 230)); 
            }

            // **Resaltar día seleccionado**
            if (selectedDate != null && dateToCheck.equals(selectedDate)) {
                calendarDays[i][j].setBackground(new Color(144, 238, 144)); 
            }

            // **Marcar días con citas en rojo**
            if (tieneCitas(dateToCheck)) {
                calendarDays[i][j].setForeground(Color.RED);
            } else {
                calendarDays[i][j].setForeground(Color.BLACK);
            }

            day++;
        }
    }
}
    
    private boolean tieneCitas(LocalDate fecha) {
        for (citas cita : objDatosCitas.getCitas()) {
            if (cita.getDia() == fecha.getDayOfMonth() && 
                cita.getMes() == fecha.getMonthValue() && 
                cita.getAño() == fecha.getYear()) {
                return true;
            }
        }
        return false;
    }
    
    private void dayButtonClicked(int row, int col) {
       
        String dayText = calendarDays[row][col].getText();
        if (!dayText.isEmpty()) {
            int day = Integer.parseInt(dayText);
            selectedDate = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), day);
            
            
            updateCalendar();
            
           
            updateAvailableHours();
        }
    }
    
    private void updateAvailableHours() {
        if (selectedDate == null) return;
        
        StringBuilder sb = new StringBuilder();
        String selectedAreaText = (String) area.getSelectedItem();
        
        sb.append("Horarios para ").append(formatDate(selectedDate)).append("\n");
        sb.append("Área: ").append(selectedAreaText).append("\n\n");
        
        for (int hour = START_HOUR; hour < END_HOUR; hour++) {
            int occupiedSlots = getOccupiedSlots(selectedDate, hour, selectedAreaText);
            int availableSlots = MAX_SLOTS_PER_AREA - occupiedSlots;
            
            String timeStr = formatHour(hour);
            String status = (availableSlots > 0) ? 
                    "Disponible (" + availableSlots + " espacios)" : 
                    "Completo";
            
            sb.append(timeStr).append(": ").append(status).append("\n");
        }
        
        horario.setText(sb.toString());
    }
    
    private int getOccupiedSlots(LocalDate date, int hour, String areaName) {
        int count = 0;
        for (citas cita : objDatosCitas.getCitas()) {
            if (cita.getDia() == date.getDayOfMonth() && 
                cita.getMes() == date.getMonthValue() && 
                cita.getAño() == date.getYear() && 
                cita.getHora() == hour && 
                cita.getServicio().equals(areaName)) {
                count++;
            }
        }
        return count;
    }
    
    private String formatDate(LocalDate date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return date.format(formatter);
    }
    
    private String formatHour(int hour) {
        return hour + ":00";
    }
    
   private void guardarCita() {
       
    if (selectedDate == null) {
        JOptionPane.showMessageDialog(this, "Por favor seleccione una fecha en el calendario", 
                "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (paciente.getSelectedItem() == null || paciente.getSelectedItem().equals("No hay pacientes registrados")) {
        JOptionPane.showMessageDialog(this, "No hay pacientes registrados para agendar cita", 
                "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String pacienteNombre = (String) paciente.getSelectedItem();
    String areaSeleccionada = (String) area.getSelectedItem();
    String horaSeleccionada = (String) JOptionPane.showInputDialog(
        this,
        "Seleccione un horario disponible:",
        "Seleccionar Horario",
        JOptionPane.PLAIN_MESSAGE,
        null,
        getHorasDisponibles(selectedDate, areaSeleccionada),
        null);

    if (horaSeleccionada == null) {
        return; 
    }

    int hora = Integer.parseInt(horaSeleccionada.split(":")[0]);
    int duracion = elegirhora.getSelectedIndex() + 1; 

  
    if (duracion == 2) {
        if (hora + 1 >= END_HOUR) { 
            JOptionPane.showMessageDialog(this, "No es posible reservar 2 horas en este horario.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (getOccupiedSlots(selectedDate, hora, areaSeleccionada) >= MAX_SLOTS_PER_AREA ||
            getOccupiedSlots(selectedDate, hora + 1, areaSeleccionada) >= MAX_SLOTS_PER_AREA) {
            JOptionPane.showMessageDialog(this, "No hay suficiente espacio para una sesión de 2 horas.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }

   
    for (int i = 0; i < duracion; i++) {
        citas nuevaCita = new citas(
            pacienteNombre,
            selectedDate.getDayOfMonth(),
            selectedDate.getMonthValue(),
            selectedDate.getYear(),
            hora + i,
            areaSeleccionada);
        objDatosCitas.agregarCita(nuevaCita);
    }

    JOptionPane.showMessageDialog(this, "Cita guardada exitosamente!", 
        "Éxito", JOptionPane.INFORMATION_MESSAGE);

   
    updateCalendar();
    updateAvailableHours();
}
    
    private String[] getHorasDisponibles(LocalDate date, String areaName) {
        ArrayList<String> horasDisp = new ArrayList<>();
        
        for (int hour = START_HOUR; hour < END_HOUR; hour++) {
            int occupiedSlots = getOccupiedSlots(date, hour, areaName);
            int availableSlots = MAX_SLOTS_PER_AREA - occupiedSlots;
            
            if (availableSlots > 0) {
                horasDisp.add(formatHour(hour));
            }
        }
        
        return horasDisp.toArray(new String[0]);
    }
    
    private void actualizarCita() {
        if (selectedDate == null) {
            JOptionPane.showMessageDialog(this, "Por favor seleccione una fecha en el calendario", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
       
        ArrayList<citas> citasDelDia = new ArrayList<>();
        for (citas cita : objDatosCitas.getCitas()) {
            if (cita.getDia() == selectedDate.getDayOfMonth() && 
                cita.getMes() == selectedDate.getMonthValue() && 
                cita.getAño() == selectedDate.getYear()) {
                citasDelDia.add(cita);
            }
        }
        
        if (citasDelDia.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay citas para actualizar en esta fecha", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        
        String[] citasInfo = new String[citasDelDia.size()];
        for (int i = 0; i < citasDelDia.size(); i++) {
            citas cita = citasDelDia.get(i);
            citasInfo[i] = cita.getPaciente() + " - " + formatHour(cita.getHora()) + " - " + cita.getServicio();
        }
        
       
        String citaSeleccionada = (String) JOptionPane.showInputDialog(
                this, 
                "Seleccione la cita a actualizar:", 
                "Actualizar cita", 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                citasInfo, 
                citasInfo[0]);
        
        if (citaSeleccionada == null) {
            return;
        }
        
        
        int indexCitaSeleccionada = -1;
        for (int i = 0; i < citasInfo.length; i++) {
            if (citasInfo[i].equals(citaSeleccionada)) {
                indexCitaSeleccionada = i;
                break;
            }
        }
        
        if (indexCitaSeleccionada == -1) {
            return;
        }
        
        citas citaActual = citasDelDia.get(indexCitaSeleccionada);
        int indexEnListaGeneral = objDatosCitas.getCitas().indexOf(citaActual);
        
       
        String[] opciones = {"Paciente", "Hora", "Área de servicio", "Cancelar"};
        int opcionSeleccionada = JOptionPane.showOptionDialog(
                this, 
                "¿Qué desea actualizar?", 
                "Actualizar cita", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                opciones, 
                opciones[0]);
        
        switch (opcionSeleccionada) {
            case 0: 
                if (objDatos.getPacientes().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "No hay pacientes registrados", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                String[] pacientesNombres = new String[objDatos.getPacientes().size()];
                for (int i = 0; i < objDatos.getPacientes().size(); i++) {
                    pacientesNombres[i] = objDatos.getPacientes().get(i).getNombre();
                }
                
                String nuevoPaciente = (String) JOptionPane.showInputDialog(
                        this, 
                        "Seleccione el nuevo paciente:", 
                        "Actualizar paciente", 
                        JOptionPane.QUESTION_MESSAGE, 
                        null, 
                        pacientesNombres, 
                        citaActual.getPaciente());
                
                if (nuevoPaciente != null) {
                    // Crear una nueva cita con el paciente actualizado
                    citas citaActualizada = new citas(
                            nuevoPaciente, 
                            citaActual.getDia(), 
                            citaActual.getMes(), 
                            citaActual.getAño(), 
                            citaActual.getHora(), 
                            citaActual.getServicio());
                    
                  
                    objDatosCitas.getCitas().set(indexEnListaGeneral, citaActualizada);
                    JOptionPane.showMessageDialog(this, "Paciente actualizado correctamente", 
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
                break;
                
            case 1: 
                String[] horasDisponibles = getHorasDisponibles(selectedDate, citaActual.getServicio());
                
                String horaActual = formatHour(citaActual.getHora());
                String[] todasHoras = new String[horasDisponibles.length + 1];
                System.arraycopy(horasDisponibles, 0, todasHoras, 0, horasDisponibles.length);
                todasHoras[horasDisponibles.length] = horaActual;
                
                String nuevaHora = (String) JOptionPane.showInputDialog(
                        this, 
                        "Seleccione la nueva hora:", 
                        "Actualizar hora", 
                        JOptionPane.QUESTION_MESSAGE, 
                        null, 
                        todasHoras, 
                        horaActual);
                
                if (nuevaHora != null) {
                    int hora = Integer.parseInt(nuevaHora.split(":")[0]);
                    
                   
                    citas citaActualizada = new citas(
                            citaActual.getPaciente(), 
                            citaActual.getDia(), 
                            citaActual.getMes(), 
                            citaActual.getAño(), 
                            hora, 
                            citaActual.getServicio());
                    
                   
                    objDatosCitas.getCitas().set(indexEnListaGeneral, citaActualizada);
                    JOptionPane.showMessageDialog(this, "Hora actualizada correctamente", 
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
                break;
                
            case 2: 
                String[] areasServicio = {"Electroterapia", "Hidroterapia", "Reahabilitacion cardiaca", 
                        "Rehabilitacion neurologica", "Rehabilitacion ortopedica"};
                
                String nuevaArea = (String) JOptionPane.showInputDialog(
                        this, 
                        "Seleccione la nueva área de servicio:", 
                        "Actualizar área", 
                        JOptionPane.QUESTION_MESSAGE, 
                        null, 
                        areasServicio, 
                        citaActual.getServicio());
                
                if (nuevaArea != null) {
                   
                    int occupiedSlots = getOccupiedSlots(selectedDate, citaActual.getHora(), nuevaArea);
                    if (occupiedSlots >= MAX_SLOTS_PER_AREA) {
                        JOptionPane.showMessageDialog(this, "No hay espacio disponible en esa área y hora", 
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    
                   
                    citas citaActualizada = new citas(
                            citaActual.getPaciente(), 
                            citaActual.getDia(), 
                            citaActual.getMes(), 
                            citaActual.getAño(), 
                            citaActual.getHora(), 
                            nuevaArea);
                    
                   
                    objDatosCitas.getCitas().set(indexEnListaGeneral, citaActualizada);
                    JOptionPane.showMessageDialog(this, "Área actualizada correctamente", 
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
                break;
                
            default: 
                return;
        }
        
        
        updateCalendar();
        updateAvailableHours();
    }
    
    private void eliminarCita() {
        if (selectedDate == null) {
            JOptionPane.showMessageDialog(this, "Por favor seleccione una fecha en el calendario", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        
        ArrayList<citas> citasDelDia = new ArrayList<>();
        for (citas cita : objDatosCitas.getCitas()) {
            if (cita.getDia() == selectedDate.getDayOfMonth() && 
                cita.getMes() == selectedDate.getMonthValue() && 
                cita.getAño() == selectedDate.getYear()) {
                citasDelDia.add(cita);
            }
        }
        
        if (citasDelDia.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay citas para eliminar en esta fecha", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
       
        String[] citasInfo = new String[citasDelDia.size()];
        for (int i = 0; i < citasDelDia.size(); i++) {
            citas cita = citasDelDia.get(i);
            citasInfo[i] = cita.getPaciente() + " - " + formatHour(cita.getHora()) + " - " + cita.getServicio();
        }
        
        
        String citaSeleccionada = (String) JOptionPane.showInputDialog(
                this, 
                "Seleccione la cita a eliminar:", 
                "Eliminar cita", 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                citasInfo, 
                citasInfo[0]);
        
        if (citaSeleccionada == null) {
            return; 
        }
        
        
        int indexCitaSeleccionada = -1;
        for (int i = 0; i < citasInfo.length; i++) {
            if (citasInfo[i].equals(citaSeleccionada)) {
                indexCitaSeleccionada = i;
                break;
            }
        }
        
        if (indexCitaSeleccionada == -1) {
            return;
        }
        
        citas citaAEliminar = citasDelDia.get(indexCitaSeleccionada);
        
       
        int confirmacion = JOptionPane.showConfirmDialog(
                this, 
                "¿Está seguro que desea eliminar esta cita?", 
                "Confirmar eliminación", 
                JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            objDatosCitas.getCitas().remove(citaAEliminar);
            JOptionPane.showMessageDialog(this, "Cita eliminada correctamente", 
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
          
            updateCalendar();
            updateAvailableHours();
        }
                 
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        calendario = new javax.swing.JTextArea();
        paciente = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        area = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        horario = new javax.swing.JTextArea();
        regresar = new javax.swing.JButton();
        guardar = new javax.swing.JButton();
        actualizar = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        elegirhora = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        calendario.setColumns(20);
        calendario.setRows(5);
        jScrollPane1.setViewportView(calendario);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 450, 390));

        paciente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        getContentPane().add(paciente, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 70, 220, -1));

        jLabel2.setText("Paciente");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 50, -1, -1));

        jLabel3.setText("Area");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 110, -1, -1));

        area.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Electroterapia", "Hidroterapia", "Reahabilitacion cardiaca", "Rehabilitacion neurologica", "Rehabilitacion ortopedica" }));
        getContentPane().add(area, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 130, 220, -1));

        horario.setColumns(20);
        horario.setRows(5);
        jScrollPane2.setViewportView(horario);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 260, -1, 200));

        regresar.setText("Regresar");
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });
        getContentPane().add(regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 510, -1, -1));

        guardar.setText("Guardar");
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });
        getContentPane().add(guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 510, -1, -1));

        actualizar.setText("Actualizar");
        actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                actualizarActionPerformed(evt);
            }
        });
        getContentPane().add(actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 510, -1, -1));

        eliminar.setText("Eliminar");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });
        getContentPane().add(eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 510, -1, -1));

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 490, 540, 60));

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setText("Horas disponibles");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        jLabel5.setText("Duracion");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));

        elegirhora.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1 hora", "2 horas" }));
        jPanel2.add(elegirhora, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 220, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 40, 240, 440));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:/Users/52444/Documents/P3-PRIM-25/fisioGympf/src/main/java/resources/img/fondo1.jpg"));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 570));

        jPanel3.setBackground(new java.awt.Color(153, 153, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 470, 410));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        menu m1 = new menu(this.objDatos);  
        m1.setVisible(true); 
        this.dispose();
    }//GEN-LAST:event_regresarActionPerformed

    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
         guardarCita();
    }//GEN-LAST:event_guardarActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        eliminarCita();
    }//GEN-LAST:event_eliminarActionPerformed

    private void actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualizarActionPerformed
       actualizarCita();
    }//GEN-LAST:event_actualizarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new reserva().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton actualizar;
    private javax.swing.JComboBox<String> area;
    private javax.swing.JTextArea calendario;
    private javax.swing.JComboBox<String> elegirhora;
    private javax.swing.JButton eliminar;
    private javax.swing.JButton guardar;
    private javax.swing.JTextArea horario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JComboBox<String> paciente;
    private javax.swing.JButton regresar;
    // End of variables declaration//GEN-END:variables
}
