/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.fisiogympf;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Semaphore;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Duration;
import java.time.format.DateTimeFormatter;

public class gimnasio extends javax.swing.JFrame {

    private datosP objDatos;
    private datosC objDatosCitas;
    private Map<String, List<JProgressBar>> areasBarras;
    private Map<String, List<JLabel>> areasLabels;
    private Semaphore[] semaforosAreas;
    private Thread[] hilosAreas;
    private boolean simulacionActiva;
    private Timer timerActualizacion;
    
    // SISTEMA DE TIEMPO ACELERADO
    private LocalTime tiempoSimulado;
    private LocalDate fechaSimulada;
    private Timer timerTiempoAcelerado;
    private JLabel labelTiempoSimulado;
    private JLabel labelVelocidad;
    
    // Configuración de velocidad (1 segundo real = X minutos simulados)
    private int factorAceleracion = 5; // 1 segundo real = 5 minutos simulados
    private boolean pausado = false;
    
    // Mapa para rastrear sesiones activas
    private Map<String, Map<String, SesionTerapia>> sesionesActivas;
    
    private final String[] AREAS = {
        "Electroterapia", 
        "Hidroterapia", 
        "Rehabilitacion cardiaca", 
        "Rehabilitacion neurologica", 
        "Rehabilitacion ortopedica"
    };
    private final int CAPACIDAD_AREA = 3;
    
    // Clase para representar una sesión con tiempo acelerado
    private class SesionTerapia {
        String paciente;
        String area;
        LocalTime horaInicioReal; // Hora real de la cita
        LocalTime horaFinReal;    // Hora real de fin
        LocalTime horaInicioSimulada; // Cuándo empezó en tiempo simulado
        int duracionMinutos;
        int progreso;
        boolean activa;
        String citaKey;
        
        public SesionTerapia(citas cita, LocalTime tiempoInicioSimulado) {
            this.paciente = cita.getPaciente();
            this.area = cita.getServicio();
            this.horaInicioReal = LocalTime.of(cita.getHora(), 0);
            this.horaFinReal = this.horaInicioReal.plusHours(cita.getDuracionHoras());
            this.horaInicioSimulada = tiempoInicioSimulado;
            this.duracionMinutos = cita.getDuracionHoras() * 60; // Convertir a minutos
            this.progreso = 0;
            this.activa = true;
            this.citaKey = generarCitaKey(cita);
        }
        
        private String generarCitaKey(citas cita) {
            return cita.getPaciente() + "_" + cita.getDia() + "_" + 
                   cita.getMes() + "_" + cita.getAño() + "_" + 
                   cita.getHora() + "_" + cita.getServicio();
        }
        
        public void actualizarProgresoConTiempoAcelerado(LocalTime tiempoActualSimulado) {
            if (!activa) return;
            
            // Calcular minutos transcurridos en tiempo simulado
            long minutosTranscurridos = Duration.between(horaInicioSimulada, tiempoActualSimulado).toMinutes();
            
            if (minutosTranscurridos < 0) {
                // La sesión aún no ha comenzado
                progreso = 0;
            } else if (minutosTranscurridos >= duracionMinutos) {
                // La sesión ha terminado
                progreso = 100;
                activa = false;
            } else {
                // La sesión está en curso
                progreso = (int) ((minutosTranscurridos * 100) / duracionMinutos);
                progreso = Math.max(0, Math.min(100, progreso));
            }
        }
        
        public boolean estaCompleta() {
            return progreso >= 100 || !activa;
        }
        
        public LocalTime getHoraFinSimulada() {
            return horaInicioSimulada.plusMinutes(duracionMinutos);
        }
    }

    public gimnasio() {
        initComponents(); 
        this.objDatos = new datosP();
        this.objDatosCitas = new datosC();
        inicializarSimulacion();
    }
 
    public gimnasio(datosP objDatos, datosC objDatosCitas) {
        initComponents();
        this.objDatos = objDatos;
        this.objDatosCitas = objDatosCitas;
        inicializarSimulacion();
    }

    private void inicializarSimulacion() {
        // Inicializar tiempo simulado (empezar a las 8:00 AM del día actual)
        fechaSimulada = LocalDate.now();
        tiempoSimulado = LocalTime.of(8, 0); // Empezar a las 8:00 AM
        
        inicializarInterfaz();
        inicializarControlTiempo();
        inicializarHilosYSemaforos();
        iniciarSimulacionTiempoAcelerado();
    }

    private void inicializarInterfaz() {
        areasBarras = new HashMap<>();
        areasLabels = new HashMap<>();
        sesionesActivas = new HashMap<>();
        
        panelSimulacion.removeAll();
        panelSimulacion.setLayout(new BorderLayout());
        
        /*// Panel de control de tiempo en la parte superior
        JPanel panelControlTiempo = new JPanel(new FlowLayout());
        panelControlTiempo.setBackground(new Color(220, 220, 255));
        panelControlTiempo.setBorder(BorderFactory.createTitledBorder("Control de Simulación"));
        
        labelTiempoSimulado = new JLabel("Hora: 08:00");
        labelTiempoSimulado.setFont(new Font("Verdana", Font.BOLD, 16));
        labelTiempoSimulado.setForeground(Color.BLUE);
        
        labelVelocidad = new JLabel("Velocidad: 1s = " + factorAceleracion + "min");
        labelVelocidad.setFont(new Font("Verdana", Font.PLAIN, 12));
        
        JButton btnPausar = new JButton("Pausar");
        btnPausar.addActionListener(e -> togglePausa());
        
        JButton btnAcelerar = new JButton("Acelerar");
        btnAcelerar.addActionListener(e -> cambiarVelocidad(true));
        
        JButton btnRalentizar = new JButton("Ralentizar");
        btnRalentizar.addActionListener(e -> cambiarVelocidad(false));
        
        JButton btnReiniciar = new JButton("Reiniciar Día");
        btnReiniciar.addActionListener(e -> reiniciarDia());
        
        panelControlTiempo.add(labelTiempoSimulado);
        panelControlTiempo.add(new JLabel(" | "));
        panelControlTiempo.add(labelVelocidad);
        panelControlTiempo.add(new JLabel(" | "));
        panelControlTiempo.add(btnPausar);
        panelControlTiempo.add(btnAcelerar);
        panelControlTiempo.add(btnRalentizar);
        panelControlTiempo.add(btnReiniciar);
        */
        // Panel de áreas en el centro
        JPanel panelAreas = new JPanel(new GridLayout(AREAS.length, 1, 5, 5));
        panelAreas.setBackground(new Color(240, 248, 255));
        
        for (String area : AREAS) {
            sesionesActivas.put(area, new HashMap<>());
            
            JPanel panelArea = new JPanel(new BorderLayout());
            panelArea.setBorder(BorderFactory.createTitledBorder(area));
            panelArea.setBackground(new Color(250, 250, 255));
            
            JLabel tituloArea = new JLabel(area + " (0/" + CAPACIDAD_AREA + " ocupados)");
            tituloArea.setFont(new Font("Verdana", Font.BOLD, 11));
            tituloArea.setHorizontalAlignment(SwingConstants.CENTER);
            panelArea.add(tituloArea, BorderLayout.NORTH);
            
            JPanel panelBarras = new JPanel(new GridLayout(1, CAPACIDAD_AREA, 3, 0));
            panelBarras.setBackground(new Color(250, 250, 255));
            List<JProgressBar> barras = new ArrayList<>();
            List<JLabel> labels = new ArrayList<>();
            
            for (int j = 0; j < CAPACIDAD_AREA; j++) {
                JPanel slotPanel = new JPanel(new BorderLayout());
                slotPanel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
                slotPanel.setBackground(new Color(250, 250, 255));
                
                JProgressBar barra = new JProgressBar(0, 100);
                barra.setStringPainted(true);
                barra.setString("Libre");
                barra.setForeground(new Color(0, 102, 204));
                barra.setFont(new Font("Arial", Font.BOLD, 9));
                
                JLabel label = new JLabel("Disponible", SwingConstants.CENTER);
                label.setFont(new Font("Arial", Font.PLAIN, 8));
                
                slotPanel.add(barra, BorderLayout.CENTER);
                slotPanel.add(label, BorderLayout.SOUTH);
                panelBarras.add(slotPanel);
                
                barras.add(barra);
                labels.add(label);
            }
            
            panelArea.add(panelBarras, BorderLayout.CENTER);
            panelAreas.add(panelArea);
            
            areasBarras.put(area, barras);
            areasLabels.put(area, labels);
        }
        
        //panelSimulacion.add(panelControlTiempo, BorderLayout.NORTH);
        panelSimulacion.add(panelAreas, BorderLayout.CENTER);
        
        panelSimulacion.revalidate();
        panelSimulacion.repaint();
    }

    private void inicializarControlTiempo() {
        // Timer que avanza el tiempo simulado cada segundo
        timerTiempoAcelerado = new Timer(1000, e -> {
            if (!pausado) {
                avanzarTiempoSimulado();
            }
        });
        timerTiempoAcelerado.start();
    }

    private void inicializarHilosYSemaforos() {
        simulacionActiva = true;
        semaforosAreas = new Semaphore[AREAS.length];
        hilosAreas = new Thread[AREAS.length];
        
        for (int i = 0; i < AREAS.length; i++) {
            semaforosAreas[i] = new Semaphore(CAPACIDAD_AREA, true);
        }
        
        for (int i = 0; i < AREAS.length; i++) {
            final int areaIndex = i;
            final String areaName = AREAS[i];
            
            hilosAreas[i] = new Thread(() -> {
                while (simulacionActiva) {
                    try {
                        procesarCitasDeAreaConTiempoAcelerado(areaName, areaIndex);
                        Thread.sleep(500); // Verificar cada 0.5 segundos
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            });
            
            hilosAreas[i].setDaemon(true);
            hilosAreas[i].setName("Hilo-" + areaName);
            hilosAreas[i].start();
        }
    }

    private void avanzarTiempoSimulado() {
        tiempoSimulado = tiempoSimulado.plusMinutes(factorAceleracion);
        
        // Si pasa de las 20:00, avanzar al siguiente día a las 8:00
        if (tiempoSimulado.isAfter(LocalTime.of(20, 0))) {
            fechaSimulada = fechaSimulada.plusDays(1);
            tiempoSimulado = LocalTime.of(8, 0);
            limpiarTodasLasSesiones();
        }
        
        SwingUtilities.invokeLater(() -> {
            labelTiempoSimulado.setText("Hora: " + tiempoSimulado.format(DateTimeFormatter.ofPattern("HH:mm")) + 
                                      " (" + fechaSimulada.format(DateTimeFormatter.ofPattern("dd/MM")) + ")");
        });
    }

    private void procesarCitasDeAreaConTiempoAcelerado(String areaName, int areaIndex) {
        try {
            // Refrescar datos de citas desde BD
            objDatosCitas.refrescarDatos();
            
            // Obtener citas del día simulado para esta área
            List<citas> citasDelDia = obtenerCitasDelDiaParaArea(fechaSimulada, areaName);
            
            Map<String, SesionTerapia> sesionesArea = sesionesActivas.get(areaName);
            
            // Procesar cada cita del día
            for (citas cita : citasDelDia) {
                String citaKey = generarCitaKey(cita);
                LocalTime horaCita = LocalTime.of(cita.getHora(), 0);
                
                // Verificar si es hora de iniciar esta cita (con margen de 5 minutos)
                boolean esHoraDeIniciar = !tiempoSimulado.isBefore(horaCita) && 
                                        tiempoSimulado.isBefore(horaCita.plusMinutes(10));
                
                if (esHoraDeIniciar && !sesionesArea.containsKey(citaKey)) {
                    // Intentar crear nueva sesión
                    if (semaforosAreas[areaIndex].tryAcquire()) {
                        SesionTerapia nuevaSesion = new SesionTerapia(cita, tiempoSimulado);
                        sesionesArea.put(citaKey, nuevaSesion);
                        
                        System.out.println("SIMULACIÓN: Nueva sesión iniciada - " + cita.getPaciente() + 
                                         " en " + areaName + " a las " + tiempoSimulado.format(DateTimeFormatter.ofPattern("HH:mm")) +
                                         " (cita programada: " + horaCita.format(DateTimeFormatter.ofPattern("HH:mm")) + ")");
                    }
                }
            }
            
            // Actualizar sesiones existentes y limpiar completadas
            List<String> sesionesAEliminar = new ArrayList<>();
            
            for (Map.Entry<String, SesionTerapia> entry : sesionesArea.entrySet()) {
                String citaKey = entry.getKey();
                SesionTerapia sesion = entry.getValue();
                
                sesion.actualizarProgresoConTiempoAcelerado(tiempoSimulado);
                
                if (sesion.estaCompleta()) {
                    sesionesAEliminar.add(citaKey);
                    semaforosAreas[areaIndex].release();
                    
                    System.out.println("SIMULACIÓN: Sesión completada - " + sesion.paciente + 
                                     " en " + areaName + " (progreso: " + sesion.progreso + "%)");
                }
            }
            
            // Eliminar sesiones completadas
            for (String citaKey : sesionesAEliminar) {
                sesionesArea.remove(citaKey);
            }
            
            // Actualizar interfaz
            SwingUtilities.invokeLater(() -> {
                actualizarInterfazArea(areaName);
            });
            
        } catch (Exception e) {
            System.err.println("Error procesando área " + areaName + ": " + e.getMessage());
        }
    }

    private List<citas> obtenerCitasDelDiaParaArea(LocalDate fecha, String area) {
        List<citas> citasDelDia = new ArrayList<>();
        
        for (citas cita : objDatosCitas.getCitas()) {
            if (cita.getDia() == fecha.getDayOfMonth() && 
                cita.getMes() == fecha.getMonthValue() && 
                cita.getAño() == fecha.getYear() && 
                cita.getServicio().equals(area)) {
                citasDelDia.add(cita);
            }
        }
        
        return citasDelDia;
    }

    private String generarCitaKey(citas cita) {
        return cita.getPaciente() + "_" + cita.getDia() + "_" + 
               cita.getMes() + "_" + cita.getAño() + "_" + 
               cita.getHora() + "_" + cita.getServicio();
    }

    private void actualizarInterfazArea(String areaName) {
        List<JProgressBar> barras = areasBarras.get(areaName);
        List<JLabel> labels = areasLabels.get(areaName);
        Map<String, SesionTerapia> sesionesArea = sesionesActivas.get(areaName);
        
        // Limpiar todas las barras primero
        for (int i = 0; i < CAPACIDAD_AREA; i++) {
            barras.get(i).setValue(0);
            barras.get(i).setString("Libre");
            barras.get(i).setForeground(new Color(0, 102, 204));
            labels.get(i).setText("Disponible");
        }
        
        // Asignar sesiones activas a las barras
        int slot = 0;
        for (SesionTerapia sesion : sesionesArea.values()) {
            if (slot < CAPACIDAD_AREA) {
                JProgressBar barra = barras.get(slot);
                JLabel label = labels.get(slot);
                
                barra.setValue(sesion.progreso);
                barra.setString(sesion.paciente);
                
                // Color según progreso
                if (sesion.progreso < 25) {
                    barra.setForeground(Color.RED);
                } else if (sesion.progreso < 75) {
                    barra.setForeground(Color.ORANGE);
                } else {
                    barra.setForeground(Color.GREEN);
                }
                
                label.setText(String.format("%d%% (%s-%s)", 
                    sesion.progreso,
                    sesion.horaInicioReal.format(DateTimeFormatter.ofPattern("HH:mm")),
                    sesion.horaFinReal.format(DateTimeFormatter.ofPattern("HH:mm"))));
                
                slot++;
            }
        }
        
        // Actualizar título del área
        int ocupados = sesionesArea.size();
        int areaIndex = java.util.Arrays.asList(AREAS).indexOf(areaName);
        JPanel panelAreas = (JPanel) panelSimulacion.getComponent(1);
        JPanel panelArea = (JPanel) panelAreas.getComponent(areaIndex);
        JLabel titulo = (JLabel) panelArea.getComponent(0);
        titulo.setText(areaName + " (" + ocupados + "/" + CAPACIDAD_AREA + " ocupados)");
    }

    private void iniciarSimulacionTiempoAcelerado() {
        // Timer para estadísticas cada 10 segundos
        timerActualizacion = new Timer(10000, e -> {
            mostrarEstadisticas();
        });
        timerActualizacion.start();
        
        System.out.println("🚀 SIMULACIÓN CON TIEMPO ACELERADO INICIADA");
        System.out.println("📅 Fecha simulada: " + fechaSimulada);
        System.out.println("⏰ Hora inicial: " + tiempoSimulado.format(DateTimeFormatter.ofPattern("HH:mm")));
        System.out.println("⚡ Velocidad: 1 segundo real = " + factorAceleracion + " minutos simulados");
        System.out.println("🎮 Controles: Pausar, Acelerar, Ralentizar, Reiniciar Día");
        mostrarEstadisticas();
    }

    // Métodos de control
    private void togglePausa() {
        pausado = !pausado;
        System.out.println(pausado ? "⏸️ SIMULACIÓN PAUSADA" : "▶️ SIMULACIÓN REANUDADA");
    }

    private void cambiarVelocidad(boolean acelerar) {
        if (acelerar && factorAceleracion < 30) {
            factorAceleracion += 5;
        } else if (!acelerar && factorAceleracion > 1) {
            factorAceleracion -= 1;
        }
        
        SwingUtilities.invokeLater(() -> {
            labelVelocidad.setText("Velocidad: 1s = " + factorAceleracion + "min");
        });
        
        System.out.println("⚡ Nueva velocidad: 1 segundo real = " + factorAceleracion + " minutos simulados");
    }

    private void reiniciarDia() {
        tiempoSimulado = LocalTime.of(8, 0);
        limpiarTodasLasSesiones();
        System.out.println("🔄 DÍA REINICIADO - Hora: 08:00");
    }

    private void limpiarTodasLasSesiones() {
        for (String area : AREAS) {
            sesionesActivas.get(area).clear();
            int areaIndex = java.util.Arrays.asList(AREAS).indexOf(area);
            // Liberar todos los semáforos
            semaforosAreas[areaIndex].drainPermits();
            semaforosAreas[areaIndex].release(CAPACIDAD_AREA);
        }
        
        SwingUtilities.invokeLater(() -> {
            for (String area : AREAS) {
                actualizarInterfazArea(area);
            }
        });
    }

    private void mostrarEstadisticas() {
        int totalCitasHoy = 0;
        int sesionesActivas = 0;
        
        System.out.println("\n📊 === ESTADÍSTICAS GIMNASIO (TIEMPO ACELERADO) ===");
        System.out.println("📅 Fecha: " + fechaSimulada + " - ⏰ Hora: " + tiempoSimulado.format(DateTimeFormatter.ofPattern("HH:mm")));
        System.out.println("⚡ Velocidad: 1s real = " + factorAceleracion + "min simulados");
        
        for (String area : AREAS) {
            List<citas> citasArea = obtenerCitasDelDiaParaArea(fechaSimulada, area);
            int sesionesAreaActivas = this.sesionesActivas.get(area).size();
            
            System.out.println("🏥 " + area + ": " + citasArea.size() + " citas programadas, " + 
                             sesionesAreaActivas + " sesiones activas");
            
            totalCitasHoy += citasArea.size();
            sesionesActivas += sesionesAreaActivas;
        }
        
        System.out.println("📈 TOTAL: " + totalCitasHoy + " citas hoy, " + sesionesActivas + " sesiones activas");
        System.out.println("================================================\n");
    }

    @Override
    public void dispose() {
        simulacionActiva = false;
        
        if (timerTiempoAcelerado != null) {
            timerTiempoAcelerado.stop();
        }
        
        if (hilosAreas != null) {
            for (Thread hilo : hilosAreas) {
                if (hilo != null && hilo.isAlive()) {
                    hilo.interrupt();
                    try {
                        hilo.join(1000);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }
        
        if (timerActualizacion != null) {
            timerActualizacion.stop();
        }
        
        System.out.println("🛑 Simulación detenida.");
        super.dispose();
    }
   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        panelSimulacion = new javax.swing.JPanel();
        regresar = new javax.swing.JButton();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 153, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelSimulacion.setBackground(new java.awt.Color(204, 204, 255));
        panelSimulacion.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(panelSimulacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 520, 530));

        regresar.setText("Regresar");
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });
        jPanel1.add(regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 560, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 30, 560, 610));

        fondo.setIcon(new javax.swing.ImageIcon("C:/Users/52444/Documents/P3-PRIM-25/fisioGympf/src/main/java/resources/img/fondo1.jpg"));
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 660));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        menu m1 = new menu(this.objDatos);  
        m1.setVisible(true); 
        this.dispose();
    }//GEN-LAST:event_regresarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(gimnasio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(gimnasio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(gimnasio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(gimnasio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
       
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new gimnasio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel fondo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel panelSimulacion;
    private javax.swing.JButton regresar;
    // End of variables declaration//GEN-END:variables
}
