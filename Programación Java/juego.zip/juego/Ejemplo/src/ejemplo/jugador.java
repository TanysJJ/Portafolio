/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo;

/**
 *
 * @author 174177
 */
public class jugador {
    private String nombre;
    private String user;
    private String pass;
    private int edad;
    private String genero;

    public jugador(String nombre, String user, String pass, int edad, String genero) {
        this.nombre = nombre;
        this.user = user;
        this.pass = pass;
        this.edad = edad;
        this.genero = genero;
    }

    public int getEdad() {
        return edad;
    }

    public String getGenero() {
        return genero;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUser() {
        return user;
    }

    public String getPass() {
        return pass;
    }
    

    
   
}
