/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.memoriadinamica;

/**
 *
 * @author 52444
 */
public class MemoriaDinamica {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
