/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tienda;

/**
 *
 * @author 52444
 */
public class TelefonoMovil extends Producto {
    public double descuento=10;
    public double precioFinal;
    public double precioTotal;
    
    public TelefonoMovil(String nombre, String marca, double precioBase) {
        super(nombre, marca, precioBase);
     
    }
    
    @Override
    public void calcularPrecioFinal(){
      precioTotal = precioBase - (precioBase * (descuento / 100.0));
    }
    
    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Precio final con descuento " + precioTotal);
    }
    
}