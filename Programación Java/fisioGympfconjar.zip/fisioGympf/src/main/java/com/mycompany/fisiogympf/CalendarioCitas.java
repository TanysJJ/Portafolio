/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fisiogympf;

/**
 *
 * @author Alice
 */

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class CalendarioCitas {
    private datosP objDatos;
    private datosC objDatosCitas;
    private SalaEspera salaDeEspera;
    private LocalDate currentDate;
    private LocalDate selectedDate;
    
    public static final int START_HOUR = 8; // 8 AM
    public static final int END_HOUR = 18; // 6 PM
    public static final int MAX_SLOTS_PER_AREA = 3;
    
    public CalendarioCitas(datosP objDatos, datosC objDatosCitas) {
        this.objDatos = objDatos;
        this.objDatosCitas = objDatosCitas;
        this.salaDeEspera = new SalaEspera();
        this.currentDate = LocalDate.now();
    }
    
    // Añade estos métodos getter que estás usando
    public LocalDate getCurrentDate() {
        return currentDate;
    }
    
    public LocalDate getSelectedDate() {
        return selectedDate;
    }
    
    public void setSelectedDate(LocalDate date) {
        this.selectedDate = date;
    }
    
    public datosP getObjDatos() {
        return objDatos;
    }
    
    public String getMonthYear() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
        return currentDate.format(formatter);
    }
    
    public void prevMonth() {
        currentDate = currentDate.minusMonths(1);
    }
    
    public void nextMonth() {
        currentDate = currentDate.plusMonths(1);
    }
    
    
    // Métodos para manejar citas
    public void agregarCita(String paciente, LocalDate fecha, int hora, String area, int duracion) {
        for (int i = 0; i < duracion; i++) {
            citas nuevaCita = new citas(
                paciente,
                fecha.getDayOfMonth(),
                fecha.getMonthValue(),
                fecha.getYear(),
                hora + i,
                area);
            objDatosCitas.agregarCita(nuevaCita);
        }
    }
    
    public void eliminarCita(citas cita) {
        objDatosCitas.getCitas().remove(cita);
    }
    
    public void actualizarCita(citas citaOriginal, citas citaActualizada) {
        int index = objDatosCitas.getCitas().indexOf(citaOriginal);
        if (index != -1) {
            objDatosCitas.getCitas().set(index, citaActualizada);
        }
    }
    
    // Métodos para consultar disponibilidad
    public boolean tieneCitas(LocalDate fecha) {
        for (citas cita : objDatosCitas.getCitas()) {
            if (cita.getDia() == fecha.getDayOfMonth() && 
                cita.getMes() == fecha.getMonthValue() && 
                cita.getAño() == fecha.getYear()) {
                return true;
            }
        }
        return false;
    }
    
    public String[] getHorasDisponibles(LocalDate date, String areaName) {
        ArrayList<String> horasDisp = new ArrayList<>();
        
        for (int hour = START_HOUR; hour < END_HOUR; hour++) {
            int occupiedSlots = getOccupiedSlots(date, hour, areaName);
            int availableSlots = MAX_SLOTS_PER_AREA - occupiedSlots;
            
            if (availableSlots > 0) {
                horasDisp.add(formatHour(hour));
            }
        }
        
        return horasDisp.toArray(new String[0]);
    }
    
    private int getOccupiedSlots(LocalDate date, int hour, String areaName) {
        int count = 0;
        for (citas cita : objDatosCitas.getCitas()) {
            if (cita.getDia() == date.getDayOfMonth() && 
                cita.getMes() == date.getMonthValue() && 
                cita.getAño() == date.getYear() && 
                cita.getHora() == hour && 
                cita.getServicio().equals(areaName)) {
                count++;
            }
        }
        return count;
    }
    
    private String formatHour(int hour) {
        return hour + ":00";
    }
    
    public String formatDate(LocalDate date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return date.format(formatter);
    }
    
    // Métodos para la sala de espera
    public boolean agregarASalaEspera(String paciente) {
        return salaDeEspera.agregarPaciente(paciente);
    }
    
    public int pacientesEnEspera() {
        return salaDeEspera.pacientesEnEspera();
    }
    
    public boolean hayEspacioEnSalaEspera() {
        return salaDeEspera.hayEspacio();
    }
    
    public void moverDeEsperaACita(LocalDate fecha, String area) {
        String[] horasDisponibles = getHorasDisponibles(fecha, area);

        while (horasDisponibles.length > 0 && salaDeEspera.pacientesEnEspera() > 0) {
            String paciente = salaDeEspera.siguientePaciente();
            String hora = horasDisponibles[0];
            int horaInt = Integer.parseInt(hora.split(":")[0]);

            citas nuevaCita = new citas(
                paciente,
                fecha.getDayOfMonth(),
                fecha.getMonthValue(),
                fecha.getYear(),
                horaInt,
                area);

            objDatosCitas.agregarCita(nuevaCita);
            horasDisponibles = getHorasDisponibles(fecha, area);
        }
    }
}