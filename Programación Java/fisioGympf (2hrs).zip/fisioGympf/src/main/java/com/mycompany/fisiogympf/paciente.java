/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fisiogympf;

/**
 *
 * @author 52444
 */
public class paciente {
    String nombre;
    String DNI;
    String telefono;
    int dia;
    int mes;
    int año;
    boolean bandera = true;
    private paciente pacienteObj;

    public paciente(String nombre, String DNI, String telefono, int dia, int mes, int año ) {
        this.nombre = nombre;
        this.DNI = DNI;
        this.telefono = telefono;
        this.dia = dia;
        this.mes = mes;
        this.año = año;
        this.pacienteObj = null; 
        
    }

    public String getNombre() {
        return nombre;
    }

    public String getDNI() {
        return DNI;
    }

    public String getTelefono() {
        return telefono;
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAño() {
        return año;
    }

   
    
    
}
