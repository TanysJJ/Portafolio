/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.juegobomba;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class JuegoBomba extends JFrame implements ActionListener{

   private final JButton[][] botones = new JButton[10][10];
   private final Set<Point> posicionesBomba = new HashSet<>();
   public Random rand = new Random();
   private int vidas = 3;
   private int puntos = 0;

    
    public JuegoBomba() {
     
        setTitle("Buscaminas");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  

       
        setLayout(new GridLayout(10, 10)); 

        
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                botones[i][j] = new JButton();
                botones[i][j].setFont(new Font("Arial", Font.PLAIN, 60));
                botones[i][j].setFocusPainted(false);
                botones[i][j].setEnabled(true); 
                botones[i][j].addActionListener(this);  
                add(botones[i][j]);
            }
        }
        
        while (posicionesBomba.size() < 10) {
            int fila = rand.nextInt(10);
            int col = rand.nextInt(10);
            posicionesBomba.add(new Point(fila, col));
            
        }
    }
   
    public static void main(String[] args) {
            new JuegoBomba().setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    JButton fuente = (JButton) e.getSource();

   
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            if (botones[i][j] == fuente) {
                  if (vidas>0) {
                    if (posicionesBomba.contains(new Point(i, j))) {
                    ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/img/bomba.jpg"));
                    Image imagenRedimensionada = iconoOriginal.getImage().getScaledInstance(fuente.getWidth(), fuente.getHeight(), Image.SCALE_SMOOTH);
                    fuente.setIcon(new ImageIcon(imagenRedimensionada));
                    fuente.setDisabledIcon(new ImageIcon(imagenRedimensionada));
                    fuente.removeActionListener(this);
                    
                    puntos-=10;
                    vidas--;
                    JOptionPane.showMessageDialog(null, "Puntos: "+puntos+" Quedan: "+vidas + " Vidas", "Puntaje",JOptionPane.ERROR_MESSAGE );
                } else {
                    fuente.setEnabled(false);
                    puntos+=10;
                    JOptionPane.showMessageDialog(null, "Puntos: "+puntos, "Puntaje",JOptionPane.INFORMATION_MESSAGE );
                        if ((puntos==900 && vidas==3)||(puntos==890 && vidas==2)||(puntos==880 && vidas == 1)) {
                            JOptionPane.showMessageDialog(null, "GANASTE\nPuntos totales: "+puntos, "WIIIIINEEEER",JOptionPane.INFORMATION_MESSAGE ); 
                            dispose();
                        }
                }                     
               }else{
                    JOptionPane.showMessageDialog(null, "Haz perdido\nPuntos totales: "+puntos, "LOOOOOSEEEEER",JOptionPane.ERROR_MESSAGE ); 
                    dispose();  
                  }
                  
                return;
            }
           
        }
    }
}    
}
