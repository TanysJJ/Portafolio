/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tienda;

/**
 *
 * @author 52444
 */
public class Tableta extends Producto{
    public int descuento;
    public double precioFinal;
    public double precioTotal;
    
    public Tableta(String nombre, String marca, double precioBase) {
        super(nombre, marca, precioBase);
        
    }
    
    @Override
    public void calcularPrecioFinal(){
      precioTotal = precioBase-(precioBase *(0.5));
 
    }
    
    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Precio final con descuento " + precioTotal);
    }
}
