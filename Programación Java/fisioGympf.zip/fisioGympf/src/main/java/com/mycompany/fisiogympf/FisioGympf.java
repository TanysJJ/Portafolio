/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fisiogympf;

/**
 *
 * @author 52444
 */
public class FisioGympf {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
