public class Mergesort {

    public static void merge(int A[], int p, int q, int r) {
    int n1 = q-p+1;
    int n2 = r-q;
    int L[] = new int[n1+1];
    int R[] = new int[n2+1];
        for (int i = 0; i < n1; i++) {
            L[i] = A[p+i];
        }
        for (int i = 0; i < n2; i++) {
             R[i] = A[q+i+1];
        }
        
        L[n1] = Integer.MAX_VALUE;
        R[n2] = Integer.MAX_VALUE;
        int i =0, j=0;
        for (int k = p; k <= r; k++) {
            if (L[i]<=R[j]) {
                A[k] = L[i++];
            }
            else{
                A[k] = R[j++];
            }
        }
    }
    static void mergesort(int A[], int p,int r) {
        if (p<r) {
          int q = (p + r)/2;
          mergesort(A, p, q);
          mergesort(A,q+1,r);
          merge(A,p,q,r);
        }
    }
    
    public static void main(String[] args) {
        int A[] = {5,2,4,6,1,3,9,10,8,7};
         
         //imprimir arreglo sin ordenar
         for(int x : A)
             System.out.print(x+" ");
         System.out.println();
         
         //ordenar arreglo
         Mergesort.mergesort(A, 0 ,9);
         
        //Imprimimos el arreglo ordenado
         for (int x : A)
           System.out.print(x+" ");
         System.out.println();
     } 
    }
    
    
//Merge sort con genericos

public class MezclaSort {

    public static <T extends Comparable<T>> void merge(T A[], int p, int q, int r) {
    
    int n1 = q-p+1;
    int n2 = r-q;
    
    T L[] = (T[]) new Comparable[n1+1];
    T R[] = (T[]) new Comparable[n2+1];
    
        for (int i = 0; i < n1; i++) {
            L[i] = A[p+i];
        }
        for (int i = 0; i < n2; i++) {
             R[i] = A[q+i+1];
        }
        
        L[n1] = null;
        R[n2] = null;
        
        int i =0, j=0;
        for (int k = p; k <= r; k++) {
            if (R[j] == null || (L[i] != null && L[i].compareTo(R[j]) <= 0)){
                A[k] = L[i++];
            }
            else{
                A[k] = R[j++];
            }
        }
    }
   public static <T extends Comparable<T>> void mezclaSort(T A[], int p, int r) {
        if (p < r) {
            int q = (p + r) / 2;
            mezclaSort(A, p, q);
            mezclaSort(A, q + 1, r);
            merge(A, p, q, r);
        }
    }
    
    public static void main(String[] args) {
         //Integer A[] = {5,2,4,6,1,3,9,10,8,7};
         String A[] ={ "wannabe\n", "the view\n", "cry for me\n", "shoot me\n", "congratulations\n", "All in\n","Chill\n", "Youth\n", "Social Path\n","3Racha\n","JJam\n"};
         // Imprimir arreglo sin ordenar
          System.out.println("Arreglo original:");
        for (Comparable x : A)
            System.out.print(x + " ");
        System.out.println();
        
        // Ordenar arreglo
        MezclaSort. mezclaSort(A, 0, A.length - 1);
        
        // Imprimir el arreglo ordenado
        System.out.println("Arreglo ordenado:");
        for (Comparable x : A)
            System.out.print(x + " ");
        System.out.println();
    }
}

